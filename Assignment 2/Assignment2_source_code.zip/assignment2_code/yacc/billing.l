%{
/* billing.l - LEX scanner for the telecom billing-rule language */
#include <stdlib.h>
#include <string.h>
#include "ast.h"
#include "billing.tab.h"
int lineno = 1;
%}
%option noyywrap nounput noinput
%%
[ \t\r]+                ;
\n                      { lineno++; }
"//".*                  ;
"int"                   { return INT; }
"if"                    { return IF; }
"else"                  { return ELSE; }
"&&"                    { return AND; }
"||"                    { return OR; }
"=="                    { return EQ; }
"!="                    { return NE; }
"<="                    { return LE; }
">="                    { return GE; }
[0-9]+                  { yylval.num = atoi(yytext); return NUM; }
[A-Za-z_][A-Za-z0-9_]*  { yylval.name = strdup(yytext); return ID; }
[-+*/<>=;(){}]          { return yytext[0]; }
.                       { fprintf(stderr, "line %d: stray character '%s'\n", lineno, yytext); }
%%
