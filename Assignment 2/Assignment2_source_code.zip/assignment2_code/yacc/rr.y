%{
/* rr.y - reduce/reduce conflict: a bare name may be a tariff or a customer */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
int yylex(void); void yyerror(const char *s) { fprintf(stderr, "%s\n", s); }
%}
%token NAME
%%
stmt   : tariff ';'    { printf("parsed as: apply TARIFF\n"); }
       | customer ';'  { printf("parsed as: bill CUSTOMER\n"); }
       ;
tariff   : NAME ;
customer : NAME ;
%%
int yylex(void) { int c; while ((c = getchar()) == ' ' || c == '\n');
  if (isalpha(c)) { while (isalnum(c = getchar())); ungetc(c, stdin); return NAME; }
  return c == EOF ? 0 : c; }
int main(void) { return yyparse(); }
