%{
/* billing.y - YACC/Bison specification for the billing-rule language.
   Conflicts removed by rewriting the grammar (method a). */
#include <stdio.h>
#include <stdlib.h>
#include "ast.h"
int yylex(void);
void yyerror(const char *s);
extern int lineno;
int nerrors = 0;
%}
%union { int num; char *name; struct node *n; }
%token <num>  NUM
%token <name> ID
%token INT IF ELSE AND OR EQ NE LE GE
%type  <n> prog stmts stmt matched unmatched expr and_e rel_e add_e mul_e prim

%%
prog  : stmts                         { show($1); printf("\n"); }
      ;
stmts : %empty                        { $$ = NULL; }
      | stmts stmt                    { $$ = $2 ? ($1 ? mk("seq", $1, $2, NULL) : $2) : $1; }
      ;
stmt  : matched | unmatched ;
matched : INT ID ';'                  { $$ = mk("decl", leaf_id($2), NULL, NULL); }
      | ID '=' expr ';'               { $$ = mk("=", leaf_id($1), $3, NULL); }
      | IF '(' expr ')' matched ELSE matched { $$ = mk("if", $3, $5, $7); }
      | '{' stmts '}'                 { $$ = $2; }
      | error ';'                     { $$ = NULL; yyerrok; }
      ;
unmatched : IF '(' expr ')' stmt      { $$ = mk("if", $3, $5, NULL); }
      | IF '(' expr ')' matched ELSE unmatched { $$ = mk("if", $3, $5, $7); }
      ;
expr  : expr OR and_e   { $$ = mk("||", $1, $3, NULL); } | and_e ;
and_e : and_e AND rel_e { $$ = mk("&&", $1, $3, NULL); } | rel_e ;
rel_e : add_e '<' add_e { $$ = mk("<", $1, $3, NULL); }
      | add_e '>' add_e { $$ = mk(">", $1, $3, NULL); }
      | add_e LE add_e  { $$ = mk("<=", $1, $3, NULL); }
      | add_e GE add_e  { $$ = mk(">=", $1, $3, NULL); }
      | add_e EQ add_e  { $$ = mk("==", $1, $3, NULL); }
      | add_e NE add_e  { $$ = mk("!=", $1, $3, NULL); }
      | add_e ;
add_e : add_e '+' mul_e { $$ = mk("+", $1, $3, NULL); }
      | add_e '-' mul_e { $$ = mk("-", $1, $3, NULL); }
      | mul_e ;
mul_e : mul_e '*' prim  { $$ = mk("*", $1, $3, NULL); }
      | mul_e '/' prim  { $$ = mk("/", $1, $3, NULL); }
      | prim ;
prim  : '(' expr ')'    { $$ = $2; }
      | NUM             { $$ = leaf_num($1); }
      | ID              { $$ = leaf_id($1); }
      ;
%%
node *mk(const char *op, node *a, node *b, node *c) {
    node *n = calloc(1, sizeof *n); n->op = op; n->a = a; n->b = b; n->c = c; return n; }
node *leaf_num(int v) { node *n = mk("num", 0, 0, 0); n->val = v; return n; }
node *leaf_id(char *s) { node *n = mk("id", 0, 0, 0); n->name = s; return n; }
void show(node *n) {
    if (!n) { printf("_"); return; }
    if (n->op[0] == 'n' && n->op[1] == 'u') { printf("%d", n->val); return; }
    if (n->op[0] == 'i' && n->op[1] == 'd') { printf("%s", n->name); return; }
    printf("(%s ", n->op); show(n->a);
    if (n->b) { printf(" "); show(n->b); }
    if (n->c) { printf(" "); show(n->c); }
    printf(")");
}
void yyerror(const char *s) { nerrors++; fprintf(stderr, "line %d: %s\n", lineno, s); }
int main(void) { int r = yyparse(); fprintf(stderr, "errors reported: %d\n", nerrors); return r; }
