%{
/* ambig4.y - deliberately ambiguous: no precedence, no associativity */
#include <stdio.h>
int yylex(void); void yyerror(const char *s) { fprintf(stderr, "%s\n", s); }
%}
%token NUM
%%
line : expr '\n'          { printf("= %d\n", $1); }
     ;
expr : expr '+' expr      { $$ = $1 + $3; }
     | expr '-' expr      { $$ = $1 - $3; }
     | expr '*' expr      { $$ = $1 * $3; }
     | expr '/' expr      { $$ = $1 / $3; }
     | NUM
     ;
%%
#include <ctype.h>
int yylex(void) { int c; while ((c = getchar()) == ' '); if (isdigit(c)) { ungetc(c, stdin); scanf("%d", &yylval); return NUM; } return c == EOF ? 0 : c; }
int main(void) { return yyparse(); }
