%token IF ELSE WATER NUM ID RELOP AND OR
%%
S : M | U ;
M : IF '(' C ')' M ELSE M | WATER NUM ';' ;
U : IF '(' C ')' S | IF '(' C ')' M ELSE U ;
C : C OR D | D ;
D : D AND N | N ;
N : '!' N | P ;
P : '(' C ')' | ID RELOP NUM | ID ;
