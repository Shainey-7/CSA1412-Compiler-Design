#ifndef AST_H
#define AST_H
typedef struct node {
    const char *op;          /* "+", "if", "=", "decl", "num", "id", "seq" ... */
    char *name; int val;
    struct node *a, *b, *c;
} node;
node *mk(const char *op, node *a, node *b, node *c);
node *leaf_num(int v);
node *leaf_id(char *s);
void show(node *n);
#endif
