%token IF ELSE WATER NUM ID RELOP AND OR
%%
S : IF '(' C ')' S | IF '(' C ')' S ELSE S | WATER NUM ';' ;
C : C AND C | C OR C | '!' C | '(' C ')' | A ;
A : ID RELOP NUM | ID ;
