import re, sys
src = open(sys.argv[1]).read()
tot = 0
for name in ["yypact", "yydefact", "yypgoto", "yydefgoto", "yytable", "yycheck", "yystos", "yyr1", "yyr2"]:
    m = re.search(r"static const \w+ " + name + r"\[\] =\s*\{(.*?)\};", src, re.S)
    n = len([x for x in m.group(1).replace("\n", " ").split(",") if x.strip()])
    tot += n
print(sys.argv[1], "total parse-table entries:", tot)
