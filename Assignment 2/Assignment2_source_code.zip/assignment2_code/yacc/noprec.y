%{
/* billing.y - YACC/Bison specification for the billing-rule language.
   Conflicts resolved with precedence declarations (method b). */
#include <stdio.h>
#include <stdlib.h>
#include "ast.h"
int yylex(void);
void yyerror(const char *s);
extern int lineno;
int nerrors = 0;
%}
%union { int num; char *name; struct node *n; }
%token <num>  NUM
%token <name> ID
%token INT IF ELSE AND OR EQ NE LE GE
%type  <n> prog stmts stmt expr

%%
prog  : stmts                         { show($1); printf("\n"); }
      ;
stmts : %empty                        { $$ = NULL; }
      | stmts stmt                    { $$ = $2 ? ($1 ? mk("seq", $1, $2, NULL) : $2) : $1; }
      ;
stmt  : INT ID ';'                    { $$ = mk("decl", leaf_id($2), NULL, NULL); }
      | ID '=' expr ';'               { $$ = mk("=", leaf_id($1), $3, NULL); }
      | IF '(' expr ')' stmt
                                      { $$ = mk("if", $3, $5, NULL); }
      | IF '(' expr ')' stmt ELSE stmt { $$ = mk("if", $3, $5, $7); }
      | '{' stmts '}'                 { $$ = $2; }
      | error ';'                     { $$ = NULL; yyerrok; }
      ;
expr  : expr '+' expr   { $$ = mk("+", $1, $3, NULL); }
      | expr '-' expr   { $$ = mk("-", $1, $3, NULL); }
      | expr '*' expr   { $$ = mk("*", $1, $3, NULL); }
      | expr '/' expr   { $$ = mk("/", $1, $3, NULL); }
      | expr '<' expr   { $$ = mk("<", $1, $3, NULL); }
      | expr '>' expr   { $$ = mk(">", $1, $3, NULL); }
      | expr LE expr    { $$ = mk("<=", $1, $3, NULL); }
      | expr GE expr    { $$ = mk(">=", $1, $3, NULL); }
      | expr EQ expr    { $$ = mk("==", $1, $3, NULL); }
      | expr NE expr    { $$ = mk("!=", $1, $3, NULL); }
      | expr AND expr   { $$ = mk("&&", $1, $3, NULL); }
      | expr OR expr    { $$ = mk("||", $1, $3, NULL); }
      | '(' expr ')'    { $$ = $2; }
      | NUM             { $$ = leaf_num($1); }
      | ID              { $$ = leaf_id($1); }
      ;
%%
node *mk(const char *op, node *a, node *b, node *c) {
    node *n = calloc(1, sizeof *n); n->op = op; n->a = a; n->b = b; n->c = c; return n; }
node *leaf_num(int v) { node *n = mk("num", 0, 0, 0); n->val = v; return n; }
node *leaf_id(char *s) { node *n = mk("id", 0, 0, 0); n->name = s; return n; }
void show(node *n) {
    if (!n) { printf("_"); return; }
    if (n->op[0] == 'n' && n->op[1] == 'u') { printf("%d", n->val); return; }
    if (n->op[0] == 'i' && n->op[1] == 'd') { printf("%s", n->name); return; }
    printf("(%s ", n->op); show(n->a);
    if (n->b) { printf(" "); show(n->b); }
    if (n->c) { printf(" "); show(n->c); }
    printf(")");
}
void yyerror(const char *s) { nerrors++; fprintf(stderr, "line %d: %s\n", lineno, s); }
int main(void) { int r = yyparse(); fprintf(stderr, "errors reported: %d\n", nerrors); return r; }
