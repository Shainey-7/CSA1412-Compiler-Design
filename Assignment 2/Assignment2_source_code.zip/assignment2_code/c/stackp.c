/* stackp.c - the redesign in C: explicit heap stack, no recursion */
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv) {
    long n = atol(argv[1]), sp = 0, max = 0;
    char *t = malloc(2 * n + 2);
    for (long k = 0; k < n; k++) t[k] = '(';
    t[n] = 'x'; for (long k = 0; k < n; k++) t[n + 1 + k] = ')'; t[2 * n + 1] = 0;
    char *stk = malloc(n + 2);                  /* operator stack on the heap */
    for (long i = 0; t[i]; i++) {
        if (t[i] == '(') { stk[sp++] = '('; if (sp > max) max = sp; }
        else if (t[i] == ')') { if (sp == 0 || stk[--sp] != '(') { puts("error"); return 1; } }
    }
    printf("ok n=%ld stack=%ld\n", n, max);
    return 0;
}
