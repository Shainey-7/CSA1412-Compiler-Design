/* rd.c - the original recursive-descent design in C, 7 procedures (billing precedence levels).
   Reads n and parses "(" * n  id  ")" * n held in memory. */
#include <stdio.h>
#include <stdlib.h>
static char *t; static long i;
static long depth, maxdepth;
static void lvl(int k);
static void primary(void) {
    if (t[i] == '(') { i++; lvl(0); if (t[i] != ')') { puts("error"); exit(1); } i++; }
    else if (t[i] == 'x') i++;
    else { puts("error"); exit(1); }
}
static const char *ops[] = {"|", "&", "<", "+", "*", "^"};
static void lvl(int k) {
    char pad[16]; pad[0] = (char)k;           /* typical small locals in a real parser frame */
    if (++depth > maxdepth) maxdepth = depth;
    if (k == 6) primary();
    else { lvl(k + 1); while (t[i] && t[i] == ops[k][0]) { i++; lvl(k + 1); } }
    depth--; (void)pad;
}
int main(int argc, char **argv) {
    long n = atol(argv[1]);
    t = malloc(2 * n + 2);
    for (long k = 0; k < n; k++) t[k] = '(';
    t[n] = 'x';
    for (long k = 0; k < n; k++) t[n + 1 + k] = ')';
    t[2 * n + 1] = 0;
    lvl(0);
    printf("ok n=%ld frames=%ld\n", n, maxdepth);
    return 0;
}
