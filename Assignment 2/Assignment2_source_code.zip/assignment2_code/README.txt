Assignment 2 (CO2) - source code behind every table in the report

toolkit/   Python 3 (no extra packages; Graphviz 'dot' needed only for figures)
           python3 q1.py ... python3 q7.py   -> writes tables/figures to ../out/
yacc/      bison -d -v billing.y && flex billing.l && gcc -o billing billing.tab.c lex.yy.c
           ./billing < sample.bill        ./billing < three.bill
           bison -v ambig4.y / noprec.y / rewrite.y / rr.y to reproduce the conflict reports
c/         gcc -O0 -o rd rd.c ; bash -c "ulimit -s 1024; ./rd 2204"   (stack-overflow test)
