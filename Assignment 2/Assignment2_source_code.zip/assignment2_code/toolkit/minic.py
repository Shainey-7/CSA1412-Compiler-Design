"""Mini-C front end used in Q5 and Q7: lexer, LL(1) parser with selectable recovery, SLR parser."""
import re, os
from grammar import Grammar, LR, END

KEYWORDS = {"if", "else", "while"}
TOKEN_RE = re.compile(r"\s*(?:(\d+)|([A-Za-z_]\w*)|(<=|>=|==|!=|<|>)|(.))")

GRAMMAR_TEXT = open(os.path.join(os.path.dirname(__file__), "minic.g")).read()


class Tok:
    def __init__(self, kind, lex, line, col):
        self.kind, self.lex, self.line, self.col = kind, lex, line, col

    def __repr__(self):
        return f"{self.kind}:{self.lex}@{self.line}"


def lex(src):
    toks = []
    for ln, line in enumerate(src.splitlines(), 1):
        pos = 0
        while pos < len(line):
            m = TOKEN_RE.match(line, pos)
            if not m or m.end() == pos:
                break
            col = m.start(m.lastindex) + 1
            num, ident, rel, other = m.groups()
            if num:
                toks.append(Tok("num", num, ln, col))
            elif ident:
                toks.append(Tok(ident if ident in KEYWORDS else "id", ident, ln, col))
            elif rel:
                toks.append(Tok("rel", rel, ln, col))
            elif other and other.strip():
                toks.append(Tok(other, other, ln, col))
            pos = m.end()
    last = len(src.splitlines()) or 1
    toks.append(Tok(END, "end of file", last + 1, 1))
    return toks


G = Grammar(GRAMMAR_TEXT)
TABLE, CONFLICTS = G.ll1_table(prefer={("X", "else"): G.alts("X")[0][0]})
STMT_START = {"id", "if", "while", "{"}
SYNC = {A: set(G.follow[A]) | {";", "}"} | ({"if", "while", "{"} if A in ("S", "L", "X", "P") else set()) for A in G.nts}
# statement-level non-terminals may also resynchronise on 'if', 'while', '{' (they start the next statement)

NAMES = {"rel": "a comparison operator (<, >, ==, ...)", "id": "an identifier", "num": "a number", END: "end of file"}


def nice(t):
    return NAMES.get(t, f"'{t}'")


def edit1(a, b):
    """True when a and b differ by one insertion, deletion or substitution."""
    if abs(len(a) - len(b)) > 1 or a == b:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    if len(a) > len(b):
        a, b = b, a
    return any(b[:i] + b[i + 1:] == a for i in range(len(b)))


def ll1_run(toks, mode="panic", trace=None, quiet_after_error=0):
    """
    mode: 'stop'   - report first error and stop
          'naive'  - report, skip the offending token, keep the stack, carry on
          'panic'  - panic mode with synchronising sets
          'phrase' - panic + phrase-level local repairs
          'full'   - phrase + error productions
    returns list of (line, message)
    """
    stack = [END, G.start]
    i = 0
    msgs = []
    opens = []              # lines of '{' not yet closed (for phrase-level messages)
    recovering = 0          # tokens to match before new messages are allowed (cascade guard)
    steps = 0

    def report(tok, text):
        if recovering == 0:
            msgs.append((tok.line, text))
        if trace is not None:
            trace.append(("ERR", " ".join(stack), " ".join(t.lex for t in toks[i:i + 6]), text))

    while stack and steps < 5000:
        steps += 1
        X, tok = stack[-1], toks[i]
        a = tok.kind
        if trace is not None and len(trace) < 400:
            trace.append(("", " ".join(stack), " ".join(t.lex if t.kind != END else "$" for t in toks[i:i + 6]), ""))
        if X == END and a == END:
            break
        if not G.is_nt(X):
            if X == a:
                stack.pop(); i += 1
                if recovering:
                    recovering -= 1
                continue
            # ---- terminal mismatch ----
            if mode == "stop":
                msgs.append((tok.line, f"expected {nice(X)} but found '{tok.lex}'")); return msgs
            if mode == "naive":
                msgs.append((tok.line, f"expected {nice(X)} but found '{tok.lex}'"))
                if a == END:
                    stack.pop()
                else:
                    i += 1
                continue
            if mode == "full" and X == "rel" and a == "=":
                # error production C -> E = E : accept, explain the likely mistake
                msgs.append((tok.line, "'=' used in a condition; did you mean '=='?"))
                stack.pop(); i += 1; recovering = quiet_after_error
                continue
            if mode in ("phrase", "full") and X == ";" and (a in STMT_START or a in ("}", END)):
                prev = toks[i - 1]
                msgs.append((prev.line, f"missing ';' after '{prev.lex}' (line {prev.line})"))
                stack.pop(); recovering = quiet_after_error
                continue
            if mode in ("phrase", "full") and X == "}" and opens:
                msgs.append((tok.line, f"missing '}}' for the block opened on line {opens.pop()}"))
                stack.pop(); continue
            report(tok, f"expected {nice(X)} but found '{tok.lex}' (inserted {nice(X)})")
            stack.pop(); recovering = quiet_after_error
            continue
        if mode in ("phrase", "full") and X in ("S", "L") and a == "id" and toks[i + 1].kind == "(":
            kw = next((k for k in ("while", "if") if edit1(tok.lex, k)), None)
            if kw:
                msgs.append((tok.line, f"unknown word '{tok.lex}'; did you mean '{kw}'?"))
                tok.kind = kw; recovering = quiet_after_error
                continue
        if mode in ("phrase", "full") and X in ("E'", "T'") and (a in STMT_START or a in ("}", END)) and ";" in stack:
            # expression is complete but the next statement has started: let E'/T' go to ε,
            # the ';' mismatch below then reports the missing semicolon at the right line
            stack.pop(); continue
        if mode == "full" and X in ("E'", "T'") and a == "=" and "rel" in stack:
            # error production C -> E = E : '=' may end an expression inside a condition
            stack.pop(); continue
        if a == "{":
            opens.append(tok.line)
        if a == "}" and X == "}" and opens:
            opens.pop()
        p = TABLE.get((X, a))
        if p is not None:
            stack.pop()
            stack.extend(reversed(G.prods[p][1]))
            continue
        # ---- blank table entry ----
        expected = sorted(t for (A, t) in TABLE if A == X)
        if mode == "stop":
            msgs.append((tok.line, f"unexpected '{tok.lex}'; expected one of {', '.join(map(nice, expected))}")); return msgs
        if mode == "naive":
            msgs.append((tok.line, f"unexpected '{tok.lex}'"))
            if a == END:
                stack.pop()
            else:
                i += 1
            continue
        if mode in ("phrase", "full"):
            # phrase-level: operator with missing operand -> insert a dummy operand
            if X in ("E", "T", "F") and a in (";", ")", "rel"):
                msgs.append((tok.line, f"operator has no right operand before '{tok.lex}'"))
                stack.pop(); recovering = quiet_after_error
                continue
        if mode == "full" and X in ("S", "L") and a == "else":
            # error production S -> else S : report once and parse the statement after it
            msgs.append((tok.line, "'else' without a matching 'if'"))
            i += 1; recovering = quiet_after_error
            continue
        if a in SYNC[X]:
            report(tok, f"unexpected '{tok.lex}' while parsing {X}; skipped {X}")
            stack.pop(); recovering = quiet_after_error
        else:
            report(tok, f"unexpected '{tok.lex}'; skipping input to resynchronise")
            # skip tokens until one in SYNC[X] or FIRST-usable
            while toks[i].kind != END and toks[i].kind not in SYNC[X] and (X, toks[i].kind) not in TABLE:
                i += 1
            recovering = quiet_after_error
            if toks[i].kind == END and (X, END) not in TABLE:
                stack.pop()
    return msgs


# ---------- SLR parser for detection points ----------
_LR = LR(G)
_LR.slr(prefer_shift=True)


def lr_detect(toks):
    """Return (token index of detection, reductions performed with that lookahead before the error)."""
    stack = [0]
    i = 0
    reds_since_shift = 0
    while True:
        a = toks[i].kind
        act = _LR.action.get((stack[-1], a))
        if act is None:
            return i, reds_since_shift
        if act[0] == "s":
            stack.append(act[1]); i += 1; reds_since_shift = 0
        elif act[0] == "r":
            lhs, rhs = _LR.g.prods[act[1]]
            for _ in rhs:
                stack.pop()
            stack.append(_LR.goto[(stack[-1], lhs)]); reds_since_shift += 1
        else:
            return None, 0


def ll_detect(toks):
    stack = [END, G.start]
    i = 0
    exp_since_match = 0
    while True:
        X, a = stack[-1], toks[i].kind
        if X == END and a == END:
            return None, 0
        if not G.is_nt(X):
            if X != a:
                return i, exp_since_match
            stack.pop(); i += 1; exp_since_match = 0
        else:
            p = TABLE.get((X, a))
            if p is None:
                return i, exp_since_match
            stack.pop(); stack.extend(reversed(G.prods[p][1])); exp_since_match += 1
