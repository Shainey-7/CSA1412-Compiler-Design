P -> L
L -> S L | ε
S -> id = E ; | if ( C ) S X | while ( C ) S | { L }
X -> else S | ε
C -> E rel E
E -> T E'
E' -> + T E' | - T E' | ε
T -> F T'
T' -> * F T' | / F T' | ε
F -> ( E ) | id | num
