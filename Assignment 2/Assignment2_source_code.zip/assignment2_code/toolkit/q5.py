from minic import *
from util import md_table, save

PROGRAMS = [
    ("E1", "Missing semicolon", "total = 0;\ncount = 5\nwhile (count > 0) { total = total + count; count = count - 1; }", 2),
    ("E2", "Unmatched brace", "while (x < 10) {\n  x = x + 1;\n  y = y * 2;\n", 1),
    ("E3", "else without if", "x = 1;\nelse x = 2;\ny = 3;", 2),
    ("E4", "= written for ==", "if (x = 5) y = 1;\nz = 2;", 1),
    ("E5", "Operator with missing operand", "a = b * ;\nc = a + 1;", 1),
    ("E6", "Misspelt keyword", "i = 0;\nwhille (i < 3) i = i + 1;\nk = i;", 2),
]
rep = []
print("LL(1) table conflicts (resolved toward else):", CONFLICTS)

# 1. catalogue with detection points
rows = []
for code, name, src, line in PROGRAMS:
    toks = lex(src)
    li, le = ll_detect(toks)
    ri, rr = lr_detect(toks)
    lt, rt = toks[li], toks[ri]
    rows.append((code, name, src.replace("\n", " ⏎ "),
                 f"token {li+1} '{lt.lex}' (line {lt.line}); {le} expansion(s) after last match",
                 f"token {ri+1} '{rt.lex}' (line {rt.line}); {rr} reduction(s) on this lookahead"))
save("q5_catalogue.md", md_table(["#", "Error", "Program (⏎ = new line)", "LL(1) detects at", "SLR detects at"], rows))

# 2. predictions vs measured naive behaviour, then recovery comparison
modes = [("stop", "No recovery"), ("naive", "Naive restart (skip 1 token)"), ("panic", "Panic mode"),
         ("phrase", "Panic + phrase-level"), ("full", "Panic + phrase + error productions")]
table_rows = []
summary = {m: [0, 0, 0, 0] for m, _ in modes}
detail = []
for code, name, src, line in PROGRAMS:
    r = [code]
    for m, _ in modes:
        msgs = ll1_run(lex(src), mode=m, quiet_after_error=3 if m != "naive" else 0)
        first_ok = bool(msgs) and (msgs[0][0] == line or f"line {line}" in msgs[0][1])
        spurious = len(msgs) - (1 if first_ok else 0)
        helpful = first_ok and any(k in msgs[0][1] for k in ("missing", "did you mean", "without", "no right operand"))
        summary[m][0] += len(msgs); summary[m][1] += spurious; summary[m][2] += first_ok; summary[m][3] += helpful
        r.append(f"{len(msgs)} / {spurious} / {'Y' if first_ok else 'N'} / {'Y' if helpful else 'N'}")
        if m in ("naive", "panic", "full"):
            detail.append((code, m, " | ".join(f"L{l}: {t}" for l, t in msgs)))
    table_rows.append(r)
table_rows.append(["Total"] + [f"{summary[m][0]} / {summary[m][1]} / {summary[m][2]} / {summary[m][3]}" for m, _ in modes])
save("q5_compare.md", md_table(["Program"] + [lab for _, lab in modes], table_rows))
save("q5_messages.md", md_table(["Program", "Strategy", "Messages printed"], detail))

# 3. panic-mode trace for E5
trace = []
msgs = ll1_run(lex(PROGRAMS[4][2]), mode="panic", trace=trace, quiet_after_error=3)
save("q5_panic_trace.md", md_table(["Step", "Stack (top at right)", "Next input", "Recovery action"],
                                   [(k + 1, s, inp, act) for k, (_, s, inp, act) in enumerate(trace)]))
rep.append(f"E5 panic messages: {msgs}")

# sync sets
from grammar import fmt_set
save("q5_sync.md", md_table(["Non-terminal", "FOLLOW", "Synchronising set used"],
                            [(A, fmt_set(G.follow[A]), fmt_set(SYNC[A])) for A in G.nts]))

# a file with three mistakes (used again in Q6 for comparison)
three = "x = 1\ny = x + ;\nif (y = 2) z = 3;\nw = 4;"
for m, lab in modes:
    msgs = ll1_run(lex(three), mode=m, quiet_after_error=3 if m != "naive" else 0)
    rep.append(f"THREE {lab}: {len(msgs)} -> {msgs}")
# effect of the cascade guard
for q in (0, 3):
    tot = sum(len(ll1_run(lex(src), mode="panic", quiet_after_error=q)) for _, _, src, _ in PROGRAMS)
    rep.append(f"panic total messages with quiet_after_error={q}: {tot}")
save("q5_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))

# panic trace for E1 (shows skipping), rows around the error
trace = []
ll1_run(lex(PROGRAMS[0][2]), mode="panic", trace=trace, quiet_after_error=3)
k0 = next(k for k, r in enumerate(trace) if r[0] == "ERR")
rows = [(k + 1, s, inp, act) for k, (_, s, inp, act) in enumerate(trace)][max(0, k0 - 3):k0 + 14]
save("q5_panic_trace_e1.md", md_table(["Step", "Stack (top at right)", "Next input", "Recovery action"], rows))
