"""Q7: diagnose the recursive-descent parser under deep nesting / changing grammar; redesign; measure."""
import sys, time, subprocess, json, tracemalloc, random
from util import md_table, save

rep = []

# ---------------------------------------------------------------------------
# ORIGINAL: recursive descent generated level-by-level (Q2 has 3 levels: E, T, F)
# one procedure per precedence level, exactly as a hand-written RD parser is built
# ---------------------------------------------------------------------------
class RDOriginal:
    def __init__(self, levels):
        self.levels = levels          # list of operator sets, lowest precedence first
        self.calls = 0
        self.max_depth = 0
        self.depth = 0

    def parse(self, toks):
        self.t, self.i = toks + ["$"], 0
        node = self.level(0)
        if self.t[self.i] != "$":
            raise SyntaxError(f"unexpected '{self.t[self.i]}' at token {self.i + 1}")
        return node

    def level(self, k):
        self.calls += 1
        self.depth += 1
        self.max_depth = max(self.max_depth, self.depth)
        if k == len(self.levels):
            node = self.primary()
        else:
            node = self.level(k + 1)
            while self.t[self.i] in self.levels[k]:
                op = self.t[self.i]; self.i += 1
                node = (op, node, self.level(k + 1))
        self.depth -= 1
        return node

    def primary(self):
        tok = self.t[self.i]
        if tok == "(":
            self.i += 1
            node = self.level(0)
            if self.t[self.i] != ")":
                raise SyntaxError(f"expected ')' at token {self.i + 1}")
            self.i += 1
            return node
        if tok in ("-", "!"):
            self.i += 1
            return ("neg" if tok == "-" else "not", self.primary())
        if tok in ("id", "num"):
            self.i += 1
            return tok
        raise SyntaxError(f"unexpected '{tok}' at token {self.i + 1}")


Q2_LEVELS = [{"+", "-"}, {"*", "/"}]
BILL_LEVELS = [{"||"}, {"&&"}, {"==", "!=", "<", ">", "<=", ">="}, {"+", "-"}, {"*", "/"}, {"^"}]

# ---------------------------------------------------------------------------
# REDESIGN: table-driven precedence parser with explicit heap stacks and
# statement-level error collection
# ---------------------------------------------------------------------------
class ParseError(Exception):
    pass


PREC = {  # operator: (precedence, associativity)   <- the only thing edited when the grammar changes
    "||": (1, "L"), "&&": (2, "L"),
    "==": (3, "N"), "!=": (3, "N"), "<": (3, "N"), ">": (3, "N"), "<=": (3, "N"), ">=": (3, "N"),
    "+": (4, "L"), "-": (4, "L"), "*": (5, "L"), "/": (5, "L"), "^": (6, "R"),
}
PREFIX = {"-": 7, "!": 7}
OPERANDS = {"id", "num"}


class Redesigned:
    def __init__(self, prec=PREC, prefix=PREFIX):
        self.prec, self.prefix = prec, prefix
        self.max_stack = 0
        self.stack_ops = 0

    def parse_expr(self, toks, i, stop):
        """Parse one expression starting at toks[i]; returns (ast, next_index). Raises on error."""
        vals, ops = [], []          # explicit stacks on the heap
        expect_operand = True
        open_parens = 0

        def reduce_top():
            op = ops.pop(); self.stack_ops += 1
            if op[0] == "prefix":
                v = vals.pop(); vals.append((op[1], v))
            else:
                b = vals.pop(); a = vals.pop(); vals.append((op[1], a, b))
            self.stack_ops += 1

        while True:
            tok = toks[i]
            if expect_operand:
                if tok in OPERANDS:
                    vals.append(tok); self.stack_ops += 1; expect_operand = False
                elif tok == "(":
                    ops.append(("paren", "(")); open_parens += 1; self.stack_ops += 1
                elif tok in self.prefix:
                    ops.append(("prefix", "neg" if tok == "-" else "not", self.prefix[tok])); self.stack_ops += 1
                else:
                    raise ParseError(i, f"expected an operand but found '{tok}'")
            else:
                if tok in self.prec:
                    p, assoc = self.prec[tok]
                    while ops and ops[-1][0] != "paren":
                        top = ops[-1]
                        tp = top[2] if top[0] == "prefix" else self.prec[top[1]][0]
                        if tp > p or (tp == p and assoc == "L"):
                            reduce_top()
                        elif tp == p and assoc == "N":
                            raise ParseError(i, f"'{top[1]}' and '{tok}' cannot be chained without parentheses")
                        else:
                            break
                    ops.append(("bin", tok)); self.stack_ops += 1; expect_operand = True
                elif tok == ")" and open_parens > 0:
                    while ops[-1][0] != "paren":
                        reduce_top()
                    ops.pop(); open_parens -= 1; self.stack_ops += 1
                elif tok in stop or tok == ")":
                    if open_parens:
                        raise ParseError(i, f"{open_parens} unclosed '(' before '{tok}'")
                    if tok == ")":
                        raise ParseError(i, "unmatched ')'")
                    while ops:
                        reduce_top()
                    return vals[0], i
                else:
                    raise ParseError(i, f"expected an operator or ';' but found '{tok}'")
            self.max_stack = max(self.max_stack, len(vals) + len(ops))
            i += 1

    def parse_file(self, toks):
        """toks: expression statements separated by ';'. Reports every error, one per statement."""
        toks = toks + ["$"]
        i, errors, asts = 0, [], []
        while toks[i] != "$":
            try:
                ast, i = self.parse_expr(toks, i, {";", "$"})
                asts.append(ast)
                if toks[i] == ";":
                    i += 1
            except ParseError as e:
                pos, msg = e.args
                errors.append((pos + 1, msg))
                while toks[pos] not in (";", "$"):       # resynchronise at the statement boundary
                    pos += 1
                i = pos + 1 if toks[pos] == ";" else pos
        return asts, errors


def nested(n, kind="paren"):
    if kind == "paren":
        return ["("] * n + ["id"] + [")"] * n
    if kind == "right":      # a ^ b ^ c ^ ... (right-assoc chain)
        out = ["id"]
        for _ in range(n):
            out += ["^", "id"]
        return out
    if kind == "mixed":      # id + ( id * ( id - ( ... ) ) )
        out = []
        for k in range(n):
            out += ["id", ["+", "*", "-", "/"][k % 4], "("]
        return out + ["id"] + [")"] * n


