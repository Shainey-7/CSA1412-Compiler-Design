from grammar import Grammar, LR, fmt_set
from util import *

AMBIG = """
S -> if ( C ) S | if ( C ) S else S | water num ;
C -> C && C | C || C | ! C | ( C ) | A
A -> id relop num | id
"""

REPAIRED = """
S -> M | U
M -> if ( C ) M else M | water num ;
U -> if ( C ) S | if ( C ) M else U
C -> C || D | D
D -> D && N | N
N -> ! N | P
P -> ( C ) | id relop num | id
"""

log = []
g1 = Grammar(AMBIG)
lr1 = LR(g1); _, _, c1 = lr1.slr()
g2 = Grammar(REPAIRED)
lr2 = LR(g2); _, _, c2 = lr2.slr()
lalr1 = LR(g1).lalr_states(); lalr2 = LR(g2).lalr_states()
lr_a, lr_b = LR(g1), LR(g2)
s1 = lr_a.lr1()[0]; s2 = lr_b.lr1()[0]
rep = []
rep.append(f"Ambiguous grammar G1: {len(g1.prods)} productions, SLR conflicts = {len(c1)}, canonical LR(1) states = {len(s1)}, LR(1) conflicts = {lr_a.lr1_conflicts(s1)}")
rep.append(f"Repaired grammar G2: {len(g2.prods)} productions, SLR conflicts = {len(c2)}, canonical LR(1) states = {len(s2)}, LR(1) conflicts = {lr_b.lr1_conflicts(s2)}")
for (st, a, o, n) in c1[:40]:
    rep.append(f"  G1 conflict state {st} on '{a}': {o} vs {n}")
save("q1_check.txt", "\n".join(rep) + "\n")
print("\n".join(rep[:2]))

# ---- worked rule: if (moisture < 30 && !raining) water 20;
toks = ["if", "(", "id", "relop", "num", "&&", "!", "id", ")", "water", "num", ";"]
labs = ["if", "(", "id\\nmoisture", "relop\\n<", "num\\n30", "&&", "!", "id\\nraining", ")", "water", "num\\n20", ";"]
tree, reds = tree_from_lr(lr2, toks)
left, right = derivations(tree, set(g2.nts))
save("q1_lm.md", md_table(["Step", "Leftmost derivation (expand the leftmost non-terminal)"],
                          [(i, ("S" if i == 0 else "⇒ ") + ("" if i == 0 else f) ) for i, f in enumerate(left)]))
save("q1_rm.md", md_table(["Step", "Rightmost derivation (expand the rightmost non-terminal)"],
                          [(i, ("S" if i == 0 else "⇒ ") + ("" if i == 0 else f)) for i, f in enumerate(right)]))
tree_l, _ = tree_from_lr(lr2, toks, labels=[l for l in labs] + ["$"])
tree_dot(tree_l, set(g2.nts), "fig1_parsetree")
print("derivation steps", len(left) - 1)

# ---- two parse trees for the ambiguous string under G1
# if ( moisture < 30 || raining && temp > 35 ) water 10 ;
A1 = ("A", [("id\nmoisture", []), ("relop\n<", []), ("num\n30", [])])
A2 = ("A", [("id\nraining", [])])
A3 = ("A", [("id\ntemp", []), ("relop\n>", []), ("num\n35", [])])
C = lambda *k: ("C", list(k))
t_or_top = C(C(A1), ("||", []), C(C(A2), ("&&", []), C(A3)))
t_and_top = C(C(C(A1), ("||", []), C(A2)), ("&&", []), C(A3))
wrap = lambda c: ("S", [("if", []), ("(", []), c, (")", []), ("S", [("water", []), ("num\n10", []), (";", [])])])
fix = lambda t: (t[0].replace("\n", "\\n"), [fix(k) for k in t[1]])
tree_dot(fix(wrap(t_or_top)), {"S", "C", "A"}, "fig2_ambig_or", highlight={"C": "#1f4e79"})
tree_dot(fix(wrap(t_and_top)), {"S", "C", "A"}, "fig3_ambig_and", highlight={"C": "#aa3333"})

# ---- dangling else trees: if (a) if (b) water 5; else water 0;
w = lambda n: ("S", [("water", []), (f"num\\n{n}", []), (";", [])])
inner_else = ("S", [("if", []), ("(", []), ("C\\nwet", []), (")", []),
                    ("S", [("if", []), ("(", []), ("C\\nhot", []), (")", []), w(5), ("else", []), w(0)])])
outer_else = ("S", [("if", []), ("(", []), ("C\\nwet", []), (")", []),
                    ("S", [("if", []), ("(", []), ("C\\nhot", []), (")", []), w(5)]), ("else", []), w(0)])
tree_dot(inner_else, {"S"}, "fig4a_else_inner")
tree_dot(outer_else, {"S"}, "fig4b_else_outer")

# ---- the repaired grammar on the dangling-else string: only one tree
toks2 = ["if", "(", "id", ")", "if", "(", "id", ")", "water", "num", ";", "else", "water", "num", ";"]
lr2b = LR(g2); lr2b.slr()
t2, _ = tree_from_lr(lr2b, toks2)
def shape(t):
    return t[0] if not t[1] else t[0] + "(" + " ".join(shape(k) for k in t[1]) + ")"
save("q1_dangling_repaired.txt", shape(t2) + "\n")
# ---- repaired grammar on the || && string: single tree, && binds tighter
toks3 = ["if", "(", "id", "relop", "num", "||", "id", "&&", "id", "relop", "num", ")", "water", "num", ";"]
t3, _ = tree_from_lr(lr2b, toks3)
save("q1_prec_repaired.txt", shape(t3) + "\n")
print(shape(t3))

# ---- the cooperative's own example rule
toks4 = "if ( id relop num && ! id ) water num ; else if ( id relop num ) water num ;".split()
t4, _ = tree_from_lr(lr2b, toks4)
save("q1_brief_example.txt", shape(t4) + "\n")
print(shape(t4))
