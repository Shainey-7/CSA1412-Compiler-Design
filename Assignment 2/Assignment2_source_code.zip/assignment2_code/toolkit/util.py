import os, subprocess, re
from grammar import EPS, END

OUT = os.path.join(os.path.dirname(__file__), "..", "out")
os.makedirs(OUT, exist_ok=True)


def esc(s):
    s = str(s)
    for ch in ["\\", "*", "_", "|", "`", "<", ">", "[", "]", "#"]:
        s = s.replace(ch, "\\" + ch)
    return s


def md_table(headers, rows, code_cols=()):
    out = ["| " + " | ".join(esc(h) for h in headers) + " |",
           "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        cells = []
        for k, c in enumerate(r):
            cells.append(esc(c) if c != "" else " ")
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out) + "\n"


def save(name, text):
    with open(os.path.join(OUT, name), "w") as f:
        f.write(text)


# ---------- trees ----------
def tree_from_lr(lr, tokens, labels=None):
    """Run the LR parser and build the parse tree. Returns (tree, reductions)."""
    toks = list(tokens) + [END]
    labels = labels or toks
    stack, nodes, ip, reds = [0], [], 0, []
    while True:
        s, a = stack[-1], toks[ip]
        act = lr.action.get((s, a))
        if act is None:
            raise SyntaxError(f"error at token {ip} {a}")
        if act[0] == "s":
            stack.append(act[1]); nodes.append((labels[ip], [])); ip += 1
        elif act[0] == "r":
            lhs, rhs = lr.g.prods[act[1]]
            kids = []
            for _ in rhs:
                stack.pop(); kids.insert(0, nodes.pop())
            if not rhs:
                kids = [(EPS, [])]
            reds.append(act[1])
            stack.append(lr.goto[(stack[-1], lhs)]); nodes.append((lhs, kids))
        else:
            return nodes[0], reds


def derivations(tree, nts):
    """Leftmost and rightmost derivation sentential forms from a tree."""
    def run(rightmost):
        forms = []
        form = [tree]
        while True:
            forms.append(" ".join(n[0] for n in form if n[0] != EPS) or EPS)
            idxs = [i for i, n in enumerate(form) if n[0] in nts and n[1]]
            if not idxs:
                break
            i = idxs[-1] if rightmost else idxs[0]
            kids = [k for k in form[i][1]]
            form = form[:i] + kids + form[i + 1:]
        return forms
    return run(False), run(True)


def tree_dot(tree, nts, name, title=None, highlight=None):
    lines = ["digraph T {", 'graph [ordering=out, nodesep=0.25, ranksep=0.35, fontname="Helvetica"];',
             'node [fontname="Helvetica", fontsize=12, shape=plaintext];', 'edge [arrowhead=none, color="#555555"];']
    if title:
        lines.append(f'labelloc="t"; label="{title}"; fontsize=13;')
    cnt = [0]

    def walk(n):
        my = f"n{cnt[0]}"; cnt[0] += 1
        lab = n[0].replace('"', '\\"')
        if n[0] in nts:
            col = highlight.get(n[0], "#1f4e79") if highlight else "#1f4e79"
            lines.append(f'{my} [label="{lab}", fontcolor="{col}", fontname="Helvetica-Bold"];')
        else:
            lines.append(f'{my} [label="{lab}", shape=box, style="rounded,filled", fillcolor="#f2f2f2", color="#999999"];')
        for k in n[1]:
            c = walk(k)
            lines.append(f"{my} -> {c};")
        return my
    walk(tree)
    lines.append("}")
    render_dot("\n".join(lines), name)


def render_dot(src, name):
    p = os.path.join(OUT, name)
    with open(p + ".dot", "w") as f:
        f.write(src)
    subprocess.run(["dot", "-Tpng", "-Gdpi=150", p + ".dot", "-o", p + ".png"], check=True)
