import sys, time, random
from grammar import Grammar, fmt_set, ll1_parse, EPS, END
from util import *

ORIG = """
E -> E + T | E - T | T
T -> T * F | T / F | F
F -> ( E ) | id | num
"""
TRANS = """
E -> T E'
E' -> + T E' | - T E' | ε
T -> F T'
T' -> * F T' | / F T' | ε
F -> ( E ) | id | num
"""
STMT = """
S -> if C then S S' | id = E
S' -> else S | ε
C -> E relop E
E -> T E'
E' -> + T E' | - T E' | ε
T -> F T'
T' -> * F T' | / F T' | ε
F -> ( E ) | id | num
"""
report = []

# ---------- 1. naive procedure for E -> E + T ----------
calls = [0]
def naive_E(tokens, pos):
    calls[0] += 1
    naive_E(tokens, pos)          # E -> E + T : first thing is to call E again
    # match('+'); T()  -- never reached
old = sys.getrecursionlimit()
sys.setrecursionlimit(3000)
try:
    naive_E(["id", "+", "id"], 0)
except RecursionError:
    report.append(f"naive E(): RecursionError after {calls[0]} nested calls, tokens consumed = 0")
sys.setrecursionlimit(old)

# ---------- 2. transformed grammar: FIRST / FOLLOW iterations ----------
g = Grammar(TRANS)
flog, wlog = [], []
g.compute_first(flog)
g.compute_follow(wlog)
rows = []
for A in g.nts:
    rows.append([A] + [fmt_set(it[A]) for it in flog])
save("q2_first_iter.md", md_table(["Non-terminal"] + [f"Pass {i+1}" for i in range(len(flog))], rows))
rows = []
for A in g.nts:
    rows.append([A] + [fmt_set(it[A]) for it in wlog])
save("q2_follow_iter.md", md_table(["Non-terminal"] + [f"Pass {i+1}" for i in range(len(wlog))], rows))
save("q2_sets.md", md_table(["Non-terminal", "FIRST", "FOLLOW"],
                            [(A, fmt_set(g.first[A]), fmt_set(g.follow[A])) for A in g.nts]))
report.append(f"FIRST passes = {len(flog)} (last pass confirms no change); FOLLOW passes = {len(wlog)}")

# ---------- predictive table ----------
table, conf = g.ll1_table()
terms = ["id", "num", "+", "-", "*", "/", "(", ")", "$"]
rows = []
for A in g.nts:
    rows.append([A] + [g.prod_str(table[(A, a)]).split(" → ", 1)[1].join([A + " → ", ""]) if (A, a) in table else "" for a in terms])
save("q2_table.md", md_table(["M"] + terms, rows))
report.append(f"LL(1) conflicts in transformed expression grammar = {len(conf)}; filled entries = {len(table)} of {len(g.nts)*len(terms)}")

# ---------- recursive-descent parser with call trace ----------
class RD:
    def __init__(self, toks, lex):
        self.t, self.lex, self.i, self.trace, self.depth = toks + ["$"], lex + ["$"], 0, [], 0
    def la(self): return self.t[self.i]
    def log(self, s): self.trace.append(("  " * self.depth) + s)
    def match(self, x):
        if self.la() == x:
            self.log(f"match {x}" + (f" ({self.lex[self.i]})" if x in ("id", "num") else ""))
            self.i += 1
        else:
            raise SyntaxError(f"expected '{x}' but found '{self.lex[self.i]}' at token {self.i+1}")
    def enter(self, n):
        self.log(f"{n}()  lookahead = {self.lex[self.i]}"); self.depth += 1
    def leave(self): self.depth -= 1
    # one procedure per non-terminal, returns an AST node
    def E(self):
        self.enter("E"); left = self.T(); node = self.Ep(left); self.leave(); return node
    def Ep(self, inherited):
        self.enter("E'")
        if self.la() in ("+", "-"):
            op = self.la(); self.match(op)
            right = self.T()
            node = self.Ep((op, inherited, right))      # left-associative: build first, pass down
        elif self.la() in (")", "$"):
            self.log("E' → ε"); node = inherited
        else:
            raise SyntaxError(f"E': unexpected '{self.lex[self.i]}' at token {self.i+1}; expected + - ) or end")
        self.leave(); return node
    def T(self):
        self.enter("T"); left = self.F(); node = self.Tp(left); self.leave(); return node
    def Tp(self, inherited):
        self.enter("T'")
        if self.la() in ("*", "/"):
            op = self.la(); self.match(op)
            right = self.F()
            node = self.Tp((op, inherited, right))
        elif self.la() in ("+", "-", ")", "$"):
            self.log("T' → ε"); node = inherited
        else:
            raise SyntaxError(f"T': unexpected '{self.lex[self.i]}' at token {self.i+1}; expected * / + - ) or end")
        self.leave(); return node
    def F(self):
        self.enter("F")
        if self.la() == "(":
            self.match("("); node = self.E(); self.match(")")
        elif self.la() in ("id", "num"):
            node = self.lex[self.i]; self.match(self.la())
        else:
            raise SyntaxError(f"F: unexpected '{self.lex[self.i]}' at token {self.i+1}; expected ( id num")
        self.leave(); return node

def show(n):
    return n if isinstance(n, str) else f"({show(n[1])} {n[0]} {show(n[2])})"

lex = "rate * ( p + f ) - d".split()
toks = ["id", "*", "(", "id", "+", "id", ")", "-", "id"]
p = RD(toks, lex); ast = p.E(); p.match("$")
save("q2_rd_trace.txt", "\n".join(p.trace) + "\n")
report.append(f"RD trace lines = {len(p.trace)}; AST = {show(ast)}")
calls_n = sum(1 for l in p.trace if "()" in l)
report.append(f"procedure calls = {calls_n}")

# associativity check
p2 = RD(["num", "-", "num", "-", "num"], ["10", "-", "4", "-", "3"]); a2 = p2.E()
def ev(n): return float(n) if isinstance(n, str) else {"+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b, "/": lambda a, b: a / b}[n[0]](ev(n[1]), ev(n[2]))
# a naive translation that just mirrors E' -> - T E' would build 10 - (4 - 3)
report.append(f"10 - 4 - 3: AST {show(a2)} evaluates to {ev(a2):g}; mirroring the E' tree literally gives 10 - (4 - 3) = 9")

# ---------- table-driven trace ----------
rows, ok, _ = ll1_parse(g, toks)
save("q2_ll1_trace.md", md_table(["Step", "Stack (top at right)", "Input", "Action"], [(i + 1,) + r for i, r in enumerate(rows)]))
report.append(f"table-driven parse steps = {len(rows)}, accepted = {ok}")

# ---------- error case ----------
elex = "rate * ( p + ) - d".split()
etoks = ["id", "*", "(", "id", "+", ")", "-", "id"]
rows, ok, pos = ll1_parse(g, etoks)
save("q2_err_trace.md", md_table(["Step", "Stack", "Input", "Action"], [(i + 1,) + r for i, r in enumerate(rows)]))
try:
    RD(etoks, elex).E()
except SyntaxError as e:
    report.append(f"RD error: {e}")
report.append(f"LL(1) error at token #{pos+1} '{etoks[pos]}', after {len(rows)-1} steps")

# ---------- statement grammar (left-factored) ----------
gs = Grammar(STMT)
tab_s, conf_s = gs.ll1_table(prefer={("S'", "else"): gs.alts("S'")[0][0]})
save("q2_stmt_sets.md", md_table(["Non-terminal", "FIRST", "FOLLOW"],
                                 [(A, fmt_set(gs.first[A]), fmt_set(gs.follow[A])) for A in gs.nts]))
for (A, a, p1, p2_) in conf_s:
    report.append(f"statement grammar conflict M[{A}, {a}] = {{ {gs.prod_str(p1)} , {gs.prod_str(p2_)} }}")

# ---------- non-LL(1) grammar of my own: function calls ----------
FUN = """
E -> T E'
E' -> + T E' | - T E' | ε
T -> F T'
T' -> * F T' | / F T' | ε
F -> ( E ) | id | num | id ( A )
A -> E A' | ε
A' -> , E A' | ε
"""
gf = Grammar(FUN)
_, cf = gf.ll1_table()
for (A, a, p1, p2_) in cf:
    report.append(f"function grammar conflict M[{A}, {a}] = {{ {gf.prod_str(p1)} , {gf.prod_str(p2_)} }}")
FUN2 = FUN.replace("F -> ( E ) | id | num | id ( A )", "F -> ( E ) | num | id R\nR -> ( A ) | ε")
gf2 = Grammar(FUN2)
tf2, cf2 = gf2.ll1_table()
report.append(f"left-factored function grammar: conflicts = {len(cf2)}, non-terminals = {len(gf2.nts)}, table entries = {len(tf2)}")
save("q2_fun_sets.md", md_table(["Non-terminal", "FIRST", "FOLLOW"],
                                [(A, fmt_set(gf2.first[A]), fmt_set(gf2.follow[A])) for A in gf2.nts]))

# ---------- backtracking cost experiment ----------
def bt_count(n):
    """S -> if c then S else S | if c then S | a ; tries alternatives in order, re-reading on failure."""
    toks = ["if", "c", "then"] * n + ["a"]
    reads = [0]
    def S(i):
        # alternative 1: if c then S else S
        res = []
        if i + 2 < len(toks) and toks[i] == "if":
            reads[0] += 3
            for j in S(i + 3):
                reads[0] += 1
                if j < len(toks) and toks[j] == "else":
                    res.extend(S(j + 1))
            # alternative 2: if c then S  (re-parse the same inner S from scratch)
            reads[0] += 3
            res.extend(S(i + 3))
        elif i < len(toks) and toks[i] == "a":
            reads[0] += 1
            res.append(i + 1)
        return res
    S(0)
    return reads[0], len(toks)
rows = []
for n in [1, 2, 4, 6, 8, 10, 12, 16, 20]:
    r, L = bt_count(n)
    rows.append((n, L, r, f"{r / L:.1f}"))
save("q2_backtrack.md", md_table(["Nesting depth n", "Tokens", "Token reads with backtracking", "Reads per token"], rows))
r20 = bt_count(20)[0]
report.append(f"backtracking reads at n=20: {r20}")

# ---------- speed comparison RD vs table ----------
random.seed(7)
def gen(depth):
    if depth == 0:
        return [random.choice(["id", "num"])]
    k = random.random()
    if k < 0.3:
        return ["("] + gen(depth - 1) + [")"]
    return gen(depth - 1) + [random.choice(["+", "-", "*", "/"])] + gen(depth - 1)
big = gen(12)
while len(big) < 20000:
    big = big + ["+"] + gen(10)
sys.setrecursionlimit(100000)
t0 = time.perf_counter()
for _ in range(5):
    q = RD(big, big); q.log = lambda s: None; q.E()
t_rd = (time.perf_counter() - t0) / 5
t0 = time.perf_counter()
for _ in range(5):
    # silent table-driven parse
    st = ["$", "E"]; i = 0; tk = big + ["$"]
    while st:
        X = st.pop(); a = tk[i]
        if X == a:
            i += 1; continue
        pr = table[(X, a)]
        st.extend(reversed(g.prods[pr][1]))
t_tab = (time.perf_counter() - t0) / 5
report.append(f"speed on {len(big)} tokens: RD {t_rd*1000:.1f} ms, table-driven {t_tab*1000:.1f} ms")
save("q2_report.txt", "\n".join(report) + "\n")
print("\n".join(report))
