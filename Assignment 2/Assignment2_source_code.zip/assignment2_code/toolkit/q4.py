from grammar import Grammar, LR, fmt_set, END
from util import *

rep = []
g = Grammar("""
S -> C C
C -> c C | d
""")
lr = LR(g)
# all items of the augmented grammar
items = []
for p, (lhs, rhs) in enumerate(lr.g.prods):
    for d in range(len(rhs) + 1):
        items.append(lr.item_str((p, d)))
save("q4_items.md", md_table(["#", "LR(0) item"], [(i + 1, it) for i, it in enumerate(items)]))
action, goto, conf = lr.slr()
rows = []
for i, st in enumerate(lr.states):
    kernel = [it for it in st if it[1] > 0 or it[0] == 0]
    cl = [it for it in st if it not in kernel]
    came = [f"goto(I{k}, {X})" for (k, X), t in lr.trans.items() if t == i]
    rows.append((f"I{i}", "; ".join(lr.item_str(it) for it in kernel), "; ".join(lr.item_str(it) for it in cl) or "—", ", ".join(came) or "start"))
save("q4_states.md", md_table(["State", "Kernel items", "Added by closure", "Reached by"], rows))
# DFA
dot = ['digraph D {', 'rankdir=LR; graph [fontname="Helvetica", nodesep=0.4, ranksep=0.6];',
       'node [shape=box, style="rounded,filled", fillcolor="#eef3f8", color="#1f4e79", fontname="Helvetica", fontsize=11];',
       'edge [fontname="Helvetica-Bold", fontsize=12, color="#444444"];']
for i, st in enumerate(lr.states):
    body = "\\l".join(lr.item_str(it) for it in st) + "\\l"
    fill = "#fdebd0" if any(d == len(lr.g.prods[p][1]) for p, d in st) else "#eef3f8"
    dot.append(f'I{i} [label="I{i}\\n{body}", fillcolor="{fill}"];')
for (i, X), t in lr.trans.items():
    dot.append(f'I{i} -> I{t} [label=" {X} "];')
dot.append("}")
render_dot("\n".join(dot), "fig5_dfa")
# ACTION/GOTO table
terms = ["c", "d", "$"]
rows = []
for i in range(len(lr.states)):
    r = [i]
    for a in terms:
        act = action.get((i, a))
        r.append("" if not act else ("acc" if act[0] == "acc" else f"{act[0]}{act[1]}"))
    for A in ["S", "C"]:
        r.append(goto.get((i, A), ""))
    rows.append(r)
save("q4_table.md", md_table(["State", "c", "d", "$", "GOTO S", "GOTO C"], rows))
prods = [(f"r{p}", lr.g.prod_str(p)) for p in range(1, len(lr.g.prods))]
save("q4_prods.md", md_table(["Number", "Production"], prods))
lr.g.compute_follow()
just = []
for i, st in enumerate(lr.states):
    for p, d in st:
        lhs, rhs = lr.g.prods[p]
        if d == len(rhs) and p != 0:
            just.append((f"I{i}", lr.item_str((p, d)), f"FOLLOW({lhs}) = {fmt_set(lr.g.follow[lhs])}", ", ".join(f"ACTION[{i},{a}] = r{p}" for a in sorted(lr.g.follow[lhs]))))
save("q4_justify.md", md_table(["State", "Completed item", "FOLLOW set", "Entries written"], just))
rows, ok, _ = lr.parse(["c", "d", "d"])
save("q4_parse_ok.md", md_table(["Step", "Stack (states and symbols)", "Input", "Action"], [(i + 1,) + r for i, r in enumerate(rows)]))
rep.append(f"cdd: {len(rows)} steps, accepted={ok}")
rows, ok, pos = lr.parse(["c", "d", "c"])
save("q4_parse_bad.md", md_table(["Step", "Stack (states and symbols)", "Input", "Action"], [(i + 1,) + r for i, r in enumerate(rows)]))
rep.append(f"cdc: {len(rows)} steps, accepted={ok}, error at token {pos+1}")
rep.append(f"CC grammar: LR(0) states={len(lr.states)}, SLR conflicts={len(conf)}")
s1 = LR(g).lr1()[0]
rep.append(f"CC grammar: LR(1) states={len(s1)}, LALR states={len(LR(g).lalr_states())}")

# ---------------- S -> L = R | R ----------------
h = Grammar("""
S -> L = R | R
L -> * R | id
R -> L
""")
lh = LR(h)
_, _, ch = lh.slr()
rows = []
for i, st in enumerate(lh.states):
    rows.append((f"I{i}", "; ".join(lh.item_str(it) for it in st)))
save("q4_lr_states.md", md_table(["State", "Items (kernel + closure)"], rows))
lh.g.compute_follow()
rep.append("L=R FOLLOW: " + "; ".join(f"{A}={fmt_set(lh.g.follow[A])}" for A in lh.g.nts))
for (st, a, o, n) in ch:
    rep.append(f"L=R SLR conflict: state I{st} on '{a}': {o} vs {n}; items: " + " ; ".join(lh.item_str(it) for it in lh.states[st]))
lr1 = LR(h); s1 = lr1.lr1()[0]
lal = LR(h).lalr_states()
rep.append(f"L=R: LR(0)/SLR states={len(lh.states)}, SLR conflicts={len(ch)}; LR(1) states={len(s1)}, LR(1) conflicts={lr1.lr1_conflicts(s1)}; LALR states={len(lal)}, LALR conflicts={lr1.lr1_conflicts(lal)}")
# lookaheads in the critical LR(1) state
for st in s1:
    its = sorted(st)
    if any(lr1.g.prods[p] == ("R", ("L",)) and d == 1 for p, d, _ in its) and any(lr1.g.prods[p][0] == "S" and d == 1 for p, d, _ in its):
        rep.append("LR(1) state with S → L•=R: " + " ; ".join(lr1.item_str(it) for it in its))
# canonical-LR(1) vs LALR on the Q1 rule grammar and Q2 grammar, to show the price
from q_sizes import sizes
for name, txt in sizes():
    gg = Grammar(txt); a = LR(gg); a.slr(prefer_shift=True); b = LR(gg); s = b.lr1()[0]
    c = LR(gg).lalr_states()
    terms_n = len(gg.terms) + 1; nts_n = len(gg.nts)
    rep.append(f"SIZE {name}: prods={len(gg.prods)} LR0={len(a.states)} LALR={len(c)} LR1={len(s)} cells_per_state={terms_n + nts_n} conflicts SLR/LALR/LR1={len(a.conflicts)}/{b.lr1_conflicts(c)}/{b.lr1_conflicts(s)}")
save("q4_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
