from grammar import Grammar, LR, op_precedence, op_parse, END
from util import *

EXPR = """
E -> E + T | T
T -> T * F | F
F -> ( E ) | id
"""
rep = []
g = Grammar(EXPR)
lr = LR(g); lr.slr()
toks = ["id", "+", "id", "*", "id"]
labels = ["id₁", "+", "id₂", "*", "id₃", "$"]

# --- reductions with handles (rightmost derivation in reverse) ---
toks_e = toks + [END]
stack, syms, ip, rows, sr = [0], [], 0, [], []
step = 0
while True:
    s, a = stack[-1], toks_e[ip]
    act = lr.action[(s, a)]
    stack_txt = "$ " + " ".join(syms)
    if act[0] == "s":
        sr.append((stack_txt, " ".join(labels[ip:]), "shift"))
        stack.append(act[1]); syms.append(labels[ip]); ip += 1
    elif act[0] == "r":
        lhs, rhs = lr.g.prods[act[1]]
        n = len(rhs)
        handle = syms[len(syms) - n:]
        form = " ".join(syms) + " " + " ".join(labels[ip:-1])
        step += 1
        rows.append((step, form.strip(), " ".join(handle), lr.g.prod_str(act[1]),
                     f"lookahead '{a}'"))
        sr.append((stack_txt, " ".join(labels[ip:]), f"reduce by {lr.g.prod_str(act[1])}"))
        for _ in rhs:
            stack.pop(); syms.pop()
        stack.append(lr.goto[(stack[-1], lhs)]); syms.append(lhs)
    else:
        sr.append((stack_txt, "$", "accept"))
        break
save("q3_handles.md", md_table(["#", "Right-sentential form", "Handle", "Reduce by", "Why now"], rows))
save("q3_sr.md", md_table(["Step", "Stack", "Input", "Action"], [(i + 1,) + r for i, r in enumerate(sr)]))
rep.append(f"reductions = {len(rows)}, shift-reduce steps = {len(sr)}")

# --- shift/reduce conflict grammar ---
gsr = Grammar("E -> E - E | num")
l1 = LR(gsr); _, _, c = l1.slr()
for (st, a, o, n) in c:
    rep.append(f"S/R grammar: state {st} on '{a}': {o} vs {n}; items: " + " ; ".join(l1.item_str(it) for it in l1.states[st]))
# --- reduce/reduce conflict grammar ---
grr = Grammar("""
S -> V ; | P ;
V -> id
P -> id
""")
l2 = LR(grr); _, _, c = l2.slr()
for (st, a, o, n) in c:
    rep.append(f"R/R grammar: state {st} on '{a}': {o} vs {n}; items: " + " ; ".join(l2.item_str(it) for it in l2.states[st]))

# --- operator precedence ---
OPG = """
E -> E + T | T
T -> T * P | P
P -> F ^ P | F
F -> ( E ) | id
"""
go = Grammar(OPG)
lead, trail, rel, why = op_precedence(go)
rep.append("LEADING: " + "; ".join(f"{A}={sorted(lead[A])}" for A in go.nts))
rep.append("TRAILING: " + "; ".join(f"{A}={sorted(trail[A])}" for A in go.nts))
order = ["id", "+", "*", "^", "(", ")", "$"]
rows = [[a] + [rel.get((a, b), "") for b in order] for a in order]
save("q3_prec.md", md_table(["left \\ right"] + order, rows))
save("q3_leadtrail.md", md_table(["Non-terminal", "LEADING", "TRAILING"],
                                 [(A, "{ " + ", ".join(sorted(lead[A])) + " }", "{ " + ", ".join(sorted(trail[A])) + " }") for A in go.nts]))
# reasons for a selection of entries
pick = [("+", "+"), ("+", "*"), ("*", "+"), ("^", "^"), ("*", "^"), ("^", "*"), ("(", ")"), ("id", "+"), ("$", "("), (")", "$"), ("(", "+"), ("+", ")")]
save("q3_reasons.md", md_table(["Pair", "Relation", "Derived from"], [(f"{a} , {b}", rel[(a, b)], why[(a, b)]) for a, b in pick]))
blank = sum(1 for a in order for b in order if (a, b) not in rel)
rep.append(f"precedence entries filled = {len(rel)}, blank (error) entries = {blank}")
p1 = op_parse(rel, ["id", "+", "id", "*", "id"])
p2 = op_parse(rel, ["id", "^", "id", "^", "id"])
save("q3_op1.md", md_table(["Step", "Stack", "Input", "Relation", "Action"], [(i + 1,) + r for i, r in enumerate(p1)]))
save("q3_op2.md", md_table(["Step", "Stack", "Input", "Relation", "Action"], [(i + 1,) + r for i, r in enumerate(p2)]))
# unary minus: add P -> - P alongside binary minus
OPU = OPG.replace("E -> E + T | T", "E -> E + T | E - T | T").replace("F -> ( E ) | id", "F -> ( E ) | id | - F")
try:
    op_precedence(Grammar(OPU))
    rep.append("unary minus: no clash found")
except ValueError as e:
    rep.append(f"unary minus: {e}")
save("q3_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
