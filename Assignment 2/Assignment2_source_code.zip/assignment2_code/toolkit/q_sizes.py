def sizes():
    return [
        ("CC (Q4)", "S -> C C\nC -> c C | d"),
        ("L=R (Q4)", "S -> L = R | R\nL -> * R | id\nR -> L"),
        ("Expressions (Q3)", "E -> E + T | T\nT -> T * F | F\nF -> ( E ) | id"),
        ("Rule language (Q1)", """S -> M | U
M -> if ( C ) M else M | water num ;
U -> if ( C ) S | if ( C ) M else U
C -> C || D | D
D -> D && N | N
N -> ! N | P
P -> ( C ) | id relop num | id"""),
        ("Mini-C statements (Q5)", open(__file__.replace("q_sizes.py", "minic.g")).read()),
    ]
