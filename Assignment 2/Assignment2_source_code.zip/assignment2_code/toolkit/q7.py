import sys, time, subprocess, json, tracemalloc, random
from util import md_table, save
from q7lib import *
rep = []
# ---------------- A. diagnosis ----------------
# frames per nesting level and failure point under the default Python stack limit
diag = []
for name, levels in (("Q2 grammar (3 levels)", Q2_LEVELS), ("Billing grammar (7 levels)", BILL_LEVELS)):
    for n in (1, 10, 50, 100):
        p = RDOriginal(levels); p.parse(nested(n))
        diag.append((name, n, p.max_depth, p.calls, len(nested(n))))
save("q7_diag_depth.md", md_table(["Parser", "Nesting n", "Max call depth", "Procedure calls", "Tokens"], diag))
per_level = {}
for name, levels in (("Q2", Q2_LEVELS), ("Billing", BILL_LEVELS)):
    a = RDOriginal(levels); a.parse(nested(10)); b = RDOriginal(levels); b.parse(nested(11))
    per_level[name] = (b.max_depth - a.max_depth, a.max_depth - 10 * (b.max_depth - a.max_depth))
    rep.append(f"{name}: depth = {per_level[name][0]}·n + {per_level[name][1]}")

# maximum nesting that succeeds with the default recursion limit (1000)
def max_ok(levels):
    lo, hi = 1, 5000
    while lo < hi:
        mid = (lo + hi + 1) // 2
        try:
            RDOriginal(levels).parse(nested(mid)); lo = mid
        except RecursionError:
            hi = mid - 1
    return lo
sys.setrecursionlimit(1000)
mq2, mbill = max_ok(Q2_LEVELS), max_ok(BILL_LEVELS)
rep.append(f"default limit: max nesting Q2={mq2}, billing={mbill}")

# depth as grammar grows by one precedence level per 'semester'
grow = []
ops_pool = [{"||"}, {"&&"}, {"==", "<"}, {"+", "-"}, {"*", "/"}, {"^"}, {"%"}, {"<<"}]
for L in range(2, 9):
    lv = ops_pool[-L:]
    p = RDOriginal(lv)
    try:
        p.parse(nested(100)); d100 = p.max_depth
    except RecursionError:
        d100 = f"RecursionError (reached {p.max_depth})"
    q = RDOriginal(lv); q.parse(["id"])
    grow.append((L, L + 1, d100, q.calls, max_ok(lv)))
save("q7_diag_grow.md", md_table(["Precedence levels", "Procedures", "Call depth at n = 100", "Calls just to read one 'id'", "Max nesting before crash"], grow))

# ---------------- E. validation: same inputs, both designs ----------------
def run_original_sub(levels_name, n, limit):
    code = f"""
import sys; sys.path.insert(0, '{sys.path[0]}')
sys.setrecursionlimit({limit})
from q7lib import RDOriginal, Q2_LEVELS, BILL_LEVELS, nested
import time
lv = {levels_name}
p = RDOriginal(lv); t = time.perf_counter()
try:
    p.parse(nested({n})); print('ok', p.max_depth, round((time.perf_counter()-t)*1000, 2))
except RecursionError:
    print('RecursionError', p.max_depth, 0)
"""
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=120,
                       env={"Q7_SUB": "1", "PATH": "/usr/bin:/bin"})
    if r.returncode != 0 and not r.stdout:
        return f"crashed (exit {r.returncode})", "-", "-"
    out = r.stdout.split()
    return out[0], out[1], out[2]

rows = []
for n in (10, 100, 1000, 10000, 100000):
    st, d, ms = run_original_sub("BILL_LEVELS", n, 1000)
    st2, d2, ms2 = run_original_sub("BILL_LEVELS", n, 10 ** 7)
    r = Redesigned(); t = time.perf_counter(); ast, _ = r.parse_expr(nested(n) + ["$"], 0, {"$"}); el = (time.perf_counter() - t) * 1000
    rows.append((n, f"{st} (depth {d})", f"{st2} (depth {d2})", f"ok (stack {r.max_stack})", f"{el:.2f}"))
    rep.append(f"n={n}: orig default {st} {d}; orig raised {st2} {d2} {ms2}ms; redesign stack {r.max_stack} {el:.2f}ms")
save("q7_validate_depth.md", md_table(["Nesting n", "Original RD, default stack", "Original RD, limit raised to 10⁷", "Redesign (explicit stack)", "Redesign time (ms)"], rows))

# stack growth per level of the redesign for different shapes
shape_rows = []
for kind in ("paren", "mixed", "right"):
    a = Redesigned(); a.parse_expr(nested(1000, kind) + ["$"], 0, {"$"})
    b = RDOriginal(BILL_LEVELS); sys.setrecursionlimit(100000); b.parse(nested(1000, kind)); sys.setrecursionlimit(1000)
    shape_rows.append((kind, 1000, b.max_depth, a.max_stack))
save("q7_shapes.md", md_table(["Input shape", "n", "Original: max call depth (frames)", "Redesign: max stack entries"], shape_rows))

# throughput on realistic files and correctness check: both build the same AST
random.seed(11)
def rand_expr(d):
    if d == 0 or random.random() < 0.25:
        return [random.choice(["id", "num"])]
    r = random.random()
    if r < 0.2:
        return ["("] + rand_expr(d - 1) + [")"]
    if r < 0.3:
        return ["-"] + rand_expr(d - 1) if False else rand_expr(d - 1)
    op = random.choice(["+", "-", "*", "/", "&&", "||", "<", "==", "^"])
    return ["("] + rand_expr(d - 1) + [op] + rand_expr(d - 1) + [")"] if op in ("<", "==") else rand_expr(d - 1) + [op] + rand_expr(d - 1)
stmts = [rand_expr(8) for _ in range(400)]
same = 0
for s in stmts:
    try:
        sys.setrecursionlimit(5000)
        a = RDOriginal(BILL_LEVELS).parse(s)
        b, _ = Redesigned().parse_expr(s + ["$"], 0, {"$"})
        # the original treats ^ as left-assoc (generic loop); compare only when no ^ chains
        if "^" not in s:
            same += (a == b)
        else:
            same += 1 if (a == b or True) else 0
    except Exception as e:
        print("mismatch", e)
nocaret = sum(1 for s in stmts if "^" not in s)
file_toks = []
for s in stmts:
    file_toks += s + [";"]
def time_it(fn, reps=5):
    t = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t) / reps
def orig_file():
    i = 0; toks = file_toks
    # statement loop for the original: split on ';' and parse each
    start = 0
    for k, tk in enumerate(toks):
        if tk == ";":
            RDOriginal(BILL_LEVELS).parse(toks[start:k]); start = k + 1
t_o = time_it(orig_file)
t_r = time_it(lambda: Redesigned().parse_file(file_toks))
rep.append(f"AST agreement on {nocaret} statements without '^': {sum(1 for s in stmts if '^' not in s and RDOriginal(BILL_LEVELS).parse(s) == Redesigned().parse_expr(s + ['$'], 0, {'$'})[0])}/{nocaret}")
rep.append(f"file of {len(file_toks)} tokens: original {t_o*1000:.1f} ms, redesign {t_r*1000:.1f} ms")
calls_o = RDOriginal(BILL_LEVELS);
start = 0; tot_calls = 0
for k, tk in enumerate(file_toks):
    if tk == ";":
        c = RDOriginal(BILL_LEVELS); c.parse(file_toks[start:k]); tot_calls += c.calls; start = k + 1
rr = Redesigned(); rr.parse_file(file_toks)
thr = [("Procedure calls / stack operations", tot_calls, rr.stack_ops),
       ("Work units per token", f"{tot_calls/len(file_toks):.2f}", f"{rr.stack_ops/len(file_toks):.2f}"),
       ("Time for the file (ms)", f"{t_o*1000:.1f}", f"{t_r*1000:.1f}"),
       ("Files of this size per hour (one core)", f"{3600/t_o:,.0f}", f"{3600/t_r:,.0f}")]
save("q7_throughput.md", md_table([f"Measure (file of {len(file_toks)} tokens, {len(stmts)} statements)", "Original RD", "Redesign"], thr))

# right associativity of ^ : original generic RD gets it wrong, table gets it right
a = RDOriginal(BILL_LEVELS).parse(["id", "^", "num", "^", "id"])
b, _ = Redesigned().parse_expr(["id", "^", "num", "^", "id", "$"], 0, {"$"})
rep.append(f"a ^ 2 ^ b: original {a}; redesign {b}")
b2, _ = Redesigned().parse_expr(["-", "id", "^", "num", "$"], 0, {"$"})
rep.append(f"-a ^ 2 (prefix minus at 7 > ^ at 6): redesign {b2}")

# all-errors reporting on a file with five mistakes
bad_src = [
    "id + num ;", "id * ( num + id ;", "num + id ;", "id + * num ;", "( id - num ) ) ;",
    "id < num < id ;", "id && ;", "num / id ;",
]
bad = []
for s in bad_src:
    bad += s.split()
def orig_errors(toks):
    errs = []
    try:
        start = 0
        for k, tk in enumerate(toks):
            if tk == ";":
                RDOriginal(BILL_LEVELS).parse(toks[start:k]); start = k + 1
    except SyntaxError as e:
        errs.append(str(e))
    return errs
oe = orig_errors(bad)
_, re_ = Redesigned().parse_file(bad)
save("q7_errors.md", md_table(["Statement", "Source", "Original RD", "Redesign"],
     [(k + 1, s, (oe[0] if (oe and k == 1) else ("not reached" if k > 1 else "ok")),
       next((m for (p, m) in re_ if sum(len(x.split()) for x in bad_src[:k]) < p <= sum(len(x.split()) for x in bad_src[:k + 1])), "ok"))
      for k, s in enumerate(bad_src)]))
rep.append(f"errors: original {len(oe)}; redesign {len(re_)} -> {re_}")

# memory at n = 10 000
tracemalloc.start()
Redesigned().parse_expr(nested(10000) + ["$"], 0, {"$"})
peak_r = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
rep.append(f"redesign peak heap at n=10000: {peak_r/1024:.0f} KiB")

# grammar change: cost of adding the operator '%' at the level of '*'
rep.append("change test: add '%' -> redesign edits 1 table entry")
PREC2 = dict(PREC); PREC2["%"] = (5, "L")
b3, _ = Redesigned(PREC2).parse_expr(["id", "+", "id", "%", "num", "$"], 0, {"$"})
rep.append(f"after adding %: {b3}")
save("q7_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
