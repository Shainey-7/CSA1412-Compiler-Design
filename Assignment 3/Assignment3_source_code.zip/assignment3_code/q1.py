"""Q1: S-attributed SDD for expressions, bottom-up evaluation, annotated tree, tests, counts, height."""
import random
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from attr import *

LEFT = """
E -> E + T | E - T | T
T -> T * F | T / F | F
F -> ( E ) | digit
"""
RIGHT = """
E -> T + E | T - E | T
T -> F * T | F / T | F
F -> ( E ) | digit
"""
# semantic rules, one per production (index = production number in the grammar text)
def div(a, b):
    if b == 0:
        raise ZeroDivisionError("division by zero")
    r = a / b
    return int(r) if r == int(r) else round(r, 4)

RULES_LEFT = {
    0: ("E.val = E1.val + T.val", lambda k: k[0].attrs["val"] + k[2].attrs["val"]),
    1: ("E.val = E1.val - T.val", lambda k: k[0].attrs["val"] - k[2].attrs["val"]),
    2: ("E.val = T.val",          lambda k: k[0].attrs["val"]),
    3: ("T.val = T1.val * F.val", lambda k: k[0].attrs["val"] * k[2].attrs["val"]),
    4: ("T.val = T1.val / F.val", lambda k: div(k[0].attrs["val"], k[2].attrs["val"])),
    5: ("T.val = F.val",          lambda k: k[0].attrs["val"]),
    6: ("F.val = E.val",          lambda k: k[1].attrs["val"]),
    7: ("F.val = digit.lexval",   lambda k: k[0].attrs["lexval"]),
}
RULES_RIGHT = {
    0: ("E.val = T.val + E1.val", lambda k: k[0].attrs["val"] + k[2].attrs["val"]),
    1: ("E.val = T.val - E1.val", lambda k: k[0].attrs["val"] - k[2].attrs["val"]),
    2: ("E.val = T.val",          lambda k: k[0].attrs["val"]),
    3: ("T.val = F.val * T1.val", lambda k: k[0].attrs["val"] * k[2].attrs["val"]),
    4: ("T.val = F.val / T1.val", lambda k: div(k[0].attrs["val"], k[2].attrs["val"])),
    5: ("T.val = F.val",          lambda k: k[0].attrs["val"]),
    6: ("F.val = E.val",          lambda k: k[1].attrs["val"]),
    7: ("F.val = digit.lexval",   lambda k: k[0].attrs["lexval"]),
}
PL = Parser(LEFT)
PR = Parser(RIGHT)


def evaluate(src, parser=PL, rules=RULES_LEFT, log=None):
    """parse and evaluate val and height at reduce time (post-order is forced by the LR parse)."""
    kinds, lex = tokenize(src)
    counter = {"evals": 0}

    def on_shift(n, stack):
        if n.sym == "digit":
            n.attrs["lexval"] = int(n.lexeme)
            counter["evals"] += 1
        n.attrs["height"] = 0

    def on_reduce(n, stack):
        text, fn = rules[n.prod]
        n.attrs["val"] = fn(n.children)
        n.attrs["height"] = 1 + max(c.attrs["height"] for c in n.children)
        counter["evals"] += 2                                  # val and height
        if log is not None:
            log.append((parser.g.prod_str(n.prod), text, n.attrs["val"], n.attrs["height"]))
    tree = parser.parse(kinds, lex, on_reduce=on_reduce, on_shift=on_shift)
    return tree, counter["evals"], len(kinds)


rep = []
# ---------- the shared example ----------
log = []
tree, ev, n = evaluate("3 * (4 + 5) - 6 / 2", log=log)
rep.append(f"3*(4+5)-6/2: val={tree.attrs['val']} nodes={tree.count()} height={tree.attrs['height']} evals={ev}")
save("q1_reductions.md", md_table(["#", "Reduction (post-order)", "Semantic rule applied", "val", "height"],
                                  [(i + 1, a, b, c, d) for i, (a, b, c, d) in enumerate(log)]))
annotated_dot(tree, ["val"], "fig_q1_annotated", leaf_attrs=["lexval"])
save("q1_tree.txt", "\n".join(tree.show(["val", "lexval"])) + "\n")
# shift-reduce trace with the value stack
kinds, lex = tokenize("3 * (4 + 5) - 6 / 2")
trace = []
def os_(n, st):
    if n.sym == "digit": n.attrs["lexval"] = int(n.lexeme)
def or_(n, st):
    n.attrs["val"] = RULES_LEFT[n.prod][1](n.children)
PL.parse(kinds, lex, on_reduce=or_, on_shift=os_, trace=trace)
rows = []
for k, (states, nodes, rest, act) in enumerate(trace):
    sym = " ".join(f"{x.sym}" + (f"[{x.attrs.get('val', x.attrs.get('lexval'))}]" if ('val' in x.attrs or 'lexval' in x.attrs) else "") for x in nodes)
    a = "accept" if act[0] == "acc" else (f"shift {rest[0]}" if act[0] == "s" else f"reduce {PL.lr.g.prod_str(act[1])}")
    rows.append((k + 1, "$ " + sym, " ".join(rest), a))
save("q1_sr_trace.md", md_table(["Step", "Stack (symbol[val])", "Input", "Action"], rows))

# ---------- Student B: test expressions ----------
TESTS = [
    ("T1", "single digit", "7", 7),
    ("T2", "nested brackets", "((((8))))", 8),
    ("T3", "left-assoc subtraction", "9 - 4 - 2", 3),
    ("T4", "left-assoc division", "8 / 2 / 2", 2),
    ("T5", "precedence", "2 + 3 * 4", 14),
    ("T6", "brackets override", "(2 + 3) * 4", 20),
    ("T7", "the shared example", "3 * (4 + 5) - 6 / 2", 24),
    ("T8", "long + chain", "1 + 2 + 3 + 4 + 5 + 6", 21),
    ("T9", "non-integer division", "7 / 2", 3.5),
    ("T10", "bracketed right operand", "7 - (3 - 1)", 5),
    ("T11", "invalid: operator sequence", "3 + * 4", "error"),
    ("T12", "invalid: unclosed bracket", "(5 + 2", "error"),
    ("T13", "invalid: division by zero", "4 / (2 - 2)", "error"),
]
rows = []
inst = {}
for code, kind, src, hand in TESTS:
    try:
        t, ev, n = evaluate(src)
        got = t.attrs["val"]
        rows.append((code, kind, src, hand, got, "match" if got == hand else "MISMATCH", t.count(), ev))
        inst[code] = t
    except (SyntaxError, ZeroDivisionError) as e:
        rows.append((code, kind, src, hand, f"rejected: {e}", "match" if hand == "error" else "MISMATCH", "-", "-"))
save("q1_tests.md", md_table(["#", "Purpose", "Expression", "Hand value", "Program output", "Result", "Nodes", "Attr. evals"], rows))
save("q1_instrumented_T3.txt", "\n".join(inst["T3"].show(["val", "lexval", "height"])) + "\n")
save("q1_instrumented_T6.txt", "\n".join(inst["T6"].show(["val", "lexval", "height"])) + "\n")
rep.append(f"tests: {sum(1 for r in rows if r[5]=='match')}/{len(rows)} match")

# ---------- counts vs length ----------
random.seed(3)
def chain(k, op="+"):
    return f" {op} ".join(str(random.randint(1, 9)) for _ in range(k))
def randexpr(depth):
    if depth == 0 or random.random() < 0.3:
        return str(random.randint(1, 9))
    if random.random() < 0.2:
        return "(" + randexpr(depth - 1) + ")"
    return randexpr(depth - 1) + random.choice(["+", "-", "*"]) + randexpr(depth - 1)
rows = []
for k in (1, 2, 4, 8, 16, 32, 64):
    t, ev, n = evaluate(chain(k))
    rows.append(("+ chain", n, t.count(), sum(1 for x in t.walk() if x.children), ev, f"{t.count()/n:.2f}"))
for k in (2, 8, 32):
    t, ev, n = evaluate(chain(k, "*"))
    rows.append(("* chain", n, t.count(), sum(1 for x in t.walk() if x.children), ev, f"{t.count()/n:.2f}"))
for d in (2, 4, 6, 8):
    s = randexpr(d)
    while len(tokenize(s)[0]) < 2 * d:
        s = randexpr(d)
    t, ev, n = evaluate(s)
    rows.append(("random", n, t.count(), sum(1 for x in t.walk() if x.children), ev, f"{t.count()/n:.2f}"))
save("q1_counts.md", md_table(["Shape", "Tokens n", "Parse-tree nodes", "Interior nodes (val computed)", "Attribute evaluations", "Nodes per token"], rows))

# ---------- height: left vs right recursive ----------
rows = []
for src in ["9 - 4 - 2", "2 + 3 * 4", "1 + 2 + 3 + 4", "8 / 2 / 2", "3 * (4 + 5) - 6 / 2"]:
    tl, _, _ = evaluate(src)
    tr, _, _ = evaluate(src, PR, RULES_RIGHT)
    rows.append((src, tl.attrs["height"], tr.attrs["height"], tl.attrs["val"], tr.attrs["val"],
                 "same" if tl.attrs["val"] == tr.attrs["val"] else "DIFFERENT"))
save("q1_lr_height.md", md_table(["Expression", "Height (left-recursive)", "Height (right-recursive)", "val (left)", "val (right, naive rules)", "Values"], rows))
tl, _, _ = evaluate("9 - 4 - 2"); tr, _, _ = evaluate("9 - 4 - 2", PR, RULES_RIGHT)
annotated_dot(tl, ["val", "height"], "fig_q1_left_942")
annotated_dot(tr, ["val", "height"], "fig_q1_right_942")

# ---------- Student A: height experiment ----------
series = {"+ chain (1+1+…)": [], "* chain (1*1*…)": [], "nested brackets ((…1…))": [], "random expressions": []}
for k in range(1, 41, 3):
    t, _, n = evaluate(" + ".join(["1"] * k)); series["+ chain (1+1+…)"].append((n, t.attrs["height"]))
    t, _, n = evaluate(" * ".join(["1"] * k)); series["* chain (1*1*…)"].append((n, t.attrs["height"]))
for k in range(0, 14):
    t, _, n = evaluate("(" * k + "1" + ")" * k); series["nested brackets ((…1…))"].append((n, t.attrs["height"]))
random.seed(5)
for _ in range(60):
    s = randexpr(7)
    t, _, n = evaluate(s); series["random expressions"].append((n, t.attrs["height"]))
fig, ax = plt.subplots(figsize=(7, 4.2), dpi=150)
marks = {"+ chain (1+1+…)": "o-", "* chain (1*1*…)": "s-", "nested brackets ((…1…))": "^-", "random expressions": "."}
for name, pts in series.items():
    pts.sort()
    xs, ys = zip(*pts)
    ax.plot(xs, ys, marks[name], label=name, markersize=4 if name != "random expressions" else 6, linewidth=1.3)
ax.set_xlabel("expression length (tokens)")
ax.set_ylabel("parse-tree height")
ax.grid(alpha=0.3)
ax.legend(frameon=False, fontsize=8.5)
ax.set_title("Parse-tree height vs expression length (left-recursive grammar)", fontsize=10)
fig.tight_layout(); fig.savefig(OUT + "/fig_q1_height.png")
rows = []
for k in (1, 2, 4, 8, 16, 32):
    a = evaluate(" + ".join(["1"] * k)); b = evaluate(" * ".join(["1"] * k)); c = evaluate("(" * k + "1" + ")" * k)
    rows.append((k, a[2], a[0].attrs["height"], b[2], b[0].attrs["height"], c[2], c[0].attrs["height"]))
save("q1_height_table.md", md_table(["k", "tokens (+ chain)", "height", "tokens (* chain)", "height", "tokens (k brackets)", "height"], rows))
save("q1_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
