"""Q5: AST construction with node / mkNode / mkLeaf - bottom-up (synthesized) and top-down (E'.inh)."""
import tracemalloc, random, sys
sys.setrecursionlimit(100000)
from attr import *
from attr import tokenize as _tok
def tokenize(src):
    k, l = _tok(src)
    return ['num' if x == 'digit' else x for x in k], l

ASSIGN = """
S -> id = E
E -> E + T | E - T | T
T -> T * F | T / F | F
F -> ( E ) | id | num
"""
P = Parser(ASSIGN)


class AST:
    __slots__ = ("op", "kids", "entry", "pid")
    def __init__(self, op, kids=(), entry=None):
        self.op, self.kids, self.entry = op, list(kids), entry
    def count(self):
        return 1 + sum(k.count() for k in self.kids)
    def height(self):
        return 0 if not self.kids else 1 + max(k.height() for k in self.kids)
    def s(self):
        return self.entry if not self.kids else f"({self.op} " + " ".join(k.s() for k in self.kids) + ")"


class Builder:
    """mkNode / mkLeaf with a log so the construction can be shown step by step."""
    def __init__(self, keep_log=True):
        self.log, self.n, self.keep = [], 0, keep_log
    def mkLeaf(self, kind, entry):
        self.n += 1; a = AST(kind, entry=entry); a.pid = f"p{self.n}"
        if self.keep: self.log.append(f"{a.pid} = mkLeaf({kind}, {entry})")
        return a
    def mkNode(self, op, l, r):
        self.n += 1; a = AST(op, [l, r]); a.pid = f"p{self.n}"
        if self.keep: self.log.append(f"{a.pid} = mkNode('{op}', {l.pid}, {r.pid})")
        return a


RULES = {   # production index -> semantic rule text
    0: "S.node = mkNode('=', mkLeaf(id, id.entry), E.node)",
    1: "E.node = mkNode('+', E1.node, T.node)",
    2: "E.node = mkNode('-', E1.node, T.node)",
    3: "E.node = T.node",
    4: "T.node = mkNode('*', T1.node, F.node)",
    5: "T.node = mkNode('/', T1.node, F.node)",
    6: "T.node = F.node",
    7: "F.node = E.node",
    8: "F.node = mkLeaf(id, id.entry)",
    9: "F.node = mkLeaf(num, num.val)",
}


def build_bottom_up(src, b=None, log=None):
    b = b or Builder()
    kinds, lex = tokenize(src)
    def on_reduce(n, stack):
        k = n.children
        p = n.prod
        if p == 0:
            n.attrs["node"] = b.mkNode("=", b.mkLeaf("id", k[0].lexeme), k[2].attrs["node"])
        elif p in (1, 2, 4, 5):
            n.attrs["node"] = b.mkNode(k[1].sym, k[0].attrs["node"], k[2].attrs["node"])
        elif p in (3, 6):
            n.attrs["node"] = k[0].attrs["node"]
        elif p == 7:
            n.attrs["node"] = k[1].attrs["node"]
        elif p == 8:
            n.attrs["node"] = b.mkLeaf("id", k[0].lexeme)
        elif p == 9:
            n.attrs["node"] = b.mkLeaf("num", k[0].lexeme)
        n.attrs["ptr"] = n.attrs["node"].pid
        if log is not None:
            log.append((P.g.prod_str(p), RULES[p], n.attrs["ptr"]))
    tree = P.parse(kinds, lex, on_reduce=on_reduce)
    return tree, tree.attrs["node"], b


class TopDown:
    """S -> id = E
       E  -> T  E'      { E'.inh = T.node ;  E.node = E'.syn }
       E' -> + T E1'    { E1'.inh = mkNode('+', E'.inh, T.node) ; E'.syn = E1'.syn }
           | - T E1'    { E1'.inh = mkNode('-', E'.inh, T.node) ; E'.syn = E1'.syn }
           | ε          { E'.syn = E'.inh }
       T  -> F  T'      { T'.inh = F.node ;  T.node = T'.syn }
       T' -> * F T1'  | / F T1' | ε   (same pattern)
       F  -> ( E ) | id | num"""
    def __init__(self, src, b=None):
        self.k, self.l = tokenize(src); self.k.append("$"); self.l.append("$"); self.i = 0
        self.b = b or Builder(); self.trace = []; self.keep = self.b.keep
    def la(self): return self.k[self.i]
    def eat(self, t):
        if self.la() != t: raise SyntaxError(f"expected {t}, found {self.l[self.i]}")
        lx = self.l[self.i]; self.i += 1; return lx
    def S(self):
        name = self.eat("id"); self.eat("=")
        e = self.E(); return self.b.mkNode("=", self.b.mkLeaf("id", name), e)
    def E(self):
        t = self.T(); return self.Ep(t)
    def Ep(self, inh):
        if self.la() in "+-":
            op = self.eat(self.la()); t = self.T()
            new = self.b.mkNode(op, inh, t)
            if self.keep: self.trace.append(f"E'.inh = {inh.pid}  →  E1'.inh = mkNode('{op}', {inh.pid}, {t.pid}) = {new.pid}")
            return self.Ep(new)
        if self.keep: self.trace.append(f"E' → ε : E'.syn = E'.inh = {inh.pid}")
        return inh
    def T(self):
        f = self.F(); return self.Tp(f)
    def Tp(self, inh):
        if self.la() in "*/":
            op = self.eat(self.la()); f = self.F()
            new = self.b.mkNode(op, inh, f)
            if self.keep: self.trace.append(f"T'.inh = {inh.pid}  →  T1'.inh = mkNode('{op}', {inh.pid}, {f.pid}) = {new.pid}")
            return self.Tp(new)
        if self.keep: self.trace.append(f"T' → ε : T'.syn = T'.inh = {inh.pid}")
        return inh
    def F(self):
        if self.la() == "(":
            self.eat("("); e = self.E(); self.eat(")"); return e
        if self.la() == "num":
            return self.b.mkLeaf("num", self.eat("num"))
        return self.b.mkLeaf("id", self.eat("id"))


def ast_dot(a, name):
    L = ['digraph A {', 'graph [ordering=out, nodesep=0.3, ranksep=0.4];', 'node [fontname="Helvetica", fontsize=12];', 'edge [color="#555555", arrowsize=0.6];']
    def w(x):
        if x.kids:
            L.append(f'{x.pid} [label="{x.op}\\n({x.pid})", shape=circle, style=filled, fillcolor="#eef3f8", color="#1f4e79", fontsize=11];')
            for k in x.kids:
                w(k); L.append(f"{x.pid} -> {k.pid};")
        else:
            L.append(f'{x.pid} [label="{x.op} {x.entry}\\n({x.pid})", shape=box, style="rounded,filled", fillcolor="#f2f2f2", color="#999999", fontsize=10.5];')
    w(a); L.append("}"); render("\n".join(L), name)


rep = []
log = []
tree, ast, b = build_bottom_up("a = b + c * d", log=log)
save("q5_bu_steps.md", md_table(["#", "Reduction", "Semantic rule", "node (pointer)"], [(i + 1,) + r for i, r in enumerate(log)]))
save("q5_bu_calls.txt", "\n".join(b.log) + "\n")
annotated_dot(tree, ["ptr"], "fig_q5_parsetree")
ast_dot(ast, "fig_q5_ast")
save("q5_parsetree.txt", "\n".join(tree.show()) + "\n")
rep.append(f"a = b + c * d: parse-tree nodes={tree.count()} AST nodes={ast.count()} AST={ast.s()}")
td = TopDown("a = b + c * d"); ast2 = td.S()
save("q5_td_calls.txt", "\n".join(td.b.log) + "\n")
save("q5_td_trace.txt", "\n".join(td.trace) + "\n")
rep.append(f"top-down AST = {ast2.s()} identical={ast2.s() == ast.s()}")

# left-assoc check top-down
for src in ["x = a - b - c", "x = a / b / c", "x = (a + b) * (c - d)"]:
    _, a1, _ = build_bottom_up(src); a2 = TopDown(src).S()
    rep.append(f"{src}: bottom-up {a1.s()} | top-down {a2.s()} | same={a1.s()==a2.s()}")

# Student B: node counts and growth
random.seed(4)
def rexp(d):
    if d == 0 or random.random() < 0.25:
        return random.choice(["a", "b", "c", "x", "7", "42"])
    if random.random() < 0.25:
        return "(" + rexp(d - 1) + ")"
    return rexp(d - 1) + " " + random.choice("+-*/") + " " + rexp(d - 1)
rows = []
inputs = [("x = a", "single operand"), ("x = a + b", "one operator"), ("x = a + b * c", "precedence"),
          ("x = (a + b) * c", "brackets"), ("x = ((((a))))", "redundant brackets"),
          ("x = a + b + c + d + e + f + g + h", "8-term chain")]
for src, why in inputs:
    t, a, _ = build_bottom_up(src)
    kinds, _ = tokenize(src)
    rows.append((why, src, len(kinds), t.count(), a.count(), t.count() - a.count(), f"{t.count()/a.count():.2f}"))
for need in (25, 50, 100, 200, 400, 800):
    s = rexp(3)
    while len(tokenize(s)[0]) < need:
        s = s + " " + random.choice("+-*/") + " " + rexp(4)
    s = "x = " + s
    t, a, _ = build_bottom_up(s)
    rows.append(("random", f"({len(tokenize(s)[0])} tokens)", len(tokenize(s)[0]), t.count(), a.count(), t.count() - a.count(), f"{t.count()/a.count():.2f}"))
save("q5_counts.md", md_table(["Input type", "Input", "Tokens", "Parse-tree nodes", "AST nodes", "Removed", "Ratio"], rows))

# which nodes are removed: classify parse-tree nodes with no AST counterpart
t, a, _ = build_bottom_up("x = (a + b) * c")
kinds_removed = {}
for n in t.walk():
    if n.is_leaf():
        key = f"terminal '{n.lexeme}'" if n.sym in "()=+-*/" else None
        if n.sym in ("(", ")"):
            kinds_removed["brackets ( )"] = kinds_removed.get("brackets ( )", 0) + 1
        elif n.sym in "+-*/=":
            kinds_removed["operator tokens (become the op field of an interior AST node)"] = kinds_removed.get("operator tokens (become the op field of an interior AST node)", 0) + 1
        else:
            kinds_removed["id/num tokens (become the entry of a leaf)"] = kinds_removed.get("id/num tokens (become the entry of a leaf)", 0) + 1
    elif len(n.children) == 1 or (n.prod == 7):
        kinds_removed["chain / bracket non-terminals (E→T, T→F, F→(E), F→id)"] = kinds_removed.get("chain / bracket non-terminals (E→T, T→F, F→(E), F→id)", 0) + 1
    else:
        kinds_removed["binary non-terminals (kept as AST operator nodes)"] = kinds_removed.get("binary non-terminals (kept as AST operator nodes)", 0) + 1
save("q5_removed.md", md_table(["Parse-tree node kind in x = (a + b) * c", "Count"], sorted(kinds_removed.items())))
rep.append(f"x=(a+b)*c parse nodes {t.count()}, AST {a.count()}")

# memory
rows = []
for need in (100, 1000, 10000):
    random.seed(need)
    s = rexp(3)
    while len(tokenize(s)[0]) < need:
        s = s + " " + random.choice("+-*/") + " " + rexp(4)
    s = "x = " + s
    kinds, lex = tokenize(s)
    tracemalloc.start()
    t = P.parse(kinds, lex)
    pt_mem = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    del t
    tracemalloc.start()
    keep = TopDown(s, Builder(keep_log=False)).S()
    ast_mem = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    tt = P.parse(kinds, lex)
    rows.append((len(kinds), tt.count(), f"{pt_mem/1024:.0f} KiB", keep.count(), f"{ast_mem/1024:.0f} KiB", f"{pt_mem/ast_mem:.2f}×"))
save("q5_memory.md", md_table(["Tokens", "Parse-tree nodes", "Parse-tree memory", "AST nodes", "AST memory", "Ratio"], rows))
save("q5_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
