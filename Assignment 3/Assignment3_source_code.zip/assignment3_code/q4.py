"""Q4: postfix SDT executed at reduce time, action placement, mid-production actions, left-recursion removal."""
from attr import *

POSTFIX = """
E -> E + T | E - T | T
T -> T * F | T / F | F
F -> ( E ) | id
"""
ACTIONS = {0: "+", 1: "-", 3: "*", 4: "/"}         # print(op) at the END of these productions
P = Parser(POSTFIX)


def to_postfix(src, parser=P, actions=ACTIONS, log=None):
    kinds, lex = tokenize(src)
    out, count = [], [0]

    def on_reduce(n, stack):
        if n.prod in actions:
            a = actions[n.prod]
            if a is not None:
                out.append(a); count[0] += 1
                if log is not None: log.append((parser.g.prod_str(n.prod), f"print('{a}')", " ".join(out)))
        elif parser.g.prods[n.prod][1] == ("id",):
            out.append(n.children[0].lexeme); count[0] += 1
            if log is not None: log.append((parser.g.prod_str(n.prod), f"print('{n.children[0].lexeme}')", " ".join(out)))
    parser.parse(kinds, lex, on_reduce=on_reduce)
    return " ".join(out), count[0], len(kinds)


def shunting(src):
    """independent reference: Dijkstra's shunting-yard."""
    kinds, lex = tokenize(src)
    prec = {"+": 1, "-": 1, "*": 2, "/": 2}
    out, ops = [], []
    for k, t in zip(kinds, lex):
        if k == "id":
            out.append(t)
        elif t in prec:
            while ops and ops[-1] in prec and prec[ops[-1]] >= prec[t]:
                out.append(ops.pop())
            ops.append(t)
        elif t == "(":
            ops.append(t)
        elif t == ")":
            while ops[-1] != "(":
                out.append(ops.pop())
            ops.pop()
    while ops:
        out.append(ops.pop())
    return " ".join(out)


rep = []
log = []
res, cnt, n = to_postfix("a + b * (c - d)", log=log)
rep.append(f"a + b * (c - d) -> {res} ({cnt} actions)")
save("q4_actions_log.md", md_table(["#", "Reduction", "Action executed", "Output so far"], [(i + 1,) + r for i, r in enumerate(log)]))

TESTS = [
    ("P1", "given expression", "a + b * (c - d)"),
    ("P2", "precedence * over +", "a + b * c"),
    ("P3", "precedence, operands swapped", "a * b + c"),
    ("P4", "left associativity of -", "a - b - c"),
    ("P5", "left associativity of /", "a / b / c"),
    ("P6", "parentheses force right grouping", "a - (b - c)"),
    ("P7", "two bracketed groups", "(a + b) * (c - d)"),
    ("P8", "redundant brackets", "((a))"),
    ("P9", "mixed, longer", "a * b - c / d + e"),
    ("P10", "single operand", "x"),
]
rows = []
for code, purpose, src in TESTS:
    got, cnt, n = to_postfix(src)
    ref = shunting(src)
    rows.append((code, purpose, src, got, ref, "match" if got == ref else "MISMATCH", cnt))
save("q4_tests.md", md_table(["#", "Purpose", "Infix", "SDT output", "Reference (shunting-yard)", "Result", "Actions"], rows))
rep.append(f"tests {sum(r[5]=='match' for r in rows)}/{len(rows)}")

# parse tree with action nodes, numbered in execution order
kinds, lex = tokenize("a + b * (c - d)")
tree = P.parse(kinds, lex)
counter = [0]
def add_actions(n):
    for c in n.children:
        add_actions(c)
    if n.prod is not None:
        a = ACTIONS.get(n.prod)
        if a is None and P.g.prods[n.prod][1] == ("id",):
            a = n.children[0].lexeme
        if a is not None:
            counter[0] += 1
            act = Node(f"{counter[0]}: print('{a}')"); act.is_action = True
            n.children.append(act)
add_actions(tree)
L = ['digraph T {', 'graph [ordering=out, nodesep=0.2, ranksep=0.35];', 'node [fontname="Helvetica", fontsize=11, shape=plaintext];', 'edge [arrowhead=none, color="#777777"];']
for x in tree.walk():
    if getattr(x, "is_action", False):
        L.append(f'n{x.uid} [label="{{{esc(x.sym)}}}", shape=box, style="rounded,filled", fillcolor="#e8f4e8", color="#3a7a3a", fontcolor="#1e4d1e"];')
    elif x.is_leaf():
        L.append(f'n{x.uid} [label="{esc(x.lexeme or x.sym)}", shape=box, style="rounded,filled", fillcolor="#f2f2f2", color="#999999"];')
    else:
        L.append(f'n{x.uid} [label="{x.sym}", fontname="Helvetica-Bold", fontcolor="#1f4e79"];')
    for c in x.children:
        st = ', style=dashed, color="#3a7a3a"' if getattr(c, "is_action", False) else ""
        L.append(f"n{x.uid} -> n{c.uid} [{st.strip(', ')}];")
L.append("}")
render("\n".join(L), "fig_q4_actions")

# mid-production action through a marker (bottom-up)
MID = """
E -> E + M T | E - N T | T
T -> T * F | T / F | F
F -> ( E ) | id
M -> ε
N -> ε
"""
PM = Parser(MID)
mid_actions = {0: None, 1: None, 3: "*", 4: "/", 8: "+", 9: "-"}
rows = []
for src in ["a + b * c", "a + b * (c - d)", "a - b - c", "a * b + c"]:
    end, _, _ = to_postfix(src)
    mid, _, _ = to_postfix(src, PM, mid_actions)
    rows.append((src, end, mid))
_, _, mconf = PM.lr.slr(prefer_shift=False)
save("q4_mid.md", md_table(["Infix", "print at end of E → E + T (postfix)", "print between + and T (marker M → ε)"], rows))
rep.append(f"marker grammar SLR conflicts = {len(mconf)}")

# action counts vs size
rows = []
import random
random.seed(9)
def rexp(d):
    if d == 0 or random.random() < 0.25:
        return random.choice("abcdxyz")
    if random.random() < 0.2:
        return "(" + rexp(d - 1) + ")"
    return rexp(d - 1) + random.choice(" + - * / ".split()) + rexp(d - 1)
for k in (1, 2, 4, 8, 16, 32, 64):
    src = " + ".join(["a"] * k)
    out, cnt, n = to_postfix(src)
    rows.append(("+ chain", n, cnt, len(out.split()), n - src.count("(") - src.count(")")))
for d, need in ((3, 5), (5, 11), (7, 25), (9, 51), (11, 101)):
    src = rexp(d)
    while len(tokenize(src)[0]) < need:
        src = rexp(d)
    out, cnt, n = to_postfix(src)
    rows.append(("random", n, cnt, len(out.split()), n - src.count("(") - src.count(")")))
save("q4_counts.md", md_table(["Shape", "Input tokens", "Actions executed", "Output symbols", "Tokens excluding brackets"], rows))

# compare with Q1 evaluation order
src = "3 * (4 + 5) - 6 / 2"
pf, _, _ = to_postfix(src.replace("3", "x3").replace("4", "x4").replace("5", "x5").replace("6", "x6").replace("2", "x2"))
pf_digits = pf.replace("x", "")
st = []
steps = []
for t in pf_digits.split():
    if t.isdigit():
        st.append(int(t))
    else:
        b, a = st.pop(), st.pop()
        st.append({"+": a + b, "-": a - b, "*": a * b, "/": a / b}[t]); steps.append(f"{a}{t}{b}={st[-1]:g}")
rep.append(f"Q1 compare: postfix of {src} = {pf_digits}; stack evaluation -> {st[0]:g}; operator order {', '.join(steps)}")

# left recursion removed: predictive translator with actions in the middle
class RDPostfix:
    """E -> T R ;  R -> + T {print '+'} R | - T {print '-'} R | ε
       T -> F S ;  S -> * F {print '*'} S | / F {print '/'} S | ε ;  F -> ( E ) | id {print id}"""
    def __init__(self, src):
        self.k, self.l = tokenize(src); self.k.append("$"); self.l.append("$"); self.i = 0; self.out = []; self.calls = 0
    def la(self): return self.k[self.i]
    def eat(self, t):
        if self.la() != t: raise SyntaxError(f"expected {t} found {self.l[self.i]} (output so far: '{' '.join(self.out)}')")
        self.i += 1
    def E(self): self.calls += 1; self.T(); self.R()
    def R(self):
        self.calls += 1
        if self.la() in "+-":
            op = self.la(); self.eat(op); self.T(); self.out.append(op); self.R()
    def T(self): self.calls += 1; self.F(); self.S()
    def S(self):
        self.calls += 1
        if self.la() in "*/":
            op = self.la(); self.eat(op); self.F(); self.out.append(op); self.S()
    def F(self):
        self.calls += 1
        if self.la() == "(":
            self.eat("("); self.E(); self.eat(")")
        else:
            name = self.l[self.i]; self.eat("id"); self.out.append(name)
rows = []
for code, purpose, src in TESTS:
    r = RDPostfix(src); r.E(); r.eat("$")
    rows.append((code, src, " ".join(r.out), to_postfix(src)[0], "same" if " ".join(r.out) == to_postfix(src)[0] else "DIFFERENT"))
save("q4_rd.md", md_table(["#", "Infix", "Right-recursive SDT (top-down)", "Left-recursive postfix SDT (bottom-up)", "Agreement"], rows))

# practical difficulty: output already emitted before an error is found
for src in ["a + b * ) c", "a * (b + c"]:
    try:
        to_postfix(src)
    except SyntaxError as e:
        out = []
        kinds, lex = tokenize(src)
        def onr(n, s):
            if n.prod in ACTIONS: out.append(ACTIONS[n.prod])
            elif P.g.prods[n.prod][1] == ("id",): out.append(n.children[0].lexeme)
        try:
            P.parse(kinds, lex, on_reduce=onr)
        except SyntaxError:
            pass
        rep.append(f"ERROR CASE '{src}': {e}; already printed: '{' '.join(out)}'")
save("q4_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
