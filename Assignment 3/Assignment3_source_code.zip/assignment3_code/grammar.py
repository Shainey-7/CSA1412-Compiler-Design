"""
Small parsing toolkit written for Assignment 2 (Compiler Design, Unit II).
Grammar representation, FIRST/FOLLOW, LL(1) tables and parser,
LR(0)/SLR(1)/LR(1)/LALR(1) construction, operator-precedence relations.
"""
from collections import OrderedDict

EPS = "ε"
END = "$"


class Grammar:
    def __init__(self, text, start=None):
        self.prods = []                 # list of (lhs, tuple(rhs))
        self.nts = []                   # ordered non-terminals
        for line in text.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            lhs, rhs = line.split("->")
            lhs = lhs.strip()
            if lhs not in self.nts:
                self.nts.append(lhs)
            for alt in rhs.split(" | "):
                syms = tuple(s for s in alt.split() if s != EPS)
                self.prods.append((lhs, syms))
        self.start = start or self.nts[0]
        syms = []
        for _, rhs in self.prods:
            for s in rhs:
                if s not in self.nts and s not in syms:
                    syms.append(s)
        self.terms = syms

    def is_nt(self, s):
        return s in self.nts

    def prod_str(self, i):
        lhs, rhs = self.prods[i]
        return f"{lhs} → {' '.join(rhs) if rhs else EPS}"

    def alts(self, A):
        return [(i, r) for i, (l, r) in enumerate(self.prods) if l == A]

    # ---------------- FIRST / FOLLOW with iteration logs ----------------
    def compute_first(self, log=None):
        first = {A: set() for A in self.nts}
        rnd = 0
        changed = True
        while changed:
            changed = False
            rnd += 1
            for A, rhs in self.prods:
                add = self.first_of_seq(rhs, first)
                if not add <= first[A]:
                    first[A] |= add
                    changed = True
            if log is not None:
                log.append({A: set(first[A]) for A in self.nts})
        self.first = first
        return first

    def first_of_seq(self, seq, first=None):
        first = first if first is not None else self.first
        out = set()
        for s in seq:
            if not self.is_nt(s):
                out.add(s)
                return out
            out |= first[s] - {EPS}
            if EPS not in first[s]:
                return out
        out.add(EPS)
        return out

    def compute_follow(self, log=None):
        follow = {A: set() for A in self.nts}
        follow[self.start].add(END)
        changed = True
        while changed:
            changed = False
            for A, rhs in self.prods:
                for i, B in enumerate(rhs):
                    if not self.is_nt(B):
                        continue
                    f = self.first_of_seq(rhs[i + 1:])
                    add = f - {EPS}
                    if EPS in f:
                        add |= follow[A]
                    if not add <= follow[B]:
                        follow[B] |= add
                        changed = True
            if log is not None:
                log.append({A: set(follow[A]) for A in self.nts})
        self.follow = follow
        return follow

    # ---------------- LL(1) ----------------
    def ll1_table(self, prefer=None):
        """prefer: dict {(A,a): prod_index} used to resolve a known conflict."""
        self.compute_first()
        self.compute_follow()
        table, conflicts = {}, []
        for i, (A, rhs) in enumerate(self.prods):
            f = self.first_of_seq(rhs)
            targets = (f - {EPS}) | (self.follow[A] if EPS in f else set())
            for a in targets:
                if (A, a) in table and table[(A, a)] != i:
                    conflicts.append((A, a, table[(A, a)], i))
                    if prefer and (A, a) in prefer:
                        table[(A, a)] = prefer[(A, a)]
                    continue
                table[(A, a)] = i
        self.table = table
        return table, conflicts

    # ---------------- LR(0) items ----------------
    def augmented(self):
        g = Grammar.__new__(Grammar)
        g.prods = [(self.start + "'", (self.start,))] + list(self.prods)
        g.nts = [self.start + "'"] + list(self.nts)
        g.terms = list(self.terms)
        g.start = self.start + "'"
        return g


def fmt_set(s):
    order = lambda x: (x == EPS, x == END, x)
    return "{ " + ", ".join(sorted(s, key=order)) + " }" if s else "∅"


# ===================== LR machinery =====================
class LR:
    def __init__(self, grammar):
        self.g0 = grammar
        self.g = grammar.augmented()
        self.g.compute_first()
        self.g.compute_follow()

    # LR(0) item = (prod_index, dot)
    def item_str(self, it):
        p, d = it[0], it[1]
        lhs, rhs = self.g.prods[p]
        r = list(rhs)
        r.insert(d, "•")
        s = f"{lhs} → {' '.join(r)}"
        if len(it) == 3:
            s += f", {it[2]}"
        return s

    def closure0(self, items):
        res = list(items)
        i = 0
        while i < len(res):
            p, d = res[i]
            rhs = self.g.prods[p][1]
            if d < len(rhs) and self.g.is_nt(rhs[d]):
                for q, _ in self.g.alts(rhs[d]):
                    if (q, 0) not in res:
                        res.append((q, 0))
            i += 1
        return tuple(res)

    def goto0(self, state, X):
        moved = [(p, d + 1) for (p, d) in state
                 if d < len(self.g.prods[p][1]) and self.g.prods[p][1][d] == X]
        return self.closure0(moved) if moved else None

    def symbols(self):
        return self.g.terms + [n for n in self.g.nts if n != self.g.start]

    def lr0(self):
        states = [self.closure0([(0, 0)])]
        trans = {}
        i = 0
        while i < len(states):
            for X in self.symbols():
                nxt = self.goto0(states[i], X)
                if nxt is None:
                    continue
                key = frozenset(nxt)
                idx = next((k for k, s in enumerate(states) if frozenset(s) == key), None)
                if idx is None:
                    states.append(nxt)
                    idx = len(states) - 1
                trans[(i, X)] = idx
            i += 1
        self.states, self.trans = states, trans
        return states, trans

    def slr(self, prefer_shift=False):
        self.lr0()
        action, goto, conflicts = {}, {}, []
        why = {}
        for i, st in enumerate(self.states):
            for (p, d) in st:
                lhs, rhs = self.g.prods[p]
                if d < len(rhs):
                    a = rhs[d]
                    if not self.g.is_nt(a):
                        self._set(action, conflicts, i, a, ("s", self.trans[(i, a)]), prefer_shift)
                elif p == 0:
                    self._set(action, conflicts, i, END, ("acc",), prefer_shift)
                else:
                    for a in sorted(self.g.follow[lhs]):
                        self._set(action, conflicts, i, a, ("r", p), prefer_shift)
                        why[(i, a)] = lhs
            for A in self.g.nts:
                if (i, A) in self.trans:
                    goto[(i, A)] = self.trans[(i, A)]
        self.action, self.goto, self.conflicts, self.why = action, goto, conflicts, why
        return action, goto, conflicts

    def _set(self, action, conflicts, i, a, act, prefer_shift):
        if (i, a) in action and action[(i, a)] != act:
            old = action[(i, a)]
            conflicts.append((i, a, old, act))
            if prefer_shift and act[0] == "s":
                action[(i, a)] = act
            return
        action[(i, a)] = act

    # ---------------- LR(1) canonical and LALR merge ----------------
    def closure1(self, items):
        res = list(items)
        i = 0
        while i < len(res):
            p, d, la = res[i]
            rhs = self.g.prods[p][1]
            if d < len(rhs) and self.g.is_nt(rhs[d]):
                firsts = self.g.first_of_seq(list(rhs[d + 1:]) + [la])
                for q, _ in self.g.alts(rhs[d]):
                    for b in firsts:
                        if b != EPS and (q, 0, b) not in res:
                            res.append((q, 0, b))
            i += 1
        return frozenset(res)

    def lr1(self):
        states = [self.closure1([(0, 0, END)])]
        trans = {}
        i = 0
        while i < len(states):
            for X in self.symbols():
                moved = [(p, d + 1, la) for (p, d, la) in states[i]
                         if d < len(self.g.prods[p][1]) and self.g.prods[p][1][d] == X]
                if not moved:
                    continue
                nxt = self.closure1(moved)
                if nxt not in states:
                    states.append(nxt)
                trans[(i, X)] = states.index(nxt)
            i += 1
        self.states1, self.trans1 = states, trans
        return states, trans

    def lr1_conflicts(self, states):
        """Number of distinct (state, lookahead) cells holding more than one action."""
        cells = set()
        for k, st in enumerate(states):
            red = {}
            for (p, d, la) in st:
                if d == len(self.g.prods[p][1]):
                    red.setdefault(la, set()).add(p)
            for la, ps in red.items():
                if len(ps) > 1:
                    cells.add((k, la))
            for (p, d, la) in st:
                rhs = self.g.prods[p][1]
                if d < len(rhs) and rhs[d] in red:
                    cells.add((k, rhs[d]))
        return len(cells)

    def lalr_states(self):
        self.lr1()
        cores = OrderedDict()
        for st in self.states1:
            core = frozenset((p, d) for (p, d, _) in st)
            cores.setdefault(core, set()).update(st)
        return [frozenset(v) for v in cores.values()]

    # ---------------- table-driven LR parse with trace ----------------
    def parse(self, tokens, max_steps=500):
        toks = list(tokens) + [END]
        stack = [0]
        syms = []
        ip = 0
        rows = []
        while len(rows) < max_steps:
            s, a = stack[-1], toks[ip]
            act = self.action.get((s, a))
            st_txt = " ".join(str(stack[0]) if k == 0 else f"{syms[k-1]} {stack[k]}"
                              for k in range(len(stack)))
            inp = " ".join(toks[ip:])
            if act is None:
                exp = sorted(t for (q, t) in self.action if q == s)
                rows.append((st_txt, inp, f"ERROR: no ACTION[{s}, {a}]; expected one of {', '.join(exp)}"))
                return rows, False, ip
            if act[0] == "s":
                rows.append((st_txt, inp, f"shift {a}, go to {act[1]}"))
                stack.append(act[1]); syms.append(a); ip += 1
            elif act[0] == "r":
                lhs, rhs = self.g.prods[act[1]]
                for _ in rhs:
                    stack.pop(); syms.pop()
                t = self.goto[(stack[-1], lhs)]
                rows.append((st_txt, inp, f"reduce {self.g.prod_str(act[1])}; GOTO[{stack[-1]}, {lhs}] = {t}"))
                stack.append(t); syms.append(lhs)
            else:
                rows.append((st_txt, inp, "accept"))
                return rows, True, ip
        return rows, False, ip


# ===================== LL(1) predictive parse =====================
def ll1_parse(g, tokens, show=True):
    toks = list(tokens) + [END]
    stack = [END, g.start]
    ip = 0
    rows = []
    while True:
        X, a = stack[-1], toks[ip]
        st = " ".join(stack)
        inp = " ".join(toks[ip:])
        if X == END and a == END:
            rows.append((st, inp, "accept"))
            return rows, True, ip
        if not g.is_nt(X):
            if X == a:
                rows.append((st, inp, f"match {a}"))
                stack.pop(); ip += 1
            else:
                rows.append((st, inp, f"ERROR: expected {X}, found {a}"))
                return rows, False, ip
        else:
            p = g.table.get((X, a))
            if p is None:
                exp = sorted(t for (A, t) in g.table if A == X)
                rows.append((st, inp, f"ERROR: M[{X}, {a}] is empty; expected one of {', '.join(exp)}"))
                return rows, False, ip
            rows.append((st, inp, f"output {g.prod_str(p)}"))
            stack.pop()
            for s in reversed(g.prods[p][1]):
                stack.append(s)


# ===================== operator precedence =====================
def op_precedence(g):
    """LEADING / TRAILING and Wirth-Weber style relations for an operator grammar."""
    lead = {A: set() for A in g.nts}
    trail = {A: set() for A in g.nts}
    changed = True
    while changed:
        changed = False
        for A, rhs in g.prods:
            # LEADING
            add = set()
            if rhs:
                if not g.is_nt(rhs[0]):
                    add.add(rhs[0])
                else:
                    add |= lead[rhs[0]]
                    if len(rhs) > 1 and not g.is_nt(rhs[1]):
                        add.add(rhs[1])
            if not add <= lead[A]:
                lead[A] |= add; changed = True
            add = set()
            if rhs:
                if not g.is_nt(rhs[-1]):
                    add.add(rhs[-1])
                else:
                    add |= trail[rhs[-1]]
                    if len(rhs) > 1 and not g.is_nt(rhs[-2]):
                        add.add(rhs[-2])
            if not add <= trail[A]:
                trail[A] |= add; changed = True
    rel, reason = {}, {}

    def put(a, b, r, why):
        if (a, b) in rel and rel[(a, b)] != r:
            raise ValueError(f"precedence conflict {a},{b}")
        rel[(a, b)] = r
        reason.setdefault((a, b), why)

    for A, rhs in g.prods:
        for i in range(len(rhs) - 1):
            x, y = rhs[i], rhs[i + 1]
            if not g.is_nt(x) and not g.is_nt(y):
                put(x, y, "≐", f"adjacent in {A} → {' '.join(rhs)}")
            if i + 2 < len(rhs) and not g.is_nt(x) and g.is_nt(y) and not g.is_nt(rhs[i + 2]):
                put(x, rhs[i + 2], "≐", f"{x} {y} {rhs[i+2]} in {A} → {' '.join(rhs)}")
            if not g.is_nt(x) and g.is_nt(y):
                for b in lead[y]:
                    put(x, b, "⋖", f"{b} ∈ LEADING({y}), {x} {y} in {A} → {' '.join(rhs)}")
            if g.is_nt(x) and not g.is_nt(y):
                for a in trail[x]:
                    put(a, y, "⋗", f"{a} ∈ TRAILING({x}), {x} {y} in {A} → {' '.join(rhs)}")
    for b in lead[g.start]:
        put(END, b, "⋖", f"{b} ∈ LEADING({g.start})")
    for a in trail[g.start]:
        put(a, END, "⋗", f"{a} ∈ TRAILING({g.start})")
    return lead, trail, rel, reason


def op_parse(rel, tokens, terminals_only=True):
    """Operator-precedence parse; non-terminals shown as N."""
    toks = list(tokens) + [END]
    stack = [END]
    ip = 0
    rows = []
    while True:
        a = toks[ip]
        top_t = next(s for s in reversed(stack) if s != "N")
        st, inp = " ".join(stack), " ".join(toks[ip:])
        if top_t == END and a == END:
            rows.append((st, inp, "", "accept"))
            return rows
        r = rel.get((top_t, a))
        if r in ("⋖", "≐"):
            rows.append((st, inp, f"{top_t} {r} {a}", "shift"))
            stack.append(a); ip += 1
        elif r == "⋗":
            # pop handle: pop until terminal on top relates ⋖ to last popped terminal
            handle = []
            while True:
                s = stack.pop(); handle.insert(0, s)
                if s == "N":
                    continue
                prev_t = next(x for x in reversed(stack) if x != "N")
                if rel.get((prev_t, s)) == "⋖":
                    if stack[-1] == "N":
                        handle.insert(0, stack.pop())
                    break
            rows.append((st, inp, f"{top_t} ⋗ {a}", f"reduce handle {' '.join(handle)} → N"))
            stack.append("N")
        else:
            rows.append((st, inp, f"no relation ({top_t},{a})", "ERROR"))
            return rows
