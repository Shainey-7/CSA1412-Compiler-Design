"""Q7 experiments: correctness tests, instrumented output, baselines, timings, figures."""
import sys, time, random, tracemalloc
sys.setrecursionlimit(1000000)
from minilang import *
from attr import md_table, save, render, esc, depgraph_dot, OUT

rep = []
import os
SIZES = (25, 50, 100, 200, 400, 800, 1600) if not os.environ.get("QUICK") else ()
MAIN = """int a, b;
float x;
a = 5;
b = a + 2 * 3;
x = b / 2.0;
if (a < b) x = x - a; else b = b - 1;
while (b > 0) { b = b - 1; x = x + 1; }
"""
r = translate(MAIN)
save("q7_main_code.txt", "\n".join(r["code"]) + "\n")
save("q7_main_sym.md", md_table(["Name", "Type", "Declared on line"], [(n, t, n.line) for n, t in r["sym"].items()]))
rep.append(f"MAIN: tokens={r['tokens']} code lines={len(r['code'])} AST nodes={r['nodes']} errors={r['errors']}")


def ast_text(n, ind=0, out=None):
    out = [] if out is None else out
    pad = "  " * ind
    if n is None:
        return out
    k = n[0]
    if k == "program":
        out.append(pad + "program")
        for d in n[1]: ast_text(d, ind + 1, out)
        for s in n[2]: ast_text(s, ind + 1, out)
    elif k == "decl":
        out.append(pad + f"decl {n[1]} : " + ", ".join(n[2]))
    elif k == "=":
        out.append(pad + f"= [{n[1][1]}]"); out.append(pad + f"  id {n[1][0]} : {n[1][1]}"); ast_text(n[2], ind + 1, out)
    elif k in ("if", "if-else", "while"):
        out.append(pad + k)
        for c in n[1:]: ast_text(c, ind + 1, out)
    elif k == "block":
        out.append(pad + "block")
        for c in n[1]: ast_text(c, ind + 1, out)
    elif k in ("id", "num"):
        out.append(pad + f"{k} {n[1]} : {n[2]}")
    else:
        out.append(pad + f"{k}" + (f" : {n[3]}" if len(n) > 3 else ""))
        ast_text(n[1], ind + 1, out); ast_text(n[2], ind + 1, out)
    return out


save("q7_main_ast.txt", "\n".join(ast_text(r["ast"])) + "\n")


def ast_dot(root, name):
    L = ['digraph A {', 'graph [ordering=out, nodesep=0.18, ranksep=0.32];', 'node [fontname="Helvetica", fontsize=10.5];',
         'edge [color="#666666", arrowsize=0.5];']
    c = [0]
    def nid():
        c[0] += 1; return f"n{c[0]}"
    def box(lab, fill="#eef3f8", col="#1f4e79", shape="box"):
        i = nid(); L.append(f'{i} [label="{esc(lab)}", shape={shape}, style="rounded,filled", fillcolor="{fill}", color="{col}"];'); return i
    def w(n):
        k = n[0]
        if k == "program":
            i = box("program", "#dce6f1")
            for d in n[1]: L.append(f"{i} -> {w(d)};")
            for s in n[2]: L.append(f"{i} -> {w(s)};")
            return i
        if k == "decl":
            return box(f"decl {n[1]}\\n" + ", ".join(n[2]), "#fff4d6", "#b38600")
        if k == "=":
            i = box(f"=  (type {n[3]})", "#e8f4e8", "#3a7a3a")
            j = box(f"id {n[1][0]} : {n[1][1]}", "#f2f2f2", "#999999"); L.append(f"{i} -> {j};"); L.append(f"{i} -> {w(n[2])};"); return i
        if k in ("if", "if-else", "while"):
            i = box(k, "#fde9d9", "#b85c1e")
            for ch in n[1:]: L.append(f"{i} -> {w(ch)};")
            return i
        if k == "block":
            i = box("block", "#fde9d9", "#b85c1e")
            for ch in n[1]: L.append(f"{i} -> {w(ch)};")
            return i
        if k in ("id", "num"):
            return box(f"{k} {n[1]}\\n: {n[2]}", "#f2f2f2", "#999999")
        i = box(f"{k}" + (f"\\n: {n[3]}" if len(n) > 3 else ""), "#eef3f8", "#1f4e79", "ellipse")
        L.append(f"{i} -> {w(n[1])};"); L.append(f"{i} -> {w(n[2])};"); return i
    w(root); L.append("}"); render("\n".join(L), name)


ast_dot(r["ast"], "fig_q7_ast")

# ---- two-pass baselines on the main program; full dependency graph ----
t1 = two_pass(MAIN, "dfs")
t2 = two_pass(MAIN, "topo")
rep.append(f"MAIN baselines agree: B1={normalise(t1['code']) == normalise(r['code'])} B2={normalise(t2['code']) == normalise(r['code'])}")
dg = t2["dg"]
order, left = dg.topo()
rep.append(f"MAIN dependency graph: parse-tree nodes={t2['tree'].count()} attribute instances={len(dg.nodes)} edges={sum(len(v) for v in dg.edges.values())} cycle-free={not left}")
# classify every edge as S (child->parent), I-down (parent->child), I-sibling (left->right), or other
kinds = {"synthesized (child → parent or within node)": 0, "inherited (parent → child)": 0, "inherited (left sibling → right sibling)": 0, "right → left (would break L-attribution)": 0}
parent = {}
for n in t2["tree"].walk():
    for i, c in enumerate(n.children):
        parent[c.uid] = (n, i)
for u, vs in dg.edges.items():
    nu, au = dg.nodes[u]
    for v in vs:
        nv, av = dg.nodes[v]
        if nu.uid == nv.uid:
            kinds["synthesized (child → parent or within node)"] += 1
        elif parent.get(nu.uid, (None,))[0] is nv:
            kinds["synthesized (child → parent or within node)"] += 1
        elif parent.get(nv.uid, (None,))[0] is nu:
            kinds["inherited (parent → child)"] += 1
        elif parent.get(nu.uid, (None, 0))[0] is parent.get(nv.uid, (None, 0))[0]:
            if parent[nu.uid][1] < parent[nv.uid][1]:
                kinds["inherited (left sibling → right sibling)"] += 1
            else:
                kinds["right → left (would break L-attribution)"] += 1
        else:
            kinds["right → left (would break L-attribution)"] += 1
save("q7_edge_kinds.md", md_table(["Kind of dependency edge in the full program graph", "Count"], kinds.items()))
depgraph_dot(dg, order, "fig_q7_depgraph_full", show_values=False,
             inherited=("env", "envin", "in", "next", "true", "false"))

# zoom: dependency graph of one statement (the if-else) evaluated in isolation
ZOOM = "int a, b;\nfloat x;\nif (a < b) x = x - a; else b = b - 1;\n"
tz = two_pass(ZOOM, "topo")
oz, _ = tz["dg"].topo()
depgraph_dot(tz["dg"], oz, "fig_q7_depgraph_if", show_values=False,
             inherited=("env", "envin", "in", "next", "true", "false"))
rep.append(f"ZOOM if-else program: instances={len(tz['dg'].nodes)}")

# ---- correctness tests ----
TESTS = [
    ("V1", "valid: declarations + arithmetic", "int a, b;\na = 2;\nb = a * 3 + 1;\n"),
    ("V2", "valid: int widened to float", "int i;\nfloat f;\ni = 4;\nf = i + 0.5;\n"),
    ("V3", "valid: nested if inside while", "int n, s;\nn = 5;\ns = 0;\nwhile (n > 0) { if (n > 2) s = s + n; else s = s - 1; n = n - 1; }\n"),
    ("V4", "valid: nested while", "int i, j, c;\ni = 0;\nc = 0;\nwhile (i < 3) { j = 0; while (j < 3) { c = c + 1; j = j + 1; } i = i + 1; }\n"),
    ("V5", "valid: if without else", "int a;\na = 1;\nif (a == 1) a = 2;\n"),
    ("E1", "undeclared variable", "int a;\na = b + 1;\n"),
    ("E2", "duplicate declaration", "int a;\nfloat a;\na = 1;\n"),
    ("E3", "type error: float into int", "int a;\nfloat f;\nf = 1.5;\na = f * 2;\n"),
    ("E4", "two independent errors", "int a;\nb = 1;\na = 2.5;\n"),
    ("E5", "undeclared in condition", "int a;\nif (z < a) a = 1; else a = 2;\n"),
    ("S1", "syntax error: missing ;", "int a;\na = 1\na = 2;\n"),
]
rows = []
for code, purpose, src in TESTS:
    try:
        r1 = translate(src)
        b1 = two_pass(src, "dfs"); b2 = two_pass(src, "topo")
        agree = normalise(r1["code"]) == normalise(b1["code"]) == normalise(b2["code"]) and r1["errors"] == b1["errors"] == b2["errors"]
        errs = "; ".join(f"line {l}: {m}" for l, m in r1["errors"]) or "none"
        rows.append((code, purpose, ", ".join(f"{n}:{t}" for n, t in r1["sym"].items()), errs, len(r1["code"]), "yes" if agree else "NO"))
        save(f"q7_test_{code}.txt", src + "\n--- three-address code ---\n" + "\n".join(r1["code"]) + "\n")
    except SyntaxError as e:
        rows.append((code, purpose, "-", f"syntax: {e}", 0, "n/a"))
save("q7_tests.md", md_table(["#", "Case", "Symbol table", "Errors reported", "TAC lines", "Same output as both baselines"], rows))

# ---- scaling: one-pass vs two-pass baselines ----
random.seed(21)
def gen_program(nstmts):
    vars_i = [f"i{k}" for k in range(8)]; vars_f = [f"f{k}" for k in range(4)]
    lines = ["int " + ", ".join(vars_i) + ";", "float " + ", ".join(vars_f) + ";"]
    def expr(d=0):
        if d > 2 or random.random() < 0.35:
            return random.choice(vars_i + vars_f + ["1", "2", "3", "0.5"])
        if random.random() < 0.2:
            return "(" + expr(d + 1) + ")"
        return expr(d + 1) + " " + random.choice("+-*/") + " " + expr(d + 1)
    def assign_():
        v = random.choice(vars_f + vars_i)
        e = expr()
        if v.startswith("i"):
            e = " + ".join(random.choice(vars_i + ["1", "2"]) for _ in range(random.randint(1, 3)))
        return f"{v} = {e};"
    def stmt(depth=0):
        x = random.random()
        if depth < 2 and x < 0.15:
            return f"if ({random.choice(vars_i)} < {random.choice(vars_i)}) {stmt(depth+1)} else {stmt(depth+1)}"
        if depth < 2 and x < 0.25:
            return f"while ({random.choice(vars_i)} > 0) {{ {stmt(depth+1)} {assign_()} }}"
        return assign_()
    lines += [stmt() for _ in range(nstmts)]
    return "\n".join(lines) + "\n"


def timeit(fn, reps):
    best = 1e9
    for _ in range(reps):
        t = time.perf_counter(); fn(); best = min(best, time.perf_counter() - t)
    return best


def peak(fn):
    tracemalloc.start(); fn(); p = tracemalloc.get_traced_memory()[1]; tracemalloc.stop(); return p


rows = []
for n in SIZES:
    src = gen_program(n)
    one = translate(src, build_ast=True)
    b1 = two_pass(src, "dfs"); b2 = two_pass(src, "topo")
    assert normalise(one["code"]) == normalise(b1["code"]) == normalise(b2["code"]), n
    reps = 5 if n <= 400 else 2
    to = timeit(lambda: translate(src), reps)
    tb1 = timeit(lambda: two_pass(src, "dfs"), reps)
    tb2 = timeit(lambda: two_pass(src, "topo"), max(1, reps // 2))
    po = peak(lambda: translate(src)); pb1 = peak(lambda: two_pass(src, "dfs")); pb2 = peak(lambda: two_pass(src, "topo"))
    rows.append((n, one["tokens"], len(one["code"]), one["nodes"], b1["nodes"], b2["evals"],
                 f"{to*1000:.1f}", f"{tb1*1000:.1f}", f"{tb2*1000:.1f}",
                 f"{po/1024:.0f}", f"{pb1/1024:.0f}", f"{pb2/1024:.0f}"))
    rep.append(f"SCALE n={n}: tokens={one['tokens']} one={to*1000:.1f}ms B1={tb1*1000:.1f}ms B2={tb2*1000:.1f}ms mem {po//1024}/{pb1//1024}/{pb2//1024} KiB")
save("q7_scale.md", md_table(["Statements", "Tokens", "TAC lines", "AST nodes (one-pass)", "Parse-tree nodes (two-pass)", "Attribute instances (B2)",
                              "One-pass ms", "B1 two-pass DFS ms", "B2 two-pass dep-graph ms",
                              "One-pass peak KiB", "B1 peak KiB", "B2 peak KiB"], rows))

import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 2, figsize=(9, 3.6), dpi=150)
tok = [r_[1] for r_ in rows]
for idx, lab, mk in ((6, "one-pass SDT (final design)", "o-"), (7, "B1: tree, then DFS walk", "s-"), (8, "B2: tree, then dependency graph", "^-")):
    ax[0].plot(tok, [float(r_[idx]) for r_ in rows], mk, label=lab, markersize=4)
for idx, lab, mk in ((9, "one-pass", "o-"), (10, "B1", "s-"), (11, "B2", "^-")):
    ax[1].plot(tok, [float(r_[idx]) / 1024 for r_ in rows], mk, label=lab, markersize=4)
ax[0].set_xlabel("tokens"); ax[0].set_ylabel("time (ms)"); ax[0].set_title("Translation time", fontsize=10); ax[0].legend(frameon=False, fontsize=7.5); ax[0].grid(alpha=.3)
ax[1].set_xlabel("tokens"); ax[1].set_ylabel("peak memory (MiB)"); ax[1].set_title("Peak memory", fontsize=10); ax[1].legend(frameon=False, fontsize=7.5); ax[1].grid(alpha=.3)
fig.tight_layout(); fig.savefig(OUT + "/fig_q7_scale.png")
save("q7_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))

# ---- the full-program dependency graph, drawn in panels (same global numbering) ----
from collections import defaultdict as _dd
pos = {k: i + 1 for i, k in enumerate(order)}
byn = _dd(list)
for k, (n, a) in enumerate(dg.nodes):
    byn[n.uid].append(k)
INH = ("env", "envin", "in", "next", "true", "false", "begin")


PUNCT = {"(", ")", ";", "{", "}", "=", ",", "if", "else", "while", "int", "float"}


def panel(tree_nodes, name, title, collapse=(), rankdir="TB", context=True):
    """Each grammar symbol is one box whose cells are its attribute instances (number: attribute);
    inherited cells blue, synthesized cells red. Red arrows = dependency edges (cell to cell).
    Punctuation leaves carry no attributes and are omitted. Grey dashed boxes are attribute
    instances of neighbouring nodes that belong to another panel."""
    keep = [n for n in tree_nodes if not (n.is_leaf() and n.sym in PUNCT)]
    uids = {n.uid for n in keep}
    inside = {k for n in keep for k in byn[n.uid]}
    ctx_ = set()
    for u, vs in dg.edges.items():
        for v in vs:
            if context and (u in inside) != (v in inside):
                ctx_.add(u if v in inside else v)
    L = ['digraph G {', f'graph [rankdir={rankdir}, ordering=out, nodesep=0.12, ranksep=0.42, fontname="Helvetica"];',
         'node [fontname="Helvetica", fontsize=10, shape=plaintext];', f'labelloc="t"; label="{esc(title)}"; fontsize=12;']
    for n in keep:
        head = n.sym + (f" {n.lexeme}" if n.lexeme is not None and n.is_leaf() and n.lexeme != n.sym else "")
        if n.uid in collapse:
            head += " (own panel)"
        cells = ""
        for k in byn[n.uid]:
            at = dg.nodes[k][1]
            col = "#dbe9f7" if at in INH else "#fdecea"
            cells += f'<TD PORT="p{k}" BGCOLOR="{col}"><FONT POINT-SIZE="9">{pos[k]}: {at}</FONT></TD>'
        hdr_col = "#1f4e79" if not n.is_leaf() else "#555555"
        ncols = max(1, len(byn[n.uid]))
        tbl = (f'<<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="2" COLOR="#999999">'
               f'<TR><TD COLSPAN="{ncols}" BGCOLOR="#f4f6f8"><FONT COLOR="{hdr_col}"><B>{head.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")}</B></FONT></TD></TR>'
               + (f"<TR>{cells}</TR>" if cells else "") + "</TABLE>>")
        L.append(f"t{n.uid} [label={tbl}];")
    for k in ctx_:
        n, a = dg.nodes[k]
        L.append(f'c{k} [label="{pos[k]}: {n.sym}.{esc(a)}", shape=box, style="dashed,rounded", color="#888888", fontcolor="#666666", fontsize=9];')
    def ref(k):
        if k in inside:
            return f"t{dg.nodes[k][0].uid}:p{k}"
        return f"c{k}"
    def anc(n):
        # nearest kept ancestor for tree edges
        return n
    for n in tree_nodes:
        if n.uid not in uids:
            continue
        for c in n.children:
            if c.uid in uids:
                L.append(f't{n.uid} -> t{c.uid} [arrowhead=none, color="#bbbbbb", penwidth=1.6];')
    for u, vs in dg.edges.items():
        for v in vs:
            if (u in inside or v in inside) and (u in inside or u in ctx_) and (v in inside or v in ctx_):
                L.append(f'{ref(u)} -> {ref(v)} [color="#c0392b", penwidth=1.1, arrowsize=0.6, constraint=false];')
    L.append("}")
    render("\n".join(L), name)


root = t2["tree"]
DLn, SLn = root.children
def subtree(n):
    return list(n.walk())
# spine: P, SL chain and the top-level S nodes (collapsed)
spine, top_stmts = [root, DLn], []
x = SLn
while x.children:
    spine.append(x); top_stmts.append(x.children[1]); spine.append(x.children[1]); x = x.children[0]
spine.append(x)
panel(spine, "fig_q7_panel_spine", "Panel A - program spine: env, next and code across the statement list",
      collapse={DLn.uid} | {s.uid for s in top_stmts}, rankdir="TB", context=False)
panel(subtree(DLn), "fig_q7_panel_decl", "Panel B - declarations: T.type, L.in and the environment")
for i, s in enumerate(reversed(top_stmts), 1):
    panel(subtree(s), f"fig_q7_panel_s{i}", f"Panel C{i} - statement {i}")
rep.append(f"panels: spine + decl + {len(top_stmts)} statements")
save("q7_report.txt", "\n".join(rep) + "\n")
