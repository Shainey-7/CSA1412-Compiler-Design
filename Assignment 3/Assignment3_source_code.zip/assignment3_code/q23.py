"""Q2 (inherited attributes in declarations) and Q3 (dependency graphs, evaluation order, cycles)."""
from attr import *

# ======================= Q2 =======================
DECL_LEFT = """
D -> T L
T -> int | float
L -> L , id | id
"""
DECL_RIGHT = """
D -> T L
T -> int | float
L -> id , L | id
"""


class SymbolTable:
    def __init__(self):
        self.entries = {}          # name -> type
        self.order = []
        self.errors = []
        self.log = []

    def addType(self, entry, typ):
        self.log.append(f"addType({entry}, {typ})")
        if entry in self.entries:
            self.errors.append(f"semantic error: '{entry}' redeclared (was {self.entries[entry]}, now {typ})")
            return "duplicate"
        self.entries[entry] = typ
        self.order.append(entry)
        return "ok"

    def lookup(self, entry):
        if entry not in self.entries:
            self.errors.append(f"semantic error: '{entry}' used but not declared")
            return None
        return self.entries[entry]

    def dump(self):
        return ", ".join(f"{n}:{self.entries[n]}" for n in self.order) or "(empty)"


def decl_sdd(table, right=False):
    # (target), [deps], fn         pos 0 = head, 1.. = body
    rules = {
        0: [((2, "in"), [(1, "type")], lambda t: t)],                         # D -> T L     L.in = T.type
        1: [((0, "type"), [], lambda: "int")],                                 # T -> int     T.type = int
        2: [((0, "type"), [], lambda: "float")],                               # T -> float   T.type = float
    }
    if not right:
        rules[3] = [((1, "in"), [(0, "in")], lambda t: t),                    # L -> L1 , id  L1.in = L.in
                    ((0, "_add"), [(3, "entry"), (0, "in")], lambda e, t: table.addType(e, t))]
        rules[4] = [((0, "_add"), [(1, "entry"), (0, "in")], lambda e, t: table.addType(e, t))]  # L -> id
    else:
        rules[3] = [((1, "_add"), [(1, "entry"), (0, "in")], lambda e, t: table.addType(e, t)),  # action right after id
                    ((3, "in"), [(0, "in")], lambda t: t)]                    # L -> id , L1  L1.in = L.in
        rules[4] = [((1, "_add"), [(1, "entry"), (0, "in")], lambda e, t: table.addType(e, t))]
    return SDD(DECL_RIGHT if right else DECL_LEFT, rules, lexical={"id": {"entry": lambda lx: lx}})


# left vs right recursive insertion order, depth-first left-to-right (L-attributed) evaluation
def dfs_eval(tree, sdd):
    """L-attributed evaluation: visit children left to right, computing each child's inherited
    attributes before visiting it, then the parent's synthesized attributes/actions."""
    order = []
    def rules_for(n):
        return sdd.rules.get(n.prod, []) if n.prod is not None else []
    def compute(n, rule):
        (tpos, tattr), deps, f = rule
        tn = n if tpos == 0 else n.children[tpos - 1]
        vals = []
        for dpos, dattr in deps:
            dn = n if dpos == 0 else n.children[dpos - 1]
            if dattr == "entry":
                dn.attrs["entry"] = dn.lexeme
            vals.append(dn.attrs.get(dattr))
        tn.attrs[tattr] = f(*vals)
        order.append(f"{tn.sym}.{tattr}")
    def visit(n):
        for i, c in enumerate(n.children, 1):
            for r in rules_for(n):
                if r[0][0] == i:            # inherited attribute of child i
                    compute(n, r)
            visit(c)
        for r in rules_for(n):
            if r[0][0] == 0:
                compute(n, r)
    visit(tree)
    return order


PDL = Parser(DECL_LEFT)
PDR = Parser(DECL_RIGHT)


def run_decls(srcs, right=False, order="fifo", table=None):
    table = table or SymbolTable()
    trees = []
    for src in srcs:
        kinds, lex = tokenize(src, keywords=("int", "float"))
        try:
            tree = (PDR if right else PDL).parse(kinds, lex)
        except SyntaxError as e:
            table.errors.append(str(e)); continue
        dg = DepGraph(tree, decl_sdd(table, right))     # graph kept for drawing
        o, left = dg.topo(order)
        dfs_eval(tree, decl_sdd(table, right))          # L-attributed depth-first evaluation
        trees.append((tree, dg, o))
    return table, trees


rep = []
table, trees = run_decls(["float a, b, c"])
tree, dg, o = trees[0]
annotated_dot(tree, ["type", "in"], "fig_q2_annotated", leaf_attrs=["entry"])
depgraph_dot(dg, o, "fig_q2_flow", show_values=True)
save("q2_tree.txt", "\n".join(tree.show(["type", "in", "entry"])) + "\n")
save("q2_eval_order.md", md_table(["Step", "Attribute instance", "Rule", "Value"],
     [(i + 1, dg.name(k), "lexical" if not dg.preds[k] and dg.nodes[k][1] == "entry" else
       ("T.type from keyword" if dg.nodes[k][1] == "type" else
        ("copy L.in" if dg.nodes[k][1] == "in" else "addType(id.entry, L.in)")),
       dg.nodes[k][0].attrs.get(dg.nodes[k][1])) for i, k in enumerate(o)]))
rep.append("float a, b, c -> " + table.dump() + " | log: " + "; ".join(table.log))

# test cases (each in a fresh table unless grouped)
TESTS = [
    ("D1", "valid, three names", ["float a, b, c"], []),
    ("D2", "valid, single name", ["int x"], []),
    ("D3", "valid, two declarations", ["int count, total", "float avg"], []),
    ("D4", "duplicate inside one list", ["float a, b, a"], []),
    ("D5", "redeclared in a later declaration", ["int x, y", "float y"], []),
    ("D6", "syntax: missing comma", ["int a b"], []),
    ("D7", "syntax: missing type", ["a, b"], []),
    ("D8", "undeclared use after declarations", ["int i, j"], ["i", "k"]),
]
rows = []
for code, purpose, srcs, uses in TESTS:
    t, _ = run_decls(srcs)
    for u in uses:
        t.lookup(u)
    rows.append((code, purpose, " ; ".join(srcs) + (f"  then use {', '.join(uses)}" if uses else ""),
                 t.dump(), "; ".join(t.errors) or "none"))
save("q2_tests.md", md_table(["#", "Purpose", "Input", "Symbol table after parsing", "Errors reported"], rows))

rows = []
for label, right in (("left-recursive  L → L , id | id", False), ("right-recursive L → id , L | id", True)):
    t = SymbolTable()
    kinds, lex = tokenize("float a, b, c", keywords=("int", "float"))
    tree = (PDR if right else PDL).parse(kinds, lex)
    dfs_eval(tree, decl_sdd(t, right))
    # bottom-up (LR) order in which the L-productions are reduced
    red = []
    (PDR if right else PDL).parse(kinds, lex, on_reduce=lambda n, s: red.append(n) if n.sym == "L" else None)
    names = [next((c.lexeme for c in n.children if c.sym == "id"), None) for n in red]
    st_depth = 0
    tr = []
    (PDR if right else PDL).parse(kinds, lex, trace=tr)
    st_depth = max(len(x[0]) - 1 for x in tr)
    rows.append((label, " → ".join(t.order), " → ".join(names), st_depth, tree.height()))
    annotated_dot(tree, ["type", "in"], "fig_q2_" + ("right" if right else "left"), leaf_attrs=["entry"])
save("q2_leftright.md", md_table(["Grammar for L", "Insertion order, top-down L-attributed walk", "Order L-nodes are reduced bottom-up (id of each)", "Max LR stack depth", "Tree height"], rows))

# what if a rule uses an attribute that has not been computed yet?
t = SymbolTable()
kinds, lex = tokenize("float a, b, c", keywords=("int", "float"))
tree = PDL.parse(kinds, lex)
dg = DepGraph(tree, decl_sdd(t))
good, _ = dg.topo()
bad = list(reversed(good))
dg.evaluate(bad)
rep.append("REVERSED ORDER: table = " + t.dump() + " | log: " + "; ".join(t.log))
# per-variable types: int a, float b
PV = """
D -> D , P | P
P -> T id
T -> int | float
"""
t2 = SymbolTable()
pv_rules = {
    2: [((0, "_add"), [(2, "entry"), (1, "type")], lambda e, ty: t2.addType(e, ty))],
    3: [((0, "type"), [], lambda: "int")],
    4: [((0, "type"), [], lambda: "float")],
}
sdd_pv = SDD(PV, pv_rules, lexical={"id": {"entry": lambda lx: lx}})
ppv = Parser(PV)
kinds, lex = tokenize("int a, float b, int c", keywords=("int", "float"))
tpv = ppv.parse(kinds, lex)
dgp = DepGraph(tpv, sdd_pv); o2, _ = dgp.topo(); dgp.evaluate(o2)
inh = [dgp.name(k) for k in range(len(dgp.nodes)) if dgp.nodes[k][1] == "in"]
rep.append(f"PER-VARIABLE: int a, float b, int c -> {t2.dump()}; inherited attribute instances = {len(inh)}")
annotated_dot(tpv, ["type"], "fig_q2_pervar", leaf_attrs=["entry"])

# ======================= Q3 =======================
# dependency graph for float a, b
t3 = SymbolTable()
kinds, lex = tokenize("float a, b", keywords=("int", "float"))
tree_fb = PDL.parse(kinds, lex)
dg_fb = DepGraph(tree_fb, decl_sdd(t3))
o1, _ = dg_fb.topo("fifo")
dg_fb.evaluate(o1)
depgraph_dot(dg_fb, o1, "fig_q3_dg_decl")
o1b, _ = dg_fb.topo("rightfirst")
save("q3_decl_orders.md", md_table(["Position", "Order 1 (Kahn, queue)", "Order 2 (Kahn, stack, right-first)"],
     [(i + 1, dg_fb.name(a), dg_fb.name(b)) for i, (a, b) in enumerate(zip(o1, o1b))]))
save("q3_decl_edges.md", md_table(["#", "Edge (from → to)", "Comes from rule"],
     [(i + 1, f"{dg_fb.name(u)} → {dg_fb.name(v)}", "") for i, (u, v) in enumerate((u, v) for u in dg_fb.edges for v in dg_fb.edges[u])]))
res = []
for name, order in (("order 1", o1), ("order 2", o1b)):
    tt = SymbolTable(); tr_ = PDL.parse(kinds, lex); d = DepGraph(tr_, decl_sdd(tt)); oo, _ = d.topo("fifo" if name == "order 1" else "rightfirst"); d.evaluate(oo)
    res.append(f"{name}: table {tt.dump()} | addType calls in order: {'; '.join(tt.log)}")
rep += ["Q3 float a,b " + r for r in res]

# dependency graph for 2 + 3 * 4 with the Q1 SDD in generic form
EXPR = """
E -> E + T | E - T | T
T -> T * F | T / F | F
F -> ( E ) | digit
"""
expr_rules = {
    0: [((0, "val"), [(1, "val"), (3, "val")], lambda a, b: a + b)],
    1: [((0, "val"), [(1, "val"), (3, "val")], lambda a, b: a - b)],
    2: [((0, "val"), [(1, "val")], lambda a: a)],
    3: [((0, "val"), [(1, "val"), (3, "val")], lambda a, b: a * b)],
    4: [((0, "val"), [(1, "val"), (3, "val")], lambda a, b: a / b)],
    5: [((0, "val"), [(1, "val")], lambda a: a)],
    6: [((0, "val"), [(2, "val")], lambda a: a)],
    7: [((0, "val"), [(1, "lexval")], lambda a: a)],
}
expr_sdd = SDD(EXPR, expr_rules, lexical={"digit": {"lexval": lambda lx: int(lx)}})
pe = Parser(EXPR)
kinds, lex = tokenize("2 + 3 * 4")
te = pe.parse(kinds, lex)
dge = DepGraph(te, expr_sdd)
oe, _ = dge.topo("fifo"); dge.evaluate(oe)
depgraph_dot(dge, oe, "fig_q3_dg_expr")
oe2, _ = dge.topo("rightfirst")
te2 = pe.parse(kinds, lex); dge2 = DepGraph(te2, expr_sdd); dge2.evaluate(oe2)
save("q3_expr_orders.md", md_table(["Position", "Order 1 (queue)", "value", "Order 2 (stack, right-first)", "value"],
     [(i + 1, dge.name(a), dge.nodes[a][0].attrs.get(dge.nodes[a][1]), dge2.name(b), dge2.nodes[b][0].attrs.get(dge2.nodes[b][1])) for i, (a, b) in enumerate(zip(oe, oe2))]))
rep.append(f"Q3 2+3*4: order1 root={te.attrs['val']} order2 root={te2.attrs['val']}; attribute nodes={len(dge.nodes)} edges={sum(len(v) for v in dge.edges.values())}")
# count of valid orders (brute force small graph)
import itertools as it
def count_orders(dg):
    n = len(dg.nodes); memo = {}
    def go(done):
        if len(done) == n: return 1
        if done in memo: return memo[done]
        tot = 0
        for k in range(n):
            if k not in done and all(p in done for p in dg.preds[k]):
                tot += go(done | frozenset([k]))
        memo[done] = tot; return tot
    return go(frozenset())
rep.append(f"number of valid topological orders: float a,b = {count_orders(dg_fb)}; 2+3*4 = {count_orders(dge)}")

# cyclic SDD
CYC = """
S -> A B
A -> a
B -> b
"""
cyc_rules = {
    0: [((0, "r"), [(1, "x")], lambda x: x),
        ((1, "x"), [(2, "y")], lambda y: y + 1),        # A.x needs B.y
        ((2, "y"), [(1, "x")], lambda x: x * 2)],       # B.y needs A.x  -> cycle
}
pc = Parser(CYC)
tc = pc.parse(["a", "b"], ["a", "b"])
dgc = DepGraph(tc, SDD(CYC, cyc_rules))
oc, leftover = dgc.topo()
cyc = dgc.find_cycle(leftover)
rep.append(f"CYCLE: evaluated {len(oc)} of {len(dgc.nodes)} instances; stuck = {[dgc.name(k) for k in leftover]}; cycle = {' -> '.join(dgc.name(k) for k in cyc)}")
depgraph_dot(dgc, oc, "fig_q3_cycle", show_values=False)
save("q23_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
