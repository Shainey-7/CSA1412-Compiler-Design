"""Q6a: inherited attributes in LR parsing via marker non-terminals.  Q6b: three-address code SDD."""
from attr import *
from grammar import Grammar, LR

rep = []
# ======================= Q6a =======================
MARKED = """
D -> T M L
T -> int | float
M -> ε
L -> L , id | id
"""
PM = Parser(MARKED)
symtab = {}


def run_marked(src, trace_rows):
    kinds, lex = tokenize(src, keywords=("int", "float"))
    def on_shift(n, stack):
        if n.sym == "id":
            n.attrs["entry"] = n.lexeme

    def on_reduce(n, stack):
        p = n.prod
        k = n.children
        # 'stack' is the value stack AFTER popping |rhs| entries, i.e. stack[-1] = top - |rhs|
        if p in (1, 2):
            n.attrs["type"] = k[0].lexeme
            note = f"T.type = {n.attrs['type']}"
        elif p == 3:                                   # M -> ε : copy T.type, which is at top (M has empty rhs)
            n.attrs["i"] = stack[-1].attrs["type"]
            note = f"M.i = stack[top].type = {n.attrs['i']}"
        elif p == 4:                                   # L -> L , id : M is at top-3 before popping
            t = stack[-1].attrs["i"]; symtab[k[2].lexeme] = t
            note = f"addType({k[2].lexeme}, stack[top-3].i = {t})"
        elif p == 5:                                   # L -> id : M is at top-1 before popping
            t = stack[-1].attrs["i"]; symtab[k[0].lexeme] = t
            note = f"addType({k[0].lexeme}, stack[top-1].i = {t})"
        else:
            note = "accept D"
        n.attrs["note"] = note
    trace = []
    PM.parse(kinds, lex, on_reduce=on_reduce, on_shift=on_shift, trace=trace)
    for step, (states, nodes, rest, act) in enumerate(trace):
        cells = []
        for nd in nodes:
            v = nd.attrs.get("type") or nd.attrs.get("i") or nd.attrs.get("entry")
            cells.append(f"{nd.sym}" + (f"[{v}]" if v and nd.sym != v else ""))
        if act[0] == "s":
            a = f"shift {rest[0]}"
        elif act[0] == "r":
            a = f"reduce {PM.lr.g.prod_str(act[1])}"
        else:
            a = "accept"
        trace_rows.append([step + 1, "$ " + " ".join(cells), " ".join(rest), a])
    return trace_rows


rows = []
run_marked("int x, y", rows)
sym_after = dict(symtab)
# attach the semantic notes: re-run with notes collected in order of reductions
notes = []
kinds, lex = tokenize("int x, y", keywords=("int", "float"))
symtab.clear()
def collect(n, stack):
    p = n.prod
    if p in (1, 2): notes.append(f"T.type = {n.children[0].lexeme}"); n.attrs["type"] = n.children[0].lexeme
    elif p == 3: n.attrs["i"] = stack[-1].attrs["type"]; notes.append(f"M.i := stack[top].type = {n.attrs['i']}")
    elif p == 4: notes.append(f"addType({n.children[2].lexeme}, stack[top-3].i = {stack[-1].attrs['i']})")
    elif p == 5: notes.append(f"addType({n.children[0].lexeme}, stack[top-1].i = {stack[-1].attrs['i']})")
    elif p == 0: notes.append("D complete")
PM.parse(kinds, lex, on_reduce=collect)
it = iter(notes)
for r in rows:
    r.append(next(it) if r[3].startswith("reduce") else "")
save("q6_marker_trace.md", md_table(["Step", "Value stack (symbol[attribute])", "Input", "Action", "Semantic action at reduce"], rows))
rep.append(f"marker grammar SLR conflicts = {len(PM.lr.conflicts)}; symtab after int x, y = {sym_after}")

# where the technique fails: the inherited value is not at a fixed depth
FAIL = """
S -> a A C | b A B C
A -> x
B -> y
C -> c
"""
pf = Parser(FAIL)
rows = []
for src in (["a", "x", "c"], ["b", "x", "y", "c"]):
    seen = {}
    def on_r(n, stack):
        if n.sym == "C":
            seen["below"] = [s.sym for s in stack]
    pf.parse(src, src, on_reduce=on_r)
    below = seen["below"]
    rows.append((" ".join(src), "$ " + " ".join(below) + "  | c", below[-1], "yes" if below[-1] == "A" else "NO — A is at top-2"))
FIX = FAIL.replace("S -> a A C | b A B C", "S -> a A C | b A B N C").replace("C -> c", "C -> c\nN -> ε")
pfx = Parser(FIX)
for src in (["a", "x", "c"], ["b", "x", "y", "c"]):
    seen = {}
    def on_r(n, stack):
        if n.sym == "N":
            n.attrs["s"] = stack[-2].sym      # copies A.s from top-1 at the time N is reduced
        if n.sym == "C":
            seen["below"] = [s.sym for s in stack]
    pfx.parse(src, src, on_reduce=on_r)
    below = seen["below"]
    rows.append((" ".join(src) + "  (with marker N)", "$ " + " ".join(below) + "  | c", below[-1], "yes — A, or N holding a copy of A.s"))
save("q6_fail.md", md_table(["Input", "Stack when C → c is reduced", "Symbol at top-1", "Is A.s at a fixed position?"], rows))

# B's verification: a marker can introduce a conflict
NOM = """
S -> A B | A C
A -> a
B -> b
C -> b c
"""
WITHM = """
S -> A M B | A N C
A -> a
B -> b
C -> b c
M -> ε
N -> ε
"""
for name, txt in (("without markers", NOM), ("with markers M, N", WITHM)):
    l = LR(Grammar(txt)); _, _, c = l.slr()
    rep.append(f"MARKER RISK {name}: SLR conflicts = {len(c)} {[(s, a, o, n) for s, a, o, n in c]}")

# ======================= Q6b =======================
class TAC:
    def __init__(self):
        self.t = 0; self.L = 0
    def newTemp(self):
        self.t += 1; return f"t{self.t}"
    def newLabel(self):
        self.L += 1; return f"L{self.L}"


ASSIGN = """
S -> id = E
E -> E + T | E - T | T
T -> T * F | F
F -> id
"""
PA = Parser(ASSIGN)


def gen_assign(src, order="correct"):
    g = TAC()
    kinds, lex = tokenize(src)
    table = []
    def on_reduce(n, stack):
        k = n.children
        p = n.prod      # 0 S->id=E  1 E->E+T  2 E->E-T  3 E->T  4 T->T*F  5 T->F  6 F->id
        if p == 6:
            n.attrs["addr"], n.attrs["code"] = k[0].lexeme, []
            rule = "E.addr = id.lexeme ; E.code = ''"
        elif p in (3, 5):
            n.attrs["addr"], n.attrs["code"] = k[0].attrs["addr"], k[0].attrs["code"]
            rule = "copy addr and code"
        elif p in (1, 2, 4):
            t = g.newTemp()
            instr = [f"{t} = {k[0].attrs['addr']} {k[1].sym} {k[2].attrs['addr']}"]
            code = (k[0].attrs["code"] + k[2].attrs["code"] + instr) if order == "correct" else (instr + k[0].attrs["code"] + k[2].attrs["code"])
            n.attrs["addr"], n.attrs["code"] = t, code
            rule = f"E.addr = newTemp() = {t} ; E.code = E1.code || E2.code || gen(...)"
        else:
            instr = [f"{k[0].lexeme} = {k[2].attrs['addr']}"]
            n.attrs["code"] = (k[2].attrs["code"] + instr) if order == "correct" else (instr + k[2].attrs["code"])
            n.attrs["addr"] = k[0].lexeme
            rule = "S.code = E.code || gen(id '=' E.addr)"
        table.append((PA.g.prod_str(p), n.attrs.get("addr"), " ; ".join(n.attrs.get("code", [])) or "(empty)"))
    tree = PA.parse(kinds, lex, on_reduce=on_reduce)
    return tree, table


tree, table = gen_assign("x = a + b * c - d")
save("q6_tac_steps.md", md_table(["#", "Reduction", "E.addr", "E.code (after this reduction)"], [(i + 1,) + r for i, r in enumerate(table)]))
save("q6_tac.txt", "\n".join(tree.attrs["code"]) + "\n")
annotated_dot(tree, ["addr"], "fig_q6_tac_tree")
_, wrong = gen_assign("x = a + b * c - d", order="wrong")
save("q6_tac_wrong.txt", "\n".join(wrong[-1][2].split(" ; ")) + "\n")


# if-else with inherited labels (top-down translator)
class IfTrans:
    """S -> if ( B ) S1 else S2 | id = E ;    B -> E relop E    E as above (+, -, *)
       inherited: B.true, B.false, S.next ; synthesized: code, addr"""
    def __init__(self, src):
        self.k, self.l = tokenize(src, keywords=("if", "else")); self.k.append("$"); self.l.append("$"); self.i = 0
        self.g = TAC(); self.log = []
    def la(self): return self.k[self.i]
    def eat(self, t):
        if self.la() != t: raise SyntaxError(f"expected {t} found {self.l[self.i]}")
        x = self.l[self.i]; self.i += 1; return x
    def program(self):
        nxt = self.g.newLabel()
        code = self.S(nxt)
        return code + [f"{nxt}:"]
    def S(self, next_):                       # next_ is the inherited S.next
        if self.la() == "if":
            self.eat("if"); self.eat("(")
            Bt, Bf = self.g.newLabel(), self.g.newLabel()          # inherited by B before B is translated
            self.log.append(f"S.next = {next_}: B.true = {Bt}, B.false = {Bf}; S1.next = S2.next = {next_}")
            bcode = self.B(Bt, Bf); self.eat(")")
            s1 = self.S(next_); self.eat("else"); s2 = self.S(next_)
            return bcode + [f"{Bt}:"] + s1 + [f"goto {next_}"] + [f"{Bf}:"] + s2
        name = self.eat("id"); self.eat("=")
        addr, code = self.E(); self.eat(";")
        return code + [f"{name} = {addr}"]
    def B(self, t, f):
        a1, c1 = self.E(); op = self.eat("relop"); a2, c2 = self.E()
        return c1 + c2 + [f"if {a1} {op} {a2} goto {t}", f"goto {f}"]
    def E(self):
        a, c = self.Tm()
        while self.la() in "+-":
            op = self.eat(self.la()); b, d = self.Tm(); t = self.g.newTemp()
            c = c + d + [f"{t} = {a} {op} {b}"]; a = t
        return a, c
    def Tm(self):
        a, c = self.Fa()
        while self.la() == "*":
            self.eat("*"); b, d = self.Fa(); t = self.g.newTemp()
            c = c + d + [f"{t} = {a} * {b}"]; a = t
        return a, c
    def Fa(self):
        if self.la() == "digit" or self.la() == "num":
            return self.eat(self.la()), []
        return self.eat("id"), []


it1 = IfTrans("if (a < b) x = a + b; else x = a - b;")
save("q6_if.txt", "\n".join(it1.program()) + "\n")
save("q6_if_log.txt", "\n".join(it1.log) + "\n")
it2 = IfTrans("if (a < b) if (c > d) x = 1; else x = 2; else x = 3;")
save("q6_if_nested.txt", "\n".join(it2.program()) + "\n")
save("q6_if_nested_log.txt", "\n".join(it2.log) + "\n")
save("q6_report.txt", "\n".join(rep) + "\n")
print("\n".join(rep))
