import sys, time, random; sys.path.insert(0,'.'); sys.setrecursionlimit(10**6)
import os; os.environ["QUICK"]="1"
import minilang as M
src_gen = None
_src=open('q7.py').read(); _a=_src.index("def gen_program"); _b=_src.index("def timeit"); exec(_src[_a:_b])
random.seed(21)
progs = {n: gen_program(n) for n in (25,50,100,200,400,800,1600)}
orig = M.make_sdd
def patched(ctx):
    s = orig(ctx)
    r = list(s.rules[8]); 
    def app(c1, c2, n):
        c1.extend(c2); c1.append(f"{n}:"); return c1   # in-place: no copy of the prefix
    r[3] = (r[3][0], r[3][1], app)
    s.rules[8] = r
    return s
for n in (400, 800, 1600):
    src = progs[n]
    t=time.perf_counter(); a=M.two_pass(src,"dfs"); t1=time.perf_counter()-t
    M.make_sdd = patched
    t=time.perf_counter(); b=M.two_pass(src,"dfs"); t2=time.perf_counter()-t
    M.make_sdd = orig
    print(n, f"copying concat {t1*1000:.0f} ms, in-place append {t2*1000:.0f} ms", M.normalise(a["code"])==M.normalise(b["code"]))
import gc
for n in (400, 800, 1600):
    src = progs[n]
    t=time.perf_counter(); M.two_pass(src,"dfs"); t1=time.perf_counter()-t
    t=time.perf_counter(); M.translate(src); o1=time.perf_counter()-t
    gc.disable()
    t=time.perf_counter(); M.two_pass(src,"dfs"); t2=time.perf_counter()-t
    t=time.perf_counter(); M.translate(src); o2=time.perf_counter()-t
    gc.enable()
    print("GC", n, f"B1 {t1*1000:.0f} -> {t2*1000:.0f} ms (gc off); one-pass {o1*1000:.1f} -> {o2*1000:.1f}")
for n in (400, 1600):
    src = progs[n]
    k,l = M.lex(src)
    t=time.perf_counter(); tree=M.LRP.parse(k,l); tp=time.perf_counter()-t
    ctx=M.Ctx(); sdd=M.make_sdd(ctx)
    t=time.perf_counter(); M.dfs_eval(tree, sdd); te=time.perf_counter()-t
    print("SPLIT", n, f"parse {tp*1000:.0f} ms, eval {te*1000:.0f} ms, tree height {tree.height()}")
import cProfile, pstats
cProfile.run('M.dfs_eval(M.LRP.parse(*M.lex(progs[1600])), M.make_sdd(M.Ctx()))', '/tmp/prof')
pstats.Stats('/tmp/prof').sort_stats('tottime').print_stats(6)
