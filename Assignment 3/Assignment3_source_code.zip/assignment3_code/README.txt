Assignment 3 (CO3) - MOTHISH G (192421135) & HARITHI S (192421151)
Source code behind every tree, graph, table and timing in the report. Python 3 + Graphviz (dot) + matplotlib.

grammar.py   LR(0)/SLR table construction (from our Assignment 2 toolkit)
attr.py      parse trees, SDD rules, dependency graph, Kahn topological evaluation, cycle detection, drawing
q1.py        Q1  S-attributed SDD, annotated tree, 13 tests, counts, height experiment
q23.py       Q2/Q3  inherited attributes, addType, dependency graphs, two orders, cyclic SDD
q4.py        Q4  postfix SDT, action nodes, mid-production marker, right-recursive translator
q5.py        Q5  AST via mkNode/mkLeaf, top-down E'.inh version, node counts, memory
q6.py        Q6  marker non-terminals (stack trace for int x, y), failure case, three-address code, if-else labels
minilang.py  Q7  one-pass MiniLang translator + two-pass baselines (B1 DFS, B2 dependency graph)
q7.py        Q7  tests, instrumented output, full-program dependency graph panels, scaling
q7_check_concat.py / q7_check_memory.py   diagnostics for the B1 baseline
Run:  python3 q1.py ; python3 q23.py ; ... ; python3 q7.py      (outputs go to ../out/)
