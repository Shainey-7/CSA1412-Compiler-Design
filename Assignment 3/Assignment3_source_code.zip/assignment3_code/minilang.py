"""
MiniLang syntax-directed translator (Q7).

* lex()          - tokens with line numbers
* OnePass        - final design: recursive-descent, L-attributed SDT, translation during parsing
* SDD_RULES      - the same translation written as an attribute grammar over an LR grammar,
                   used by the two-pass baselines (build the parse tree, then evaluate):
                     B1 = parse tree + depth-first left-to-right (L-attributed) walk
                     B2 = parse tree + general dependency graph + topological order
"""
import re
from attr import Node, Parser, DepGraph, SDD

KEYWORDS = {"int", "float", "if", "else", "while"}


class Lex(str):
    """a lexeme that remembers its line"""
    def __new__(cls, s, line):
        o = str.__new__(cls, s); o.line = line; return o


def lex(src):
    kinds, lexes = [], []
    for ln, line in enumerate(src.splitlines(), 1):
        for m in re.finditer(r"\s*(\d+\.\d+|\d+|[A-Za-z_]\w*|<=|>=|==|!=|\S)", line):
            t = m.group(1)
            if t[0].isdigit():
                k = "num"
            elif t in KEYWORDS:
                k = t
            elif t[0].isalpha() or t[0] == "_":
                k = "id"
            elif t in ("<", ">", "<=", ">=", "==", "!="):
                k = "relop"
            else:
                k = t
            kinds.append(k); lexes.append(Lex(t, ln))
    return kinds, lexes


class Ctx:
    """counters, symbol table and error list shared by the semantic actions"""
    def __init__(self):
        self.t = 0; self.L = 0; self.errors = []
    def newTemp(self):
        self.t += 1; return f"t{self.t}"
    def newLabel(self):
        self.L += 1; return f"L{self.L}"
    def err(self, line, msg):
        self.errors.append((line, msg))


def num_type(lexeme):
    return "float" if "." in lexeme else "int"


def arith(ctx, op, a1, t1, c1, a2, t2, c2, line):
    """E.addr / E.type / E.code for a binary operator, with int->float widening."""
    code = c1 + c2
    if "error" in (t1, t2):
        return ctx.newTemp(), "error", code
    typ = "float" if "float" in (t1, t2) else "int"
    if typ == "float" and t1 == "int":
        w = ctx.newTemp(); code = code + [f"{w} = (float) {a1}"]; a1 = w
    if typ == "float" and t2 == "int":
        w = ctx.newTemp(); code = code + [f"{w} = (float) {a2}"]; a2 = w
    t = ctx.newTemp()
    return t, typ, code + [f"{t} = {a1} {op} {a2}"]


def assign(ctx, name, vtype, a, etype, code, line):
    if vtype is None:
        ctx.err(line, f"undeclared variable '{name}'")
        return code
    if etype == "error":
        return code
    if vtype == "int" and etype == "float":
        ctx.err(line, f"type error: cannot assign float expression to int variable '{name}'")
        return code
    if vtype == "float" and etype == "int":
        w = ctx.newTemp(); return code + [f"{w} = (float) {a}", f"{name} = {w}"]
    return code + [f"{name} = {a}"]


def compare(ctx, a1, t1, c1, op, a2, t2, c2, true, false):
    code = c1 + c2
    if "error" not in (t1, t2) and t1 != t2:
        if t1 == "int":
            w = ctx.newTemp(); code = code + [f"{w} = (float) {a1}"]; a1 = w
        else:
            w = ctx.newTemp(); code = code + [f"{w} = (float) {a2}"]; a2 = w
    return code + [f"if {a1} {op} {a2} goto {true}", f"goto {false}"]


# ============================================================================
# FINAL DESIGN: one-pass L-attributed translator (recursive descent)
# ============================================================================
class OnePass:
    """
    P   -> DL SL                    SL.env = DL.env (symbol table after the declarations)
    DL  -> D DL | ε
    D   -> T id {addType(id, T.type)} L ;        L.in = T.type     (inherited)
    L   -> , id {addType(id, L.in)} L1 | ε       L1.in = L.in
    T   -> int {T.type = int} | float {T.type = float}
    SL  -> S SL | ε                 S.next = newLabel()  (inherited)
    S   -> id = E ;
         | if ( C ) S1 X            C.true, C.false = newLabel() (inherited by C); S1.next = S.next
         | while ( C ) S1           begin = newLabel(); C.false = S.next; S1.next = begin
         | { SL }
    X   -> else S2 | ε
    C   -> E1 relop E2              uses inherited C.true, C.false
    E   -> Tm E'                    E'.inh = (Tm.addr, Tm.type, Tm.code)  (inherited)
    E'  -> + Tm E1' | - Tm E1' | ε  E1'.inh = arith(E'.inh, Tm) ; E'.syn = E1'.syn
    Tm  -> Fa Tm' ; Tm' -> * Fa Tm1' | / Fa Tm1' | ε   (same pattern)
    Fa  -> ( E ) | id | num
    """
    def __init__(self, src, build_ast=True):
        self.k, self.l = lex(src)
        self.k.append("$"); self.l.append(Lex("$", self.l[-1].line if self.l else 1))
        self.i = 0; self.ctx = Ctx(); self.sym = {}; self.order = []; self.ast = build_ast
        self.nodes = 0

    # ---- helpers ----
    def la(self): return self.k[self.i]
    def eat(self, t):
        if self.la() != t:
            raise SyntaxError(f"line {self.l[self.i].line}: expected '{t}' but found '{self.l[self.i]}'")
        x = self.l[self.i]; self.i += 1; return x
    def mk(self, *a):
        self.nodes += 1
        return a if self.ast else None
    def addType(self, name, typ):
        if name in self.sym:
            self.ctx.err(name.line, f"duplicate declaration of '{name}' (already {self.sym[name]})")
        else:
            self.sym[name] = typ; self.order.append(name)
    def lookup(self, name):
        return self.sym.get(name)

    # ---- program ----
    def P(self):
        decls = self.DL()
        code, stmts = self.SL()
        self.eat("$")
        return code, self.mk("program", decls, stmts)

    def DL(self):
        out = []
        while self.la() in ("int", "float"):
            out.append(self.D())
        return out

    def D(self):
        typ = self.T()
        name = self.eat("id"); self.addType(name, typ)
        names = [name] + self.L(typ)
        self.eat(";")
        return self.mk("decl", typ, names)

    def L(self, inh):                      # inh = L.in (inherited)
        names = []
        while self.la() == ",":
            self.eat(","); name = self.eat("id"); self.addType(name, inh); names.append(name)
        return names

    def T(self):
        if self.la() == "int":
            self.eat("int"); return "int"
        self.eat("float"); return "float"

    def SL(self, stop=("$",)):
        code, nodes = [], []
        while self.la() not in stop and self.la() != "}":
            nxt = self.ctx.newLabel()             # S.next inherited from SL
            c, n = self.S(nxt)
            code += c + [f"{nxt}:"]; nodes.append(n)
        return code, nodes

    def S(self, nxt):
        if self.la() == "id":
            name = self.eat("id"); self.eat("=")
            a, t, c, n = self.E()
            self.eat(";")
            vt = self.lookup(name)
            return assign(self.ctx, name, vt, a, t, c, name.line), self.mk("=", (name, vt), n, t)
        if self.la() == "if":
            self.eat("if"); self.eat("(")
            tl = self.ctx.newLabel(); fl = self.ctx.newLabel()      # C.true, C.false (inherited by C)
            cc, cn = self.C(tl, fl); self.eat(")")
            s1, n1 = self.S(nxt)                                   # S1.next = S.next
            if self.la() == "else":
                self.eat("else"); s2, n2 = self.S(nxt)
                return cc + [f"{tl}:"] + s1 + [f"goto {nxt}", f"{fl}:"] + s2, self.mk("if-else", cn, n1, n2)
            return cc + [f"{tl}:"] + s1 + [f"{fl}:"], self.mk("if", cn, n1)
        if self.la() == "while":
            self.eat("while"); self.eat("(")
            begin = self.ctx.newLabel(); tl = self.ctx.newLabel()
            cc, cn = self.C(tl, nxt); self.eat(")")
            s1, n1 = self.S(begin)
            return [f"{begin}:"] + cc + [f"{tl}:"] + s1 + [f"goto {begin}"], self.mk("while", cn, n1)
        if self.la() == "{":
            self.eat("{"); c, ns = self.SL(); self.eat("}")
            return c, self.mk("block", ns)
        raise SyntaxError(f"line {self.l[self.i].line}: unexpected '{self.l[self.i]}' at the start of a statement")

    def C(self, true, false):              # C.true / C.false inherited
        a1, t1, c1, n1 = self.E()
        op = self.eat("relop")
        a2, t2, c2, n2 = self.E()
        return compare(self.ctx, a1, t1, c1, op, a2, t2, c2, true, false), self.mk(op, n1, n2)

    def E(self):
        a, t, c, n = self.Tm()
        return self.Ep(a, t, c, n)             # E'.inh

    def Ep(self, a, t, c, n):
        while self.la() in ("+", "-"):
            op = self.eat(self.la())
            a2, t2, c2, n2 = self.Tm()
            a, t, c = arith(self.ctx, op, a, t, c, a2, t2, c2, op.line)
            n = self.mk(op, n, n2, t)
        return a, t, c, n                      # E'.syn

    def Tm(self):
        a, t, c, n = self.Fa()
        while self.la() in ("*", "/"):
            op = self.eat(self.la())
            a2, t2, c2, n2 = self.Fa()
            a, t, c = arith(self.ctx, op, a, t, c, a2, t2, c2, op.line)
            n = self.mk(op, n, n2, t)
        return a, t, c, n

    def Fa(self):
        if self.la() == "(":
            self.eat("("); r = self.E(); self.eat(")"); return r
        if self.la() == "num":
            x = self.eat("num"); return x, num_type(x), [], self.mk("num", x, num_type(x))
        name = self.eat("id")
        t = self.lookup(name)
        if t is None:
            self.ctx.err(name.line, f"undeclared variable '{name}'")
            t = "error"
        return name, t, [], self.mk("id", name, t)


def translate(src, build_ast=True):
    p = OnePass(src, build_ast)
    code, ast = p.P()
    return {"code": cleanup(code), "raw": code, "ast": ast, "sym": {n: p.sym[n] for n in p.order},
            "errors": sorted(p.ctx.errors), "nodes": p.nodes, "tokens": len(p.k) - 1}


def cleanup(code):
    """drop labels that are never jumped to (pure post-processing, same for every strategy)."""
    used = {ins.split()[-1] for ins in code if "goto" in ins}
    return [ins for ins in code if not (ins.endswith(":") and ins[:-1] not in used)]


def normalise(code):
    """rename temporaries and labels in order of first appearance so different evaluation orders compare."""
    mt, ml = {}, {}
    out = []
    for ins in code:
        def rt(m):
            return mt.setdefault(m.group(0), f"t{len(mt) + 1}")
        def rl(m):
            return ml.setdefault(m.group(0), f"L{len(ml) + 1}")
        ins = re.sub(r"\bt\d+\b", rt, ins)
        ins = re.sub(r"\bL\d+\b", rl, ins)
        out.append(ins)
    return out


# ============================================================================
# BASELINES: the same SDD over an LR grammar, evaluated after the tree is built
# ============================================================================
LR_GRAMMAR = """
P -> DL SL
DL -> DL D | ε
D -> T L ;
T -> int | float
L -> L , id | id
SL -> SL S | ε
S -> id = E ; | if ( C ) S else S | if ( C ) S | while ( C ) S | { SL }
C -> E relop E
E -> E + Tm | E - Tm | Tm
Tm -> Tm * Fa | Tm / Fa | Fa
Fa -> ( E ) | id | num
"""
LRP = Parser(LR_GRAMMAR)


def make_sdd(ctx):
    def add(env, name, typ):
        if name in env:
            ctx.err(name.line, f"duplicate declaration of '{name}' (already {env[name]})")
            return env
        e = dict(env); e[name] = typ; return e

    def look(env, name):
        t = env.get(name)
        if t is None:
            ctx.err(name.line, f"undeclared variable '{name}'")
            return "error"
        return t

    def bin_(op):
        return [((0, "res"), [(1, "addr"), (1, "type"), (1, "code"), (3, "addr"), (3, "type"), (3, "code"), (2, "lex")],
                 lambda a1, t1, c1, a2, t2, c2, o: arith(ctx, o, a1, t1, c1, a2, t2, c2, o.line)),
                ((0, "addr"), [(0, "res")], lambda r: r[0]),
                ((0, "type"), [(0, "res")], lambda r: r[1]),
                ((0, "code"), [(0, "res")], lambda r: r[2]),
                ((1, "env"), [(0, "env")], lambda e: e),
                ((3, "env"), [(0, "env")], lambda e: e)]

    def copy_(pos=1):
        return [((pos, "env"), [(0, "env")], lambda e: e),
                ((0, "addr"), [(pos, "addr")], lambda x: x),
                ((0, "type"), [(pos, "type")], lambda x: x),
                ((0, "code"), [(pos, "code")], lambda x: x)]

    R = {
        0: [((1, "envin"), [], lambda: {}), ((2, "env"), [(1, "envout")], lambda e: e),
            ((0, "code"), [(2, "code")], lambda c: c)],
        1: [((1, "envin"), [(0, "envin")], lambda e: e), ((2, "envin"), [(1, "envout")], lambda e: e),
            ((0, "envout"), [(2, "envout")], lambda e: e)],
        2: [((0, "envout"), [(0, "envin")], lambda e: e)],
        3: [((2, "in"), [(1, "type")], lambda t: t), ((2, "envin"), [(0, "envin")], lambda e: e),
            ((0, "envout"), [(2, "envout")], lambda e: e)],
        4: [((0, "type"), [], lambda: "int")],
        5: [((0, "type"), [], lambda: "float")],
        6: [((1, "in"), [(0, "in")], lambda t: t), ((1, "envin"), [(0, "envin")], lambda e: e),
            ((0, "envout"), [(1, "envout"), (3, "lex"), (0, "in")], lambda e, n, t: add(e, n, t))],
        7: [((0, "envout"), [(0, "envin"), (1, "lex"), (0, "in")], lambda e, n, t: add(e, n, t))],
        8: [((1, "env"), [(0, "env")], lambda e: e), ((2, "env"), [(0, "env")], lambda e: e),
            ((2, "next"), [], lambda: ctx.newLabel()),
            ((0, "code"), [(1, "code"), (2, "code"), (2, "next")], lambda c1, c2, n: c1 + c2 + [f"{n}:"])],
        9: [((0, "code"), [], lambda: [])],
        10: [((3, "env"), [(0, "env")], lambda e: e),
             ((0, "vtype"), [(0, "env"), (1, "lex")], lambda e, n: e.get(n)),
             ((0, "code"), [(1, "lex"), (0, "vtype"), (3, "addr"), (3, "type"), (3, "code")],
              lambda n, vt, a, t, c: assign(ctx, n, vt, a, t, c, n.line))],
        11: [((3, "env"), [(0, "env")], lambda e: e), ((5, "env"), [(0, "env")], lambda e: e), ((7, "env"), [(0, "env")], lambda e: e),
             ((3, "true"), [], lambda: ctx.newLabel()), ((3, "false"), [], lambda: ctx.newLabel()),
             ((5, "next"), [(0, "next")], lambda n: n), ((7, "next"), [(0, "next")], lambda n: n),
             ((0, "code"), [(3, "code"), (3, "true"), (5, "code"), (0, "next"), (3, "false"), (7, "code")],
              lambda cc, t, s1, n, f, s2: cc + [f"{t}:"] + s1 + [f"goto {n}", f"{f}:"] + s2)],
        12: [((3, "env"), [(0, "env")], lambda e: e), ((5, "env"), [(0, "env")], lambda e: e),
             ((3, "true"), [], lambda: ctx.newLabel()), ((3, "false"), [], lambda: ctx.newLabel()),
             ((5, "next"), [(0, "next")], lambda n: n),
             ((0, "code"), [(3, "code"), (3, "true"), (5, "code"), (3, "false")], lambda cc, t, s1, f: cc + [f"{t}:"] + s1 + [f"{f}:"])],
        13: [((3, "env"), [(0, "env")], lambda e: e), ((5, "env"), [(0, "env")], lambda e: e),
             ((0, "begin"), [], lambda: ctx.newLabel()),
             ((3, "true"), [], lambda: ctx.newLabel()), ((3, "false"), [(0, "next")], lambda n: n),
             ((5, "next"), [(0, "begin")], lambda b: b),
             ((0, "code"), [(0, "begin"), (3, "code"), (3, "true"), (5, "code")],
              lambda b, cc, t, s1: [f"{b}:"] + cc + [f"{t}:"] + s1 + [f"goto {b}"])],
        14: [((2, "env"), [(0, "env")], lambda e: e), ((0, "code"), [(2, "code")], lambda c: c)],
        15: [((1, "env"), [(0, "env")], lambda e: e), ((3, "env"), [(0, "env")], lambda e: e),
             ((0, "code"), [(1, "addr"), (1, "type"), (1, "code"), (2, "lex"), (3, "addr"), (3, "type"), (3, "code"), (0, "true"), (0, "false")],
              lambda a1, t1, c1, op, a2, t2, c2, t, f: compare(ctx, a1, t1, c1, op, a2, t2, c2, t, f))],
        16: bin_("+"), 17: bin_("-"), 18: copy_(),
        19: bin_("*"), 20: bin_("/"), 21: copy_(),
        22: copy_(2),
        23: [((0, "addr"), [(1, "lex")], lambda n: n), ((0, "type"), [(0, "env"), (1, "lex")], lambda e, n: look(e, n)),
             ((0, "code"), [], lambda: [])],
        24: [((0, "addr"), [(1, "lex")], lambda n: n), ((0, "type"), [(1, "lex")], lambda n: num_type(n)),
             ((0, "code"), [], lambda: [])],
    }
    lexical = {s: {"lex": (lambda lx: lx)} for s in ("id", "num", "relop", "+", "-", "*", "/")}
    return SDD(LR_GRAMMAR, R, lexical)


INHERITED = {"env", "envin", "in", "next", "true", "false"}


def dfs_eval(tree, sdd):
    """L-attributed evaluation: inherited attributes of child i just before visiting child i,
    the head's synthesized attributes after the last child."""
    count = [0]
    def val(n, a):
        if a == "lex":
            return n.lexeme
        return n.attrs.get(a)
    def run(n, rule):
        (tp, ta), deps, f = rule
        tn = n if tp == 0 else n.children[tp - 1]
        args = [val(n if dp == 0 else n.children[dp - 1], da) for dp, da in deps]
        tn.attrs[ta] = f(*args); count[0] += 1
    def visit(n):
        rules = sdd.rules.get(n.prod, []) if n.prod is not None else []
        for i, c in enumerate(n.children, 1):
            for r in rules:
                if r[0][0] == i:
                    run(n, r)
            visit(c)
        for r in rules:
            if r[0][0] == 0:
                run(n, r)
    visit(tree)
    return count[0]


def two_pass(src, mode="dfs"):
    ctx = Ctx()
    kinds, lexes = lex(src)
    tree = LRP.parse(kinds, lexes)
    sdd = make_sdd(ctx)
    if mode == "dfs":
        evals = dfs_eval(tree, sdd)
        dg = None
    else:
        dg = DepGraph(tree, sdd)
        order, left = dg.topo()
        if left:
            raise RuntimeError("cycle")
        dg.evaluate(order)
        evals = len(order)
    return {"code": cleanup(tree.attrs["code"]), "errors": sorted(ctx.errors), "tree": tree, "dg": dg,
            "evals": evals, "nodes": tree.count()}
