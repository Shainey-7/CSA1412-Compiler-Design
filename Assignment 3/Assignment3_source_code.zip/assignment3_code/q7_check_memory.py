exec(open('q7_check_concat.py').read().split("for n in (400, 800, 1600):")[0])
import tracemalloc
for n in (400, 1600):
    src = progs[n]
    for lab, f in (("copy", orig), ("in-place", patched)):
        M.make_sdd = f
        tracemalloc.start(); r = M.two_pass(src, "dfs"); p = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        total = sum(len(x.attrs.get("code", [])) for x in r["tree"].walk() if x.sym == "SL")
        print("MEM", n, lab, f"peak {p/1024/1024:.1f} MiB, total list elements held by SL.code attributes {total}")
        del r
    M.make_sdd = orig
