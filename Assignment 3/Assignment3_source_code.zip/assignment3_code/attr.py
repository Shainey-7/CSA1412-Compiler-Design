"""
Attribute-grammar toolkit for Assignment 3 (Compiler Design, Unit III).

* Node            - parse-tree node holding attribute values
* build_tree      - LR (SLR) parse that returns a parse tree of Nodes
* SDD             - semantic rules attached to productions
* DepGraph        - dependency graph of an annotated parse tree,
                    topological evaluation (Kahn) with cycle detection
* dot helpers     - draw annotated trees and dependency graphs with Graphviz
"""
import os, subprocess, itertools
from collections import defaultdict, deque
from grammar import Grammar, LR, END, EPS

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")
os.makedirs(OUT, exist_ok=True)
_ids = itertools.count()


class Node:
    def __init__(self, sym, children=None, prod=None, lexeme=None):
        self.sym, self.children, self.prod, self.lexeme = sym, children or [], prod, lexeme
        self.attrs = {}
        self.uid = next(_ids)

    def is_leaf(self):
        return not self.children

    def walk(self):
        yield self
        for c in self.children:
            yield from c.walk()

    def count(self):
        return sum(1 for _ in self.walk())

    def height(self):
        return 0 if not self.children else 1 + max(c.height() for c in self.children)

    def show(self, attrs=(), indent=0, out=None):
        out = out if out is not None else []
        a = ", ".join(f"{k}={self.attrs[k]}" for k in attrs if k in self.attrs)
        lab = self.sym + (f" '{self.lexeme}'" if self.lexeme is not None and self.is_leaf() else "")
        out.append("  " * indent + lab + (f"   [{a}]" if a else ""))
        for c in self.children:
            c.show(attrs, indent + 1, out)
        return out


def tokenize(text, keywords=(), single="+-*/(),;=<>{}"):
    """returns (token kinds, lexemes); digits -> 'digit' when one char, else 'num'."""
    import re
    kinds, lex = [], []
    for m in re.finditer(r"\s*(\d+\.\d+|\d+|[A-Za-z_]\w*|<=|>=|==|!=|.)", text):
        t = m.group(1)
        if not t.strip():
            continue
        if t[0].isdigit():
            kinds.append("digit" if len(t) == 1 else "num")
        elif t in keywords:
            kinds.append(t)
        elif t[0].isalpha() or t[0] == "_":
            kinds.append("id")
        elif t in ("<", ">", "<=", ">=", "==", "!="):
            kinds.append("relop")
        else:
            kinds.append(t)
        lex.append(t)
    return kinds, lex


class Parser:
    """SLR parser over a Grammar that builds a parse tree and can run reduce-time actions."""

    def __init__(self, text, prefer_shift=True):
        self.g = Grammar(text)
        self.lr = LR(self.g)
        self.lr.slr(prefer_shift=prefer_shift)

    def parse(self, kinds, lexemes, on_reduce=None, on_shift=None, trace=None):
        toks = list(kinds) + [END]
        lex = list(lexemes) + ["$"]
        stack, nodes, i = [0], [], 0
        while True:
            s, a = stack[-1], toks[i]
            act = self.lr.action.get((s, a))
            if trace is not None:
                trace.append((list(stack), [n for n in nodes], toks[i:], act))
            if act is None:
                exp = sorted(t for (q, t) in self.lr.action if q == s)
                raise SyntaxError(f"syntax error at token {i + 1} '{lex[i]}': expected one of {', '.join(exp)}")
            if act[0] == "s":
                n = Node(a, lexeme=lex[i])
                if on_shift:
                    on_shift(n, nodes)
                stack.append(act[1]); nodes.append(n); i += 1
            elif act[0] == "r":
                p = act[1]
                lhs, rhs = self.lr.g.prods[p]
                kids = []
                for _ in rhs:
                    stack.pop(); kids.insert(0, nodes.pop())
                n = Node(lhs, kids, prod=p - 1)          # index into the user's grammar
                if not rhs:
                    n.children = []
                if on_reduce:
                    on_reduce(n, nodes)
                stack.append(self.lr.goto[(stack[-1], lhs)]); nodes.append(n)
            else:
                return nodes[0]


# ====================== SDD + dependency graph ======================
class SDD:
    """rules[prod_index] = list of (target, deps, fn)
       target/deps are (pos, attr) with pos 0 = the head, 1..n = body symbols.
       fn receives the dependency values in order. A target attr starting with '_'
       is a side effect (e.g. addType); its value is whatever fn returns."""

    def __init__(self, grammar_text, rules, lexical=None):
        self.g = Grammar(grammar_text)
        self.rules = rules
        self.lexical = lexical or {}          # sym -> {attr: fn(lexeme)}

    def rule_text(self):
        return self.texts


class DepGraph:
    def __init__(self, tree, sdd):
        self.tree, self.sdd = tree, sdd
        self.nodes = []                       # (Node, attr)
        self.index = {}
        self.edges = defaultdict(list)        # u -> [v]
        self.preds = defaultdict(list)
        self.fn = {}
        for n in tree.walk():
            if n.is_leaf() and n.sym in sdd.lexical:
                for a, f in sdd.lexical[n.sym].items():
                    k = self._add(n, a)
                    self.fn[k] = (lambda f=f, n=n: f(n.lexeme), [])
            if n.prod is None:
                continue
            for (tpos, tattr), deps, f in sdd.rules.get(n.prod, []):
                tnode = n if tpos == 0 else n.children[tpos - 1]
                t = self._add(tnode, tattr)
                dkeys = []
                for (dpos, dattr) in deps:
                    dnode = n if dpos == 0 else n.children[dpos - 1]
                    d = self._add(dnode, dattr)
                    dkeys.append(d)
                    self.edges[d].append(t); self.preds[t].append(d)
                self.fn[t] = (f, dkeys)

    def _add(self, node, attr):
        key = (node.uid, attr)
        if key not in self.index:
            self.index[key] = len(self.nodes)
            self.nodes.append((node, attr))
        return self.index[key]

    def topo(self, tie="fifo"):
        """Kahn's algorithm. tie: 'fifo', 'lifo' or 'rightfirst' (different but valid orders).
        Returns (order, leftover) - leftover non-empty means a cycle."""
        indeg = {k: len(self.preds[k]) for k in range(len(self.nodes))}
        ready = [k for k in range(len(self.nodes)) if indeg[k] == 0]
        if tie == "rightfirst":
            ready.sort(reverse=True)
        order = []
        dq = deque(ready)
        while dq:
            k = dq.pop() if tie in ("lifo", "rightfirst") else dq.popleft()
            order.append(k)
            for v in self.edges[k]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    dq.append(v)
        leftover = [k for k in range(len(self.nodes)) if indeg[k] > 0]
        return order, leftover

    def find_cycle(self, leftover):
        """walk predecessors inside the leftover set until a node repeats"""
        left = set(leftover)
        k = leftover[0]
        path = []
        seen = {}
        while k not in seen:
            seen[k] = len(path); path.append(k)
            k = next(p for p in self.preds[k] if p in left)
        return path[seen[k]:] + [k]

    def evaluate(self, order):
        for k in order:
            node, attr = self.nodes[k]
            f, deps = self.fn.get(k, (None, []))
            if f is None:
                continue
            vals = [self.nodes[d][0].attrs.get(self.nodes[d][1]) for d in deps]
            node.attrs[attr] = f(*vals)

    def name(self, k):
        node, attr = self.nodes[k]
        lab = node.sym + (f"({node.lexeme})" if node.lexeme is not None and node.is_leaf() else "")
        return f"{lab}.{attr}"


# ====================== drawing ======================
def render(src, name):
    p = os.path.join(OUT, name)
    open(p + ".dot", "w").write(src)
    subprocess.run(["dot", "-Tpng", "-Gdpi=150", p + ".dot", "-o", p + ".png"], check=True)


def esc(s):
    return str(s).replace('"', '\\"')


def annotated_dot(tree, attrs, name, title=None, leaf_attrs=None):
    L = ['digraph T {', 'graph [ordering=out, nodesep=0.22, ranksep=0.32, fontname="Helvetica"];',
         'node [fontname="Helvetica", fontsize=11, shape=plaintext];', 'edge [arrowhead=none, color="#666666"];']
    if title:
        L.append(f'labelloc="t"; label="{esc(title)}"; fontsize=12;')
    for n in tree.walk():
        if n.is_leaf() and n.lexeme is not None:
            extra = ""
            if leaf_attrs:
                extra = "\\n" + "\\n".join(f"{a}={n.attrs[a]}" for a in leaf_attrs if a in n.attrs)
            lab = f"{n.sym}" + (f"\\n{esc(n.lexeme)}" if n.lexeme != n.sym else "") + extra
            L.append(f'n{n.uid} [label="{lab}", shape=box, style="rounded,filled", fillcolor="#f2f2f2", color="#999999"];')
        elif n.is_leaf():
            L.append(f'n{n.uid} [label="ε", fontcolor="#888888"];')
        else:
            a = "\\n".join(f"{n.sym}.{k} = {esc(n.attrs[k])}" for k in attrs if k in n.attrs)
            lab = f"{n.sym}" if not a else a
            L.append(f'n{n.uid} [label="{lab}", fontcolor="#1f4e79", fontname="Helvetica-Bold"];')
        for c in n.children:
            L.append(f"n{n.uid} -> n{c.uid};")
    L.append("}")
    render("\n".join(L), name)


def depgraph_dot(dg, order, name, title=None, show_values=True, inherited=("in", "inh", "x", "y")):
    """Parse tree drawn normally (grey); each attribute instance is a red numbered ellipse placed on the
    same rank as its grammar symbol (inherited attributes on the left, synthesized on the right);
    red arrows are the dependency edges."""
    pos = {k: i + 1 for i, k in enumerate(order)}
    L = ['digraph G {', 'graph [ordering=out, nodesep=0.18, ranksep=0.55, fontname="Helvetica"];',
         'node [fontname="Helvetica", fontsize=10.5];']
    if title:
        L.append(f'labelloc="t"; label="{esc(title)}"; fontsize=12;')
    byn = defaultdict(list)
    for k, (n, a) in enumerate(dg.nodes):
        byn[n.uid].append(k)
    for n in dg.tree.walk():
        lab = n.sym + (f"\\n{esc(n.lexeme)}" if n.lexeme is not None and n.is_leaf() and n.lexeme != n.sym else "")
        shape = 'shape=box, style="rounded,filled", fillcolor="#f2f2f2", color="#aaaaaa"' if n.is_leaf() else 'shape=plaintext, fontname="Helvetica-Bold", fontcolor="#1f4e79"'
        L.append(f't{n.uid} [label="{lab}", {shape}];')
        ks = byn[n.uid]
        if ks:
            left = [k for k in ks if dg.nodes[k][1] in inherited]
            right = [k for k in ks if k not in left]
            for k in ks:
                node, attr = dg.nodes[k]
                v = node.attrs.get(attr)
                vs = f" = {esc(v)}" if show_values and v is not None and not attr.startswith("_") else ""
                L.append(f'a{k} [label="{pos.get(k, "?")}: {esc(attr)}{vs}", shape=ellipse, style=filled, fillcolor="#fdecea", color="#c0392b", fontsize=9.5, height=0.3];')
            seq = [f"a{k}" for k in left] + [f"t{n.uid}"] + [f"a{k}" for k in right]
            L.append("{ rank=same; " + " -> ".join(seq) + ' [style=dotted, arrowhead=none, color="#c0392b"]; }')
    for n in dg.tree.walk():
        for c in n.children:
            L.append(f't{n.uid} -> t{c.uid} [arrowhead=none, color="#999999"];')
    for u, vs in dg.edges.items():
        for v in vs:
            L.append(f'a{u} -> a{v} [color="#c0392b", penwidth=1.4, constraint=false];')
    L.append("}")
    render("\n".join(L), name)


def md_table(headers, rows):
    def e(s):
        s = str(s)
        for ch in ["\\", "*", "_", "|", "`", "<", ">", "[", "]", "#"]:
            s = s.replace(ch, "\\" + ch)
        return s if s else " "
    out = ["| " + " | ".join(e(h) for h in headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(e(c) for c in r) + " |")
    return "\n".join(out) + "\n"


def save(name, text):
    open(os.path.join(OUT, name), "w").write(text)
