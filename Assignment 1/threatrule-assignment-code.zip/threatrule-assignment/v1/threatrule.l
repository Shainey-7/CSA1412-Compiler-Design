/* ======================================================================
 *  threatrule.l  -  Lexical analyzer for the ThreatRule language (v1)
 *  Course : Compiler Design, Unit I (CO1)       Tool : flex 2.6.4
 *  Build  : flex -o lex.yy.c threatrule.l && gcc -O2 -o threatrule lex.yy.c
 * ====================================================================== */

/* ---------- Section 1 : DECLARATIONS ---------------------------------- */
%option noyywrap yylineno stack
%option nounput noinput noyy_top_state nodefault

%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

/* token codes returned to the parser (the attribute travels in yylval) */
enum { T_RULE = 258, T_IF, T_AND, T_OR, T_THEN, T_ALERT, T_BLOCK,
       T_ID, T_IP, T_PORT, T_INT, T_STRING, T_RELOP, T_SEMI };
enum { REL_EQ, REL_NE, REL_LT, REL_LE, REL_GT, REL_GE };

typedef struct { int ival; const char *sval; int slen; } YYSTYPE;
YYSTYPE yylval;                 /* attribute value of the last token      */

/* statistics and flags, used by main() and the error routine */
static long n_errors = 0;
static int  quiet = 0;          /* -q : count only, do not print errors   */
static int  comment_start = 0;  /* line on which a block comment began    */

/* ---- symbol table (chained hash table, keyed by lexeme) --------------- */
typedef struct sym { char *name; int index; struct sym *next; } sym;
#define NBUCKET 65536
static sym *bucket[NBUCKET];
static int  n_syms = 0;

static unsigned hash_str(const char *s, int n)
{   unsigned h = 5381;
    while (n--) h = h * 33u + (unsigned char)*s++;
    return h & (NBUCKET - 1);
}

/* install_id: return the table index of an identifier, adding it if new */
static int install_id(const char *s, int n)
{   unsigned h = hash_str(s, n);
    sym *p;
    for (p = bucket[h]; p; p = p->next)
        if ((int)strlen(p->name) == n && memcmp(p->name, s, n) == 0)
            return p->index;
    p = malloc(sizeof *p);
    p->name = malloc(n + 1);
    memcpy(p->name, s, n); p->name[n] = '\0';
    p->index = n_syms++;
    p->next = bucket[h]; bucket[h] = p;
    return p->index;
}

/* ---- error reporting: message + line number, then scanning goes on ---- */
static void lex_error(const char *fmt, ...)
{   va_list ap;
    n_errors++;
    if (quiet) return;
    fprintf(stderr, "Lexical error at line %d: ", yylineno);
    va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
    fputc('\n', stderr);
}

/* after any token other than a relational operator the "port" context ends */
#define RET(t) do { if ((t) != T_RELOP && YY_START == AFTERPORT) \
                        BEGIN(INITIAL);                           \
                    return (t); } while (0)
%}

/* ---- regular definitions ---------------------------------------------- */
DIGIT    [0-9]
LETTER   [A-Za-z_]
ID       {LETTER}({LETTER}|{DIGIT})*
INT      {DIGIT}+
OCTET    (25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])
IP       {OCTET}\.{OCTET}\.{OCTET}\.{OCTET}
BADIP    {DIGIT}+\.{DIGIT}+\.{DIGIT}+\.{DIGIT}+
PORTNUM  ([0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])
STRING   \"[^\"\n]*\"
BADSTR   \"[^\"\n]*

%s AFTERPORT
%x COMMENT

/* ---------- Section 2 : TRANSLATION RULES ----------------------------- */
%%

"/*"                  { yy_push_state(COMMENT); comment_start = yylineno; }
<COMMENT>"*/"         { yy_pop_state(); }
<COMMENT>[^*\n]+      { /* swallow comment text */ }
<COMMENT>"*"          { /* a lone star inside a comment */ }
<COMMENT>\n           { /* yylineno is advanced by flex */ }
<COMMENT><<EOF>>      { lex_error("unterminated /* comment (opened on line %d)",
                                  comment_start);
                        yyterminate(); }

#[^\n]*               { /* line comment: discarded */ }
[ \t\r]+              { /* white space: discarded */ }
\n                    { /* newline: only the line counter changes */ }

"RULE"                { RET(T_RULE);  }
"IF"                  { RET(T_IF);    }
"AND"                 { RET(T_AND);   }
"OR"                  { RET(T_OR);    }
"THEN"                { RET(T_THEN);  }
"ALERT"               { RET(T_ALERT); }
"BLOCK"               { RET(T_BLOCK); }

{IP}                  { yylval.sval = yytext; yylval.slen = yyleng; RET(T_IP); }
{BADIP}               { lex_error("invalid IP address '%s' (octets must be 0-255, no leading zeros)", yytext); }

{ID}                  { yylval.ival = install_id(yytext, yyleng);
                        yylval.sval = yytext; yylval.slen = yyleng;
                        if (yyleng == 4 && memcmp(yytext, "port", 4) == 0) {
                            BEGIN(AFTERPORT); return T_ID;   /* next number is a PORT */
                        }
                        RET(T_ID); }

<AFTERPORT>{PORTNUM}  { yylval.ival = atoi(yytext); BEGIN(INITIAL); return T_PORT; }
<AFTERPORT>{INT}      { lex_error("port '%s' is out of range 0-65535 (or has leading zeros)", yytext);
                        BEGIN(INITIAL); }
{INT}                 { yylval.ival = (int)strtol(yytext, NULL, 10);
                        yylval.sval = yytext; yylval.slen = yyleng; RET(T_INT); }

{STRING}              { yylval.sval = yytext + 1; yylval.slen = yyleng - 2; RET(T_STRING); }
{BADSTR}              { lex_error("unterminated string literal starting with %.20s", yytext); }

"=="                  { yylval.ival = REL_EQ; RET(T_RELOP); }
"!="                  { yylval.ival = REL_NE; RET(T_RELOP); }
"<="                  { yylval.ival = REL_LE; RET(T_RELOP); }
">="                  { yylval.ival = REL_GE; RET(T_RELOP); }
"<"                   { yylval.ival = REL_LT; RET(T_RELOP); }
">"                   { yylval.ival = REL_GT; RET(T_RELOP); }
";"                   { RET(T_SEMI); }
"="                   { lex_error("single '=' is not an operator (did you mean '=='?)"); }

.                     { lex_error("illegal character '%c' (0x%02X)",
                                  (yytext[0] >= 32 && yytext[0] < 127) ? yytext[0] : '?',
                                  (unsigned char)yytext[0]); }

%%
/* ---------- Section 3 : AUXILIARY FUNCTIONS --------------------------- */
static const char *tname[] = { "RULE","IF","AND","OR","THEN","ALERT","BLOCK",
    "ID","IP","PORT","INT","STRING","RELOP","SEMI" };
static const char *rname[] = { "EQ","NE","LT","LE","GT","GE" };

static void print_token(int t)
{   printf("%4d  <%s", yylineno, tname[t - 258]);
    switch (t) {
    case T_ID:     printf(", %d, %.*s", yylval.ival, yylval.slen, yylval.sval); break;
    case T_IP:     printf(", %.*s", yylval.slen, yylval.sval); break;
    case T_PORT:
    case T_INT:    printf(", %d", yylval.ival); break;
    case T_STRING: printf(", \"%.*s\"", yylval.slen, yylval.sval); break;
    case T_RELOP:  printf(", %s", rname[yylval.ival]); break;
    }
    printf(">\n");
}

int main(int argc, char **argv)
{   int verbose = 0, i, t, c;
    long n_tok = 0, n_lines = 0;
    const char *path = NULL;
    struct timespec t0, t1;
    FILE *f;

    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-v")) verbose = 1;
        else if (!strcmp(argv[i], "-q")) quiet = 1;
        else path = argv[i];
    }
    if (!path || !(f = fopen(path, "rb"))) {
        fprintf(stderr, "usage: %s [-v] [-q] rulefile\n", argv[0]); return 2; }
    while ((c = fgetc(f)) != EOF) if (c == '\n') n_lines++;   /* line count */
    rewind(f);
    yyin = f;

    clock_gettime(CLOCK_MONOTONIC, &t0);
    while ((t = yylex()) != 0) {
        n_tok++;
        if (verbose) print_token(t);
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);

    printf("SUMMARY lines=%ld tokens=%ld errors=%ld symbols=%d time_ms=%.3f\n",
           n_lines, n_tok, n_errors, n_syms,
           (t1.tv_sec - t0.tv_sec) * 1e3 + (t1.tv_nsec - t0.tv_nsec) / 1e6);
    fclose(f);
    return n_errors ? 1 : 0;
}
