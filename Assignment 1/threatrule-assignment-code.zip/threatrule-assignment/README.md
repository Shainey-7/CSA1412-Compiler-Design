# ThreatRule lexical analyzer (Compiler Design, Assignment 1, CO1)

Requires: flex 2.6.x, gcc, python3 (+ matplotlib for figures).

    cd v1 && flex -o lex.yy.c threatrule.l && gcc -O2 -Wall -o threatrule lex.yy.c && cd ..
    cd v2 && flex -o lex.yy.c threatrule_v2.l && gcc -O2 -Wall -o threatrule_v2 lex.yy.c && cd ..
    python3 tools/run_cases.py       # functional tests
    # regenerate the 100,000-rule files (not shipped, ~12 MB each):
    python3 tools/gen_rules.py orig 100000 tests/orig_clean_100000.tr
    python3 tools/gen_rules.py orig 100000 tests/orig_faulty_100000.tr --faulty --seed 7
    python3 tools/bench.py           # timing + count checks (also builds a 1M-rule file in /tmp)

Optional -Cf builds used in the report: `flex -Cf -o lexCf.c <spec>` then gcc as above;
bench.py expects them as v1/threatrule_Cf and v2/threatrule_v2_Cf.
Timings depend on your machine; token and error counts must match the .expect.json files.
