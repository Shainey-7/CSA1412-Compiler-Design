#!/usr/bin/env python3
"""make_figs.py - draws every figure used in the report.
Diagrams: Graphviz.  Graphs: matplotlib, reading the measured results (results/bench.json)."""
import json, os, subprocess
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = os.path.join(ROOT, "figs")
FONT = "DejaVu Sans"
os.makedirs(F, exist_ok=True)


def dot(name, src):
    p = os.path.join(F, name + ".dot")
    open(p, "w").write(src)
    subprocess.run(["dot", "-Tpng", "-Gdpi=200", p, "-o", os.path.join(F, name + ".png")], check=True)


HEAD = f'''graph [fontname="{FONT}", fontsize=11, pad=0.2];
node [fontname="{FONT}", fontsize=11];
edge [fontname="{FONT}", fontsize=10];'''

# ---------------------------------------------------------------- Fig 1
dot("fig01_language_processing", f'''digraph G {{
{HEAD}
rankdir=TB; nodesep=0.5; ranksep=0.38;
node [shape=box, style="rounded,filled", fillcolor="#EAF2FB", color="#4A6FA5", margin="0.18,0.10"];
src  [label="ThreatRule source programs\\n(rules from branch SOCs + shared include files)", shape=note, fillcolor="#FFF4D6", color="#B38600"];
pre  [label="PREPROCESSOR\\nexpands INCLUDE files and macros, joins the rule files"];
msrc [label="Modified ThreatRule source", shape=note, fillcolor="#FFF4D6", color="#B38600"];
comp [label="COMPILER (ThreatRule compiler)\\nscanner + parser + semantic analysis + optimiser + code generator\\n(this assignment builds the scanner)", fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
asrc [label="Target assembly program\\n(detection-engine instructions)", shape=note, fillcolor="#FFF4D6", color="#B38600"];
asm  [label="ASSEMBLER\\ntranslates mnemonics to relocatable machine code"];
rel  [label="Relocatable machine code", shape=note, fillcolor="#FFF4D6", color="#B38600"];
lib  [label="Library files and other\\nrelocatable objects\\n(rule runtime, event schema,\\nrules compiled by other branches)", shape=note, fillcolor="#F3E8F7", color="#8E5AA8"];
link [label="LINKER\\nresolves external references, combines modules"];
abs  [label="Absolute machine code", shape=note, fillcolor="#FFF4D6", color="#B38600"];
load [label="LOADER\\nplaces the code at its memory addresses"];
eng  [label="Central SOC detection engine\\nlog events in  →  alerts / blocks out", fillcolor="#FBE3E3", color="#B34040", penwidth=2];
src -> pre -> msrc -> comp -> asrc -> asm -> rel -> link -> abs -> load -> eng;
lib -> link [style=dashed];
}}''')

# ---------------------------------------------------------------- Fig 2 (matplotlib, clean side panels)
fig, ax = plt.subplots(figsize=(7.4, 7.6))
ax.set_xlim(0, 14); ax.set_ylim(0, 16.4); ax.axis("off")
phases = ["1. Lexical analysis (scanner)", "2. Syntax analysis (parser)", "3. Semantic analysis",
          "4. Intermediate code generation", "5. Code optimisation", "6. Code generation"]
outs = ["character stream: the rule text", "token stream", "syntax tree", "annotated syntax tree",
        "three-address code", "optimised three-address code", "target code (detection-engine instructions)"]
ys = [14.2 - i * 2.4 for i in range(6)]          # top of each phase box
cx = 7.0
ax.text(cx, 16.0, outs[0], ha="center", va="center", fontsize=9, style="italic")
ax.annotate("", xy=(cx, ys[0] + 0.0), xytext=(cx, 15.6), arrowprops=dict(arrowstyle="-|>", color="black"))
for i, (y, p) in enumerate(zip(ys, phases)):
    ax.add_patch(Rectangle((cx - 2.6, y - 1.0), 5.2, 1.0, fc="#EAF2FB", ec="#4A6FA5", lw=1.4))
    ax.text(cx, y - 0.5, p, ha="center", va="center", fontsize=9.5, weight="bold")
    ax.annotate("", xy=(cx, y - 1.0 - 0.95), xytext=(cx, y - 1.0), arrowprops=dict(arrowstyle="-|>", color="black"))
    ax.text(cx, y - 1.0 - 1.15, outs[i + 1], ha="center", va="center", fontsize=8.5, style="italic",
            bbox=dict(fc="white", ec="none", pad=1))
# tall side panels
ax.add_patch(Rectangle((0.2, 0.9), 2.6, 13.6, fc="#FFF4D6", ec="#B38600", lw=1.6))
ax.text(1.5, 7.7, "SYMBOL\nTABLE\n\nnames,\ntypes and\nattributes\nshared by\nall phases", ha="center", va="center", fontsize=9)
ax.add_patch(Rectangle((11.2, 8.4), 2.6, 6.1, fc="#FBE3E3", ec="#B34040", lw=1.6))
ax.text(12.5, 11.45, "ERROR\nHANDLER\n\nreport the\nerror, recover,\nkeep going", ha="center", va="center", fontsize=9)
for y in ys:
    ax.annotate("", xy=(2.8, y - 0.5), xytext=(cx - 2.6, y - 0.5), arrowprops=dict(arrowstyle="<|-|>", color="#B38600", lw=1.1))
for y in ys[:3]:
    ax.annotate("", xy=(11.2, y - 0.5), xytext=(cx + 2.6, y - 0.5), arrowprops=dict(arrowstyle="-|>", color="#B34040", lw=1.1))
fig.tight_layout()
fig.savefig(os.path.join(F, "fig02_phases.png"), dpi=200)
plt.close(fig)

# ---------------------------------------------------------------- Fig 3
dot("fig03_grouping", f'''digraph G {{
{HEAD}
rankdir=TB; nodesep=0.35; ranksep=0.5; compound=true; newrank=true;
node [shape=box, style="rounded,filled", fillcolor="#EAF2FB", color="#4A6FA5", margin="0.14,0.08"];
src [label="ThreatRule rule file", shape=note, fillcolor="#FFF4D6", color="#B38600"];
subgraph cluster_front {{
  label="FRONT END (analysis): machine-independent, written once"; labeljust=c; style="rounded,filled"; fillcolor="#F2F8F2"; color="#3F8F3F"; penwidth=2;
  lex [label="Lexical\\nanalysis"]; syn [label="Syntax\\nanalysis"]; sem [label="Semantic\\nanalysis"]; icg [label="Intermediate\\ncode generator"];
  {{rank=same; lex; syn; sem; icg}}
  lex -> syn -> sem -> icg;
}}
ir [label="Intermediate representation (three-address code)", shape=note, fillcolor="#FFF4D6", color="#B38600"];
subgraph cluster_back {{
  label="BACK END (synthesis): tool-dependent, one code generator per tool"; labeljust=c; style="rounded,filled"; fillcolor="#FDF3F3"; color="#B34040"; penwidth=2;
  opt [label="Code optimiser"];
  b1 [label="Code generator A\\nSnort / Suricata rules"]; b2 [label="Code generator B\\nSplunk searches"]; b3 [label="Code generator C\\nElastic queries"];
  {{rank=same; b1; b2; b3}}
  opt -> b1; opt -> b2; opt -> b3;
}}
st [label="Symbol table and error handler (shared by every phase)", shape=box3d, fillcolor="#FFF4D6", color="#B38600"];
src -> lex; icg -> ir; ir -> opt;
st -> sem [style=dashed, constraint=false];
}}''')

# ---------------------------------------------------------------- Fig 4 : syntax tree
dot("fig04_syntax_tree", f'''digraph G {{
{HEAD}
rankdir=TB; nodesep=0.28; ranksep=0.45;
node [shape=ellipse, style=filled, fillcolor="#EAF2FB", color="#4A6FA5", margin="0.10,0.05"];
R   [label="rule\\nssh_attack", fillcolor="#DDF0DD", color="#3F8F3F"];
C1  [label="AND"]; C2 [label="AND"];
E1  [label="=="]; E2 [label="=="]; G1 [label=">"];
A   [label="ALERT", fillcolor="#FBE3E3", color="#B34040"];
n1 [label="src_ip", shape=box, fillcolor="#FFF4D6", color="#B38600"]; n2 [label="10.0.0.5", shape=box, fillcolor="#FFF4D6", color="#B38600"];
n3 [label="port", shape=box, fillcolor="#FFF4D6", color="#B38600"];   n4 [label="22", shape=box, fillcolor="#FFF4D6", color="#B38600"];
n5 [label="attempts", shape=box, fillcolor="#FFF4D6", color="#B38600"]; n6 [label="5", shape=box, fillcolor="#FFF4D6", color="#B38600"];
m  [label="\\"SSH brute force\\"", shape=box, fillcolor="#FFF4D6", color="#B38600"];
R -> C1 [label=" condition"]; R -> A [label=" action"];
C1 -> C2; C1 -> G1; C2 -> E1; C2 -> E2;
E1 -> n1; E1 -> n2; E2 -> n3; E2 -> n4; G1 -> n5; G1 -> n6; A -> m;
}}''')


# ---------------------------------------------------------------- transition diagrams
def td(name, body, rankdir="LR"):
    dot(name, f'''digraph G {{
{HEAD}
rankdir={rankdir}; nodesep=0.45; ranksep=0.55; forcelabels=true;
node [shape=circle, style=filled, fillcolor="#EAF2FB", color="#4A6FA5", fixedsize=true, width=0.5];
start [shape=plaintext, label="start", style="", width=0.4];
{body}
}}''')


td("fig05_td_relop", '''
start -> s0;
s0 [label="0"]; s1 [label="1"]; s2 [label="2"]; s4 [label="4"]; s5 [label="5"]; s6 [label="6"]; s7 [label="7"]; s9 [label="9"]; s10 [label="10"];
s0 [fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
s0 -> s1 [label="<"]; s1 -> s2 [label="="]; s1 -> s3 [label="other"];
s0 -> s4 [label="="]; s4 -> s5 [label="="]; s4 -> e1 [label="other"];
s0 -> s6 [label=">"]; s6 -> s7 [label="="]; s6 -> s8 [label="other"];
s0 -> s9 [label="!"]; s9 -> s10 [label="="]; s9 -> e2 [label="other"];
s2  [shape=doublecircle, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">RELOP, LE</font>>];
s3  [shape=doublecircle, label="3 *", width=0.6, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">retract; RELOP, LT</font>>];
s5  [shape=doublecircle, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">RELOP, EQ</font>>];
s7  [shape=doublecircle, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">RELOP, GE</font>>];
s8  [shape=doublecircle, label="8 *", width=0.6, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">retract; RELOP, GT</font>>];
s10 [shape=doublecircle, fillcolor="#FFF4D6", color="#B38600", xlabel=<<font point-size="9">RELOP, NE</font>>];
e1  [shape=doublecircle, label="E *", width=0.6, fillcolor="#FBE3E3", color="#B34040", xlabel=<<font point-size="9">retract; error: single =</font>>];
e2  [shape=doublecircle, label="E *", width=0.6, fillcolor="#FBE3E3", color="#B34040", xlabel=<<font point-size="9">retract; error: stray !</font>>];
''')

td("fig06_td_identifier", '''
start -> s0;
s0 [label="0"]; s1 [label="1"];
s0 [fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
s0 -> s1 [label="letter or _"];
s1 -> s1 [label="letter, digit or _"];
s1 -> s2 [label="other"];
s2 [shape=doublecircle, label="2 *", width=0.6, fillcolor="#FFF4D6", color="#B38600",
    xlabel=<<font point-size="9">retract; lexeme in keyword table?<br/>yes: return keyword token<br/>no: install_id; return (ID, index)</font>>];
''')

td("fig07_td_integer", '''
start -> s0;
s0 [label="0"]; s1 [label="1"];
s0 [fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
s0 -> s1 [label="digit"];
s1 -> s1 [label="digit"];
s1 -> s2 [label="other"];
s2 [shape=doublecircle, label="2 *", width=0.6, fillcolor="#FFF4D6", color="#B38600",
    xlabel=<<font point-size="9">retract; if previous token was "port ==" and value in 0-65535<br/>return (PORT, value) else if in port context: error<br/>else return (INT, value)</font>>];
''')


td("fig08a_td_octet", '''
start -> s0;
s0 [label="0", fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
s1 [label="1"]; s2 [label="2"]; s3 [label="3"];
s0 -> s1 [label="digit"]; s1 -> s2 [label="digit"]; s2 -> s3 [label="digit"];
s1 -> s4 [label="other"]; s2 -> s4 [label="other"]; s3 -> s4 [label="other"];
s4 [shape=doublecircle, label="4 *", width=0.6, fillcolor="#FFF4D6", color="#B38600",
    xlabel=<<font point-size="9">retract; value &lt;= 255 and no leading zero?<br/>yes: octet accepted   no: error (invalid IP)</font>>];
''')

td("fig08b_td_ip", '''
start -> s0;
s0 [label="0", fillcolor="#DDF0DD", color="#3F8F3F", penwidth=2];
s1 [label="1"]; s2 [label="2"]; s3 [label="3"]; s4 [label="4"]; s5 [label="5"]; s6 [label="6"];
s0 -> s1 [label="octet"]; s1 -> s2 [label="."]; s2 -> s3 [label="octet"]; s3 -> s4 [label="."];
s4 -> s5 [label="octet"]; s5 -> s6 [label="."];
s6 -> s7 [label="octet"];
s7 [shape=doublecircle, label="7 *", width=0.6, fillcolor="#FFF4D6", color="#B38600",
    xlabel=<<font point-size="9">retract (done inside the octet diagram)<br/>return (IP, lexeme)</font>>];
''', rankdir="LR")

# ---------------------------------------------------------------- Fig 9 : buffer pair
fig, ax = plt.subplots(figsize=(9.2, 3.5))
ax.set_xlim(0, 24); ax.set_ylim(0, 8.2); ax.axis("off")
chars = list("IF port == 22 AND attempts > 5 ")
N = 16
cells = [("", None)]
# first half
for i in range(N):
    ax.add_patch(Rectangle((0.5 + i * 0.7, 4.2), 0.7, 1.0, fc="#EAF2FB", ec="#4A6FA5"))
    ch = chars[i] if i < len(chars) else ""
    ax.text(0.5 + i * 0.7 + 0.35, 4.7, ch, ha="center", va="center", fontsize=9, family="monospace")
ax.add_patch(Rectangle((0.5 + N * 0.7, 4.2), 0.7, 1.0, fc="#F8D7D7", ec="#B34040"))
ax.text(0.5 + N * 0.7 + 0.35, 4.7, "eof", ha="center", va="center", fontsize=8, color="#B34040", weight="bold")
off = 0.5 + (N + 1) * 0.7
for i in range(N):
    ax.add_patch(Rectangle((off + i * 0.7, 4.2), 0.7, 1.0, fc="#F2F8F2", ec="#3F8F3F"))
    j = N + i
    ch = chars[j] if j < len(chars) else ""
    ax.text(off + i * 0.7 + 0.35, 4.7, ch, ha="center", va="center", fontsize=9, family="monospace")
ax.add_patch(Rectangle((off + N * 0.7, 4.2), 0.7, 1.0, fc="#F8D7D7", ec="#B34040"))
ax.text(off + N * 0.7 + 0.35, 4.7, "eof", ha="center", va="center", fontsize=8, color="#B34040", weight="bold")
ax.text(0.5 + N * 0.35, 5.7, "buffer half 1  (N characters)", ha="center", fontsize=10, color="#4A6FA5")
ax.text(off + N * 0.35, 5.7, "buffer half 2  (N characters)", ha="center", fontsize=10, color="#3F8F3F")
ax.text(0.5 + N * 0.7 + 0.35, 6.45, "sentinel", ha="center", fontsize=9, color="#B34040")
ax.text(off + N * 0.7 + 0.35, 6.45, "sentinel", ha="center", fontsize=9, color="#B34040")
# pointers: lexemeBegin at 'p' of port (index 3), forward at index 6 (after 'port ')
for idx, label, y0, col in ((3, "lexemeBegin", 2.2, "#B38600"), (7, "forward", 2.2, "#B34040")):
    x = 0.5 + idx * 0.7 + 0.35
    ax.add_patch(FancyArrowPatch((x, y0 + 0.9), (x, 4.15), arrowstyle="-|>", mutation_scale=14, color=col, lw=1.6))
    ax.text(x, y0 + 0.4, label, ha="center", fontsize=10, color=col, weight="bold")
ax.text(12, 0.7, "forward scans right; when it meets 'eof' it either reloads the other half\n"
        "(eof at a half boundary) or the input is finished (eof inside a half).\n"
        "Only ONE test per character is needed instead of two (end-of-buffer test + character test).",
        ha="center", fontsize=9)
fig.tight_layout()
fig.savefig(os.path.join(F, "fig09_buffer_pair.png"), dpi=200)
plt.close(fig)

# ---------------------------------------------------------------- performance graphs
B = json.load(open(os.path.join(ROOT, "results", "bench.json")))
sizes = [100, 1000, 10000, 100000]
C = {"v1": "#4A6FA5", "v1Cf": "#3F8F3F", "v2": "#B38600", "v2Cf": "#B34040"}
LAB = {"v1": "v1 default tables", "v1Cf": "v1 full tables (flex -Cf)"}
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3})


def val(kind, n, tag, key):
    return B["files"][f"orig_{kind}_{n}.tr"][tag][key]


# Fig 10 : scanning time
fig, ax = plt.subplots(figsize=(6.2, 3.6))
for tag in ("v1", "v1Cf"):
    ys = [val("clean", n, tag, "time_ms") for n in sizes]
    ax.plot(sizes, ys, marker="o", color=C[tag], label=LAB[tag])
    for x, y in zip(sizes, ys):
        ax.annotate(f"{y:.2f}" if y < 10 else f"{y:.0f}", (x, y), textcoords="offset points", xytext=(0, 6 if tag == "v1" else -13), ha="center", fontsize=7)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("number of rules"); ax.set_ylabel("scanning time (ms, median of 9)")
ax.set_title("Fig. 10  Scanning time against number of rules"); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(F, "fig10_time.png"), dpi=200); plt.close(fig)

# Fig 11 : tokens
fig, ax = plt.subplots(figsize=(6.2, 3.6))
xs = range(len(sizes)); w = 0.38
ax.bar([x - w / 2 for x in xs], [val("clean", n, "v1", "tokens") for n in sizes], w, color="#4A6FA5", label="clean files")
ax.bar([x + w / 2 for x in xs], [val("faulty", n, "v1", "tokens") for n in sizes], w, color="#B38600", label="files with injected faults")
ax.set_yscale("log"); ax.set_xticks(list(xs)); ax.set_xticklabels([f"{n:,}" for n in sizes])
for x, n in zip(xs, sizes):
    ax.text(x - w / 2, val("clean", n, "v1", "tokens") * 1.12, f"{val('clean', n, 'v1', 'tokens'):,}", ha="center", fontsize=6.5)
ax.set_xlabel("number of rules"); ax.set_ylabel("tokens produced")
ax.set_title("Fig. 11  Tokens produced against number of rules"); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(F, "fig11_tokens.png"), dpi=200); plt.close(fig)

# Fig 12 : errors
fig, ax = plt.subplots(figsize=(6.2, 3.6))
exp = [B["files"][f"orig_faulty_{n}.tr"]["expect"]["errors"] for n in sizes]
det = [val("faulty", n, "v1", "errors") for n in sizes]
ax.bar([x - w / 2 for x in xs], exp, w, color="#999999", label="faults injected by the generator")
ax.bar([x + w / 2 for x in xs], det, w, color="#B34040", label="lexical errors reported by the scanner")
ax.set_yscale("log"); ax.set_xticks(list(xs)); ax.set_xticklabels([f"{n:,}" for n in sizes])
for x, e, d in zip(xs, exp, det):
    ax.text(x + w / 2, d * 1.15, str(d), ha="center", fontsize=7)
ax.set_xlabel("number of rules"); ax.set_ylabel("lexical errors")
ax.set_title("Fig. 12  Lexical errors detected (faulty files)"); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(F, "fig12_errors.png"), dpi=200); plt.close(fig)

# Fig 13 : throughput
fig, ax = plt.subplots(figsize=(6.2, 3.6))
for tag, off_ in (("v1", -w / 2), ("v1Cf", w / 2)):
    ys = [B["files"][f"orig_clean_{n}.tr"][tag]["bytes"] / 1e6 / (val("clean", n, tag, "time_ms") / 1e3) for n in sizes]
    ax.bar([x + off_ for x in xs], ys, w, color=C[tag], label=LAB[tag])
    for x, y in zip(xs, ys):
        ax.text(x + off_, y + 5, f"{y:.0f}", ha="center", fontsize=7)
ax.set_xticks(list(xs)); ax.set_xticklabels([f"{n:,}" for n in sizes])
ax.set_xlabel("number of rules"); ax.set_ylabel("throughput (MB of rules per second)")
ax.set_title("Fig. 13  Scanner throughput"); ax.legend(loc="lower right")
fig.tight_layout(); fig.savefig(os.path.join(F, "fig13_throughput.png"), dpi=200); plt.close(fig)

# Fig 14 : original vs modified on the 5000-rule feed file
A = json.load(open(os.path.join(ROOT, "results", "feed_analysis.json")))
fe = B["files"]["feed_clean_5000.tr"]
fig, axs = plt.subplots(1, 3, figsize=(9.0, 3.4))
lits = sum(A["literals"].values())
axs[0].bar(["v1\n(original)", "v2\n(modified)"], [0, sum(A[k]["v2_recognised"] for k in ("hash", "cve", "url"))], color=["#4A6FA5", "#3F8F3F"])
axs[0].set_title(f"Feed literals recognised\ncorrectly (of {lits:,})", fontsize=9)
for i, v in enumerate([0, lits]):
    axs[0].text(i, v + 150, f"{v:,}", ha="center", fontsize=8)
axs[0].set_ylim(0, lits * 1.15)
axs[1].bar(["v1\n(original)", "v2\n(modified)"], [fe["v1"]["errors"], fe["v2"]["errors"]], color=["#B34040", "#3F8F3F"])
axs[1].set_title("Spurious lexical errors\non the clean feed", fontsize=9)
for i, v in enumerate([fe["v1"]["errors"], fe["v2"]["errors"]]):
    axs[1].text(i, v + 600, f"{v:,}", ha="center", fontsize=8)
axs[1].set_ylim(0, fe["v1"]["errors"] * 1.15)
tags = ["v1", "v2", "v2Cf"]
axs[2].bar(["v1", "v2", "v2\n-Cf"], [fe[t]["time_ms"] for t in tags], color=["#4A6FA5", "#B38600", "#B34040"])
axs[2].set_title("Scanning time (ms)\n5,000-rule feed file", fontsize=9)
for i, t in enumerate(tags):
    axs[2].text(i, fe[t]["time_ms"] + 0.2, f"{fe[t]['time_ms']:.1f}", ha="center", fontsize=8)
fig.suptitle("Fig. 14  Original design (v1) against modified design (v2)", fontsize=10)
fig.tight_layout(); fig.savefig(os.path.join(F, "fig14_v1_vs_v2.png"), dpi=200); plt.close(fig)
print("figures written to", F)
