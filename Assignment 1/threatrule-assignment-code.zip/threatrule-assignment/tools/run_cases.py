#!/usr/bin/env python3
"""run_cases.py - functional tests: valid, invalid and boundary inputs.
Each case lists the input and the HAND-WRITTEN expected tokens and the lines
on which lexical errors must be reported. The scanner output is compared
with these expectations (not with its own earlier output)."""
import json, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V1 = os.path.join(ROOT, "v1", "threatrule")
V2 = os.path.join(ROOT, "v2", "threatrule_v2")

SAMPLE = 'RULE ssh_attack IF src_ip == 10.0.0.5 AND port == 22 AND attempts > 5 THEN ALERT "SSH brute force" ;\n'

# (id, description, input text, expected tokens (list), expected error lines (list), applies to v1?)
CASES = [
 ("1", "Sample rule from the scenario", SAMPLE,
  ["RULE","ID(ssh_attack)","IF","ID(src_ip)","RELOP(EQ)","IP(10.0.0.5)","AND","ID(port)","RELOP(EQ)","PORT(22)","AND",
   "ID(attempts)","RELOP(GT)","INT(5)","THEN","ALERT","STRING(SSH brute force)","SEMI"], []),
 ("2", "Boundary IP 0.0.0.0", "src_ip == 0.0.0.0\n",
  ["ID(src_ip)","RELOP(EQ)","IP(0.0.0.0)"], []),
 ("3", "Boundary IP 255.255.255.255", "src_ip == 255.255.255.255\n",
  ["ID(src_ip)","RELOP(EQ)","IP(255.255.255.255)"], []),
 ("4", "Boundary port 65535", "port == 65535\n",
  ["ID(port)","RELOP(EQ)","PORT(65535)"], []),
 ("5", "Boundary port 0", "port == 0\n",
  ["ID(port)","RELOP(EQ)","PORT(0)"], []),
 ("6", "Invalid port 65536", "port == 65536\n",
  ["ID(port)","RELOP(EQ)"], [1]),
 ("7", "Invalid IP 256.1.1.1", "src_ip == 256.1.1.1\n",
  ["ID(src_ip)","RELOP(EQ)"], [1]),
 ("8", "Faulty line 1: 10.0.300.5", "src_ip == 10.0.300.5\n",
  ["ID(src_ip)","RELOP(EQ)"], [1]),
 ("9", "Faulty line 2: unterminated string (error on line 1, line 2 still scanned)",
  'ALERT "Login failed ;\nBLOCK ;\n',
  ["ALERT","BLOCK","SEMI"], [1]),
 ("10", "Faulty line 3: stray @", "port == 22 @ attempts > 5\n",
  ["ID(port)","RELOP(EQ)","PORT(22)","ID(attempts)","RELOP(GT)","INT(5)"], [1]),
 ("11", "Keywords vs identifiers (case sensitive, longest match)", "IF IFFY if THEN_X\n",
  ["IF","ID(IFFY)","ID(if)","ID(THEN_X)"], []),
 ("12", "All relational operators and a lone '='", "< <= > >= == != =\n",
  ["RELOP(LT)","RELOP(LE)","RELOP(GT)","RELOP(GE)","RELOP(EQ)","RELOP(NE)"], [1]),
 ("13", "Comments removed; line numbers survive a 2-line block comment (error on line 3)",
  "# whole line comment\n/* block\n comment */ BLOCK ; @\n",
  ["BLOCK","SEMI"], [3]),
 ("14", "Port context ends at the next non-operator token",
  "port == 22 AND attempts > 70000\n",
  ["ID(port)","RELOP(EQ)","PORT(22)","AND","ID(attempts)","RELOP(GT)","INT(70000)"], []),
 ("15", "IP with leading zero 01.2.3.4", "src_ip == 01.2.3.4\n",
  ["ID(src_ip)","RELOP(EQ)"], [1]),
 ("16", "Empty file", "", [], []),
]


MD5 = "d41d8cd98f00b204e9800998ecf8427e"
SHA1 = "da39a3ee5e6b4b0d3255bfef95601890afd80709"
SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
CASES_V2 = [
 ("A", "MD5 hash (32 hex digits)", f"h == {MD5}\n", ["ID(h)","RELOP(EQ)","HASH(md5)"], []),
 ("B", "SHA-1 hash (40 hex digits)", f"h == {SHA1}\n", ["ID(h)","RELOP(EQ)","HASH(sha1)"], []),
 ("C", "SHA-256 hash (64 hex digits)", f"h == {SHA256}\n", ["ID(h)","RELOP(EQ)","HASH(sha256)"], []),
 ("D", "Hash that starts with a digit (would split as INT + ID in v1)", "h == 5d41402abc4b2a76b9719d911017c592\n",
  ["ID(h)","RELOP(EQ)","HASH(md5)"], []),
 ("E", "Hash of 33 digits is malformed", "h == " + MD5 + "0\n", ["ID(h)","RELOP(EQ)"], [1]),
 ("F", "Valid CVE number", "cve == CVE-2024-3400\n", ["ID(cve)","RELOP(EQ)","CVE"], []),
 ("G", "Malformed CVE (short year)", "cve == CVE-24-3400\n", ["ID(cve)","RELOP(EQ)"], [1]),
 ("H", "Valid URL with query and fragment", "u == https://evil.example.com/a/b.php?x=1#top\n",
  ["ID(u)","RELOP(EQ)","URL"], []),
 ("I", "URL directly followed by ';' (';' is not a URL character)", "u == http://a.io/x;\n",
  ["ID(u)","RELOP(EQ)","URL","SEMI"], []),
 ("J", "Empty URL 'http://'", "u == http:// AND x > 1\n", ["ID(u)","RELOP(EQ)","AND","ID(x)","RELOP(GT)","INT(1)"], [1]),
 ("K", "Unsupported scheme 'htp://'", "u == htp://x.com/p\n", ["ID(u)","RELOP(EQ)"], [1]),
 ("L", "Several errors on different lines are ALL reported, scanning continues",
  "a == 10.0.300.5\nb == CVE-1-1\nALERT \"oops ;\nBLOCK ;\n",
  ["ID(a)","RELOP(EQ)","ID(b)","RELOP(EQ)","ALERT","BLOCK","SEMI"], [1,2,3]),
]


def simplify(out):
    toks = []
    for ln in out.splitlines():
        m = re.match(r"\s*(\d+)\s+<(\w+)(?:, (.*))?>$", ln)
        if not m:
            continue
        name, attr = m.group(2), m.group(3)
        if name == "ID":
            attr = attr.split(", ", 1)[1]
        if name == "STRING":
            attr = attr.strip('"')
        if name == "HASH":
            attr = attr.split(", ")[0]
        if name in ("CVE", "URL"):
            attr = None
        has_attr = name in ("ID", "RELOP", "IP", "PORT", "INT", "STRING", "HASH") and attr is not None
        toks.append(f"{name}({attr})" if has_attr else name)
    return toks


def run(binpath, text):
    p = "/tmp/_case.tr"
    open(p, "w").write(text)
    r = subprocess.run([binpath, "-v", p], capture_output=True, text=True)
    err_lines = [int(x) for x in re.findall(r"(?:at line |_case\.tr:)(\d+)", r.stderr)]
    return simplify(r.stdout), err_lines


def main():
    results, ok_all = [], True
    for cid, desc, text, exp_tok, exp_err in CASES:
        row = {"id": cid, "desc": desc, "input": text.rstrip("\n"), "expected_tokens": exp_tok,
               "expected_error_lines": exp_err}
        for tag, b in (("v1", V1), ("v2", V2)):
            toks, errs = run(b, text)
            row[tag] = {"tokens": toks, "error_lines": errs, "pass": toks == exp_tok and errs == exp_err}
            ok_all &= row[tag]["pass"]
        results.append(row)
        flag = "PASS" if row["v1"]["pass"] and row["v2"]["pass"] else "FAIL"
        print(f"case {cid:>2} {flag}  {desc}")
        if flag == "FAIL":
            print("   expected", exp_tok, exp_err)
            print("   v1      ", row["v1"]["tokens"], row["v1"]["error_lines"])
            print("   v2      ", row["v2"]["tokens"], row["v2"]["error_lines"])
    results_v2 = []
    for cid, desc, text, exp_tok, exp_err in CASES_V2:
        row = {"id": cid, "desc": desc, "input": text.rstrip("\n"), "expected_tokens": exp_tok,
               "expected_error_lines": exp_err}
        for tag, b in (("v1", V1), ("v2", V2)):
            toks, errs = run(b, text)
            row[tag] = {"tokens": toks, "error_lines": errs, "pass": toks == exp_tok and errs == exp_err}
        ok_all &= row["v2"]["pass"]
        results_v2.append(row)
        print(f"feed case {cid} v2={'PASS' if row['v2']['pass'] else 'FAIL'}  v1={'PASS' if row['v1']['pass'] else 'fail'}  {desc}")
        if not row["v2"]["pass"]:
            print("   expected", exp_tok, exp_err); print("   v2      ", row["v2"]["tokens"], row["v2"]["error_lines"])
    json.dump(results, open(os.path.join(ROOT, "results", "cases.json"), "w"), indent=1)
    json.dump(results_v2, open(os.path.join(ROOT, "results", "cases_v2.json"), "w"), indent=1)
    print("ALL PASS" if ok_all else "SOME FAILED")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
