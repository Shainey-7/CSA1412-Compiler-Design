#!/usr/bin/env python3
"""bench.py - run the scanners on every test file, check the counts against the
generator's independent expectations, and record median-of-N scanning time.
Scanning time is measured INSIDE the scanner (clock_gettime around the yylex
loop, file already in the page cache), so process start-up is excluded."""
import json, os, re, statistics, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T = os.path.join(ROOT, "tests")
REPS = 9


def run_once(binpath, path):
    p = subprocess.Popen([binpath, "-q", path], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    out = p.stdout.read()
    _, status, ru = os.wait4(p.pid, 0)
    m = re.search(r"SUMMARY lines=(\d+) tokens=(\d+) errors=(\d+) symbols=(\d+) time_ms=([\d.]+)", out)
    return dict(lines=int(m[1]), tokens=int(m[2]), errors=int(m[3]), symbols=int(m[4]),
                time_ms=float(m[5]), rss_kb=ru.ru_maxrss)


def bench(binpath, path, reps=REPS):
    runs = [run_once(binpath, path) for _ in range(reps)]
    r = dict(runs[0])
    r["time_ms"] = statistics.median(x["time_ms"] for x in runs)
    r["time_min_ms"] = min(x["time_ms"] for x in runs)
    r["rss_kb"] = max(x["rss_kb"] for x in runs)
    r["bytes"] = os.path.getsize(path)
    return r


def main():
    v1 = os.path.join(ROOT, "v1", "threatrule")
    v2 = os.path.join(ROOT, "v2", "threatrule_v2")
    v2cf = os.path.join(ROOT, "v2", "threatrule_v2_Cf")
    v1cf = os.path.join(ROOT, "v1", "threatrule_Cf")
    res = {"reps": REPS, "files": {}}
    names = []
    for kind in ("clean", "faulty"):
        for n in (100, 1000, 10000, 100000):
            names.append(f"orig_{kind}_{n}.tr")
    names += ["feed_clean_5000.tr", "feed_faulty_5000.tr"]
    all_ok = True
    for nm in names:
        path = os.path.join(T, nm)
        exp = json.load(open(path + ".expect.json"))
        row = {"expect": exp}
        for tag, b in (("v1", v1), ("v1Cf", v1cf), ("v2", v2), ("v2Cf", v2cf)):
            if os.path.exists(b):
                row[tag] = bench(b, path)
        # correctness checks against the generator's independent numbers
        chk = {}
        for tag in ("v1", "v2"):
            r = row[tag]
            chk[tag] = (r["tokens"] == exp["tokens"] and r["errors"] == exp["errors"]
                        and r["lines"] == exp["lines"])
        row["check"] = chk
        # v1 is only expected to be correct on the ORIGINAL language
        needed = ["v2"] + (["v1"] if exp["kind"] == "orig" else [])
        ok = all(chk[t] for t in needed)
        all_ok &= ok
        res["files"][nm] = row
        print(f"{nm:24s} exp tok={exp['tokens']:>8} err={exp['errors']:>5} | "
              f"v1 tok={row['v1']['tokens']:>8} err={row['v1']['errors']:>6} {row['v1']['time_ms']:8.2f}ms | "
              f"v2 tok={row['v2']['tokens']:>8} err={row['v2']['errors']:>5} {row['v2']['time_ms']:8.2f}ms"
              + (f" | v2-Cf {row['v2Cf']['time_ms']:8.2f}ms" if 'v2Cf' in row else "")
              + ("  OK" if ok else "  MISMATCH"))
    res["all_ok"] = all_ok

    # ---- scalability probe: 1,000,000 rules (not shipped, file is ~120 MB)
    big = "/tmp/orig_clean_1000000.tr"
    if not os.path.exists(big):
        subprocess.run([sys.executable, os.path.join(ROOT, "tools", "gen_rules.py"), "orig", "1000000", big],
                       check=True, stdout=subprocess.DEVNULL)
    exp = json.load(open(big + ".expect.json"))
    row = {"expect": exp}
    for tag, b in (("v1", v1), ("v1Cf", v1cf), ("v2", v2), ("v2Cf", v2cf)):
        if os.path.exists(b):
            row[tag] = bench(b, big, 5)
    res["big"] = row
    print("1M rules:", {k: (v["tokens"], v["errors"], v["time_ms"], v["rss_kb"]) for k, v in row.items() if k != "expect"},
          "expected tokens", exp["tokens"])
    json.dump(res, open(os.path.join(ROOT, "results", "bench.json"), "w"), indent=1)
    print("ALL COUNTS MATCH" if all_ok else "COUNT MISMATCH")


if __name__ == "__main__":
    main()
