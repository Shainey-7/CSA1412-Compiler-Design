#!/usr/bin/env python3
"""analyze_feed.py - how did the ORIGINAL scanner (v1) treat the new feed literals?"""
import json, os, re, subprocess
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
v1 = os.path.join(ROOT, "v1", "threatrule"); v2 = os.path.join(ROOT, "v2", "threatrule_v2")
f = os.path.join(ROOT, "tests", "feed_clean_5000.tr")
text = open(f).read()
lits = {"hash": re.findall(r"file_hash == (\S+)", text), "cve": re.findall(r"cve == (\S+)", text),
        "url": re.findall(r"url == (\S+)", text)}
o1 = subprocess.run([v1, "-v", f], capture_output=True, text=True).stdout
o2 = subprocess.run([v2, "-v", f], capture_output=True, text=True).stdout
id_lex = set(re.findall(r"<ID, \d+, (\S+)>", o1))
res = {"literals": {k: len(v) for k, v in lits.items()}}
for k, v in lits.items():
    whole_id = sum(1 for x in v if x in id_lex)          # whole literal came out as ONE (wrong-class) token
    res[k] = {"total": len(v), "v1_correct_class": 0, "v1_single_wrong_token": whole_id,
              "v1_fragmented": len(v) - whole_id,
              "v2_recognised": len(re.findall(rf"<{k.upper()}[,>]", o2))}
res["v1_summary"] = re.search(r"SUMMARY.*", o1).group(0)
res["v2_summary"] = re.search(r"SUMMARY.*", o2).group(0)
json.dump(res, open(os.path.join(ROOT, "results", "feed_analysis.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
