#!/usr/bin/env python3
"""
gen_rules.py - generate ThreatRule test files of any size.

For every file it also writes <file>.expect.json containing the number of
rules, lines, tokens and lexical errors that the scanner SHOULD report.
These numbers are computed here, independently of the scanner, so that the
scanner output can be checked against them.

usage:  gen_rules.py <kind> <rules> <outfile> [--faulty] [--seed N]
        kind = orig  (original ThreatRule grammar)
               feed  (adds file hashes, CVE numbers and URLs)
"""
import argparse, json, random

OPS = ["==", "!=", "<", "<=", ">", ">="]
FIELDS_INT = ["attempts", "bytes_out", "failed_logins", "conn_count"]
MSGS = ["SSH brute force", "Port scan detected", "Possible data exfiltration",
        "Suspicious login", "Malware beacon", "Lateral movement", "DNS tunnelling"]
HOSTS = ["evil.example.com", "update-check.net", "cdn.bad-actor.org",
         "files.malhost.io", "login-secure.example.net"]
PATHS = ["a/b.php", "dl/payload.exe", "x/y/z.js", "gate.php", "c2/beacon"]


def rand_ip(r):
    pick = r.random()
    if pick < 0.05:
        return "0.0.0.0"
    if pick < 0.10:
        return "255.255.255.255"
    return ".".join(str(r.randint(0, 255)) for _ in range(4))


def rand_port(r):
    pick = r.random()
    if pick < 0.05:
        return 65535
    if pick < 0.08:
        return 0
    return r.randint(1, 65535)


def hexs(r, n):
    return "".join(r.choice("0123456789abcdef") for _ in range(n))


def cond_orig(r, kind=None):
    """return (text, tokens)"""
    kind = kind or r.choice(["src_ip", "dst_ip", "port", "int", "int"])
    if kind in ("src_ip", "dst_ip"):
        return f"{kind} {r.choice(['==', '!='])} {rand_ip(r)}", 3
    if kind == "port":
        return f"port {r.choice(OPS)} {rand_port(r)}", 3
    return f"{r.choice(FIELDS_INT)} {r.choice(OPS)} {r.randint(0, 5000)}", 3


def cond_feed(r, lit):
    kind = r.choice(["hash", "cve", "url"])
    if kind == "hash":
        lit["hash"] += 1
        return f"file_hash == {hexs(r, r.choice([32, 40, 64]))}", 3
    if kind == "cve":
        lit["cve"] += 1
        return f"cve == CVE-{r.randint(1999, 2026)}-{r.randint(1000, 9999999)}", 3
    lit["url"] += 1
    q = "?id=%d&k=%s" % (r.randint(1, 999), hexs(r, 4)) if r.random() < 0.4 else ""
    sch = r.choice(["http", "https", "ftp"])
    return f"url == {sch}://{r.choice(HOSTS)}/{r.choice(PATHS)}{q}", 3


def build_rule(i, r, kind, faulty, lit):
    """returns (lines[list of str], tokens, errors)"""
    # ----- decide the fault (if any) for this rule
    fault = None
    if faulty and i % 20 == 7:
        orig_faults = ["badip", "unterminated", "stray", "badport", "single_eq"]
        feed_faults = ["badhash", "badcve", "emptyurl", "badscheme", "stray2"]
        pool = orig_faults + (feed_faults if kind == "feed" else [])
        fault = pool[(i // 20) % len(pool)]

    n_conds = r.randint(2, 4)
    conds, toks = [], 0
    for k in range(n_conds):
        want = None
        if k == 0 and fault == "badip":
            want = "src_ip"
        if k == 0 and fault == "badport":
            want = "port"
        if k == 0 and fault == "single_eq":
            want = "int"
        if kind == "feed" and k < 2 and fault is None:
            c, t = cond_feed(r, lit)
        elif kind == "feed" and fault in ("badhash", "badcve", "emptyurl", "badscheme") and k == 0:
            c, t = "", 3
        else:
            c, t = cond_orig(r, want)
        conds.append(c); toks += t

    errors = 0
    # ----- apply faults that edit a condition
    if fault == "badip":
        conds[0] = f"src_ip == {r.randint(0,255)}.{r.randint(0,255)}.{r.randint(256,999)}.{r.randint(0,255)}"
        toks -= 1; errors += 1
    elif fault == "badport":
        conds[0] = f"port == {r.randint(65536, 99999)}"
        toks -= 1; errors += 1
    elif fault == "single_eq":
        conds[0] = f"attempts = {r.randint(1, 50)}"
        toks -= 1; errors += 1
    elif fault == "badhash":
        conds[0] = f"file_hash == {hexs(r, r.choice([33, 41, 63, 65]))}"
        toks -= 1; errors += 1
    elif fault == "badcve":
        conds[0] = f"cve == CVE-{r.randint(10, 99)}-{r.randint(1, 99)}"
        toks -= 1; errors += 1
    elif fault == "emptyurl":
        conds[0] = "url == http://"
        toks -= 1; errors += 1
    elif fault == "badscheme":
        conds[0] = f"url == htp://{r.choice(HOSTS)}/{r.choice(PATHS)}"
        toks -= 1; errors += 1

    body = []
    for k, c in enumerate(conds):
        if k:
            body.append(r.choice(["AND", "AND", "OR"])); toks += 1
        body.append(c)
    if fault in ("stray", "stray2"):
        pos = r.randint(1, len(body) - 1) if len(body) > 1 else 1
        body.insert(pos, "@" if fault == "stray" else "@@")
        errors += 1

    # header: RULE name IF  ... THEN
    toks += 3 + 1
    use_alert = r.random() < 0.7 or fault == "unterminated"
    if use_alert:
        msg = r.choice(MSGS)
        if fault == "unterminated":
            action = f'ALERT "{msg} ;'      # closing quote lost, swallows the ';'
            toks += 1                         # ALERT only; STRING and ';' are lost
            errors += 1
        else:
            action = f'ALERT "{msg}" ;'
            toks += 3
    else:
        action = "BLOCK ;"
        toks += 2

    line = f"RULE rule_{i} IF " + " ".join(body) + " THEN " + action
    out = []
    if i % 7 == 0:
        out.append(f"# rule group {i // 7}: generated test rule")
    if i % 50 == 0:
        out.append("/* multi-line block comment:")
        out.append("   keeps line counting honest */")
    if i % 33 == 0:
        out.append("")
    out.append(line)
    return out, toks, errors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("kind", choices=["orig", "feed"])
    ap.add_argument("rules", type=int)
    ap.add_argument("outfile")
    ap.add_argument("--faulty", action="store_true")
    ap.add_argument("--seed", type=int, default=2026)
    a = ap.parse_args()

    r = random.Random(a.seed)
    lit = {"hash": 0, "cve": 0, "url": 0}
    lines, tokens, errors = [], 0, 0
    with open(a.outfile, "w") as f:
        for i in range(1, a.rules + 1):
            ls, t, e = build_rule(i, r, a.kind, a.faulty, lit)
            tokens += t; errors += e
            for l in ls:
                f.write(l + "\n")
            lines.extend(ls)
    exp = dict(file=a.outfile, kind=a.kind, faulty=a.faulty, rules=a.rules,
               lines=len(lines), tokens=tokens, errors=errors, literals=lit)
    json.dump(exp, open(a.outfile + ".expect.json", "w"), indent=1)
    print(json.dumps(exp))


if __name__ == "__main__":
    main()
