from cg import *
from progs import *
def check(name, src, outs, env, arr, k=3, pol=2, show=False):
    p = parse(src) if src else []
    blocks, code, s = generate(p, k, pol, outs) if p else ([],[],Stats())
    e,_,st = run_tac(p, env, arr)
    m,_,steps,dyn = run_target(code, k, env, arr)
    ok = all(e.get(v,0)==m.get(v,0) for v in outs)
    print(f"{name}: blocks={len(blocks)} edges={edge_count(blocks)} instr={ninstr(code)} LD={s.loads} ST={s.stores} spills={s.spills} regs={len(s.used)} cost={total_cost(code)} tac_exec={st} tgt_exec={steps} dyn={dyn}  TAC={ {v:e.get(v,0) for v in sorted(outs)} } TGT={ {v:m.get(v,0) for v in sorted(outs)} } {'MATCH' if ok else 'MISMATCH'}")
    if show:
        for i,b in enumerate(code): print('  B%d:'%i, ' ; '.join(map(str,b)))
check('T1 loop', A2, {'avg','s'}, {'n':6}, {'a':[3,-2,7,0,5,4]}, show=True)
check('T1b loop n=0', A2, {'avg','s'}, {'n':0}, {'a':[]})
check('T2 redefinition', REDEF, {'x','y','z','i'}, {'i':4}, {}, k=2, show=True)
check('T3 single', SINGLE, {'x'}, {}, {}, show=True)
check('T4 jump-to-last a>=b', JLAST, {'r'}, {'a':9,'b':4}, {}, show=True)
check('T4 jump-to-last a<b', JLAST, {'r'}, {'a':1,'b':4}, {})
check('T5 empty', EMPTY, set(), {}, {})
for name,(src,outs,env,arr) in SUITE.items():
  for k in (2,3,4,8):
    for pol in (1,2):
      p=parse(src); blocks, code, s = generate(p,k,pol,outs)
      e,_,st = run_tac(p, env, arr); m,_,steps,dyn = run_target(code,k,env,arr)
      ok = all(e.get(v,0)==m.get(v,0) for v in outs)
      print(name,k,pol, ninstr(code), s.loads, s.stores, s.spills, total_cost(code), steps, dyn, ok)
