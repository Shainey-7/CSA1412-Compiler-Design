A2 = """(1) s = 0
(2) i = 0
(3) if i >= n goto (11)
(4) t1 = 4 * i
(5) t2 = a[t1]
(6) if t2 <= 0 goto (9)
(7) t3 = s + t2
(8) s = t3
(9) i = i + 1
(10) goto (3)
(11) avg = s / n"""
EXPR = """t1 = a + b
t2 = c + d
t3 = e + f
t4 = t1 * t2
t5 = a - c
t6 = t3 * t5
t7 = t4 + t6
t8 = b * d
t9 = t7 - t8
r = t9 + e"""
DOT = """(1) s = 0
(2) i = 0
(3) if i >= n goto (14)
(4) t1 = 4 * i
(5) t2 = a[t1]
(6) t3 = b[t1]
(7) t4 = t2 * t3
(8) t5 = c[t1]
(9) t6 = t4 - t5
(10) t7 = t6 * w
(11) s = s + t7
(12) i = i + 1
(13) goto (3)
(14) r = s + w"""
POLY = """t1 = x * x
t2 = t1 * x
t3 = a * t2
t4 = b * t1
t5 = c * x
t6 = t3 + t4
t7 = t6 + t5
y = t7 + d
z = y * x
q = t1 - t5"""
REDEF = """x = i * 2
i = i + 1
y = i * 2
z = x + y"""
SINGLE = "x = 5"
JLAST = """(1) m = a
(2) if a >= b goto (4)
(3) m = b
(4) r = m * 2"""
EMPTY = ""
SUITE = {
 'A2 loop (sum of positives)': (A2, {'avg','s'}, {'n':6}, {'a':[3,-2,7,0,5,4]}),
 'EXPR block (10 instr)': (EXPR, {'r'}, dict(a=2,b=3,c=4,d=5,e=6,f=7), {}),
 'DOT loop (3 arrays)': (DOT, {'r'}, {'n':5,'w':3}, {'a':[1,2,3,4,5],'b':[2,2,2,2,2],'c':[1,0,1,0,1]}),
 'POLY block': (POLY, {'y','z','q'}, dict(x=3,a=2,b=-1,c=4,d=7), {}),
}
