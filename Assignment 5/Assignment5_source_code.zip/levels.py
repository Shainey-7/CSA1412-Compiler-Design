from cg import *; from opt import *
from progs import *
LV = """(1) k4 = 4
(2) s = 0
(3) i = 0
(4) if i >= n goto (14)
(5) t1 = k4 * i
(6) t2 = a[t1]
(7) t3 = k4 * i
(8) t4 = b[t3]
(9) t5 = t2 * t4
(10) t6 = t5 * 1
(11) s = s + t6
(12) i = i + 1
(13) goto (4)
(14) r = s + 0"""
def compile_level(p, outs, level, k):
    ctr = Counter()
    q = p
    if level >= 2:
        q = global_opt(q, outs, ctr)
    if level >= 1:
        q = dag_program(q, outs, ctr)
        q = [i for i in q if not (i.kind=='copy' and i.dst=='_nop')] or q
    if level >= 2:
        q = global_opt(q, outs, ctr)
    blocks, code, s = generate(q, k, 1 if level == 0 else 2, outs)
    ctr.ops += s.getreg_calls + len(q)
    if level >= 1:
        code, fired = peephole(code, ctr)
    return q, code, s, ctr.ops
def evaluate(name, src, outs, env, arr, k=4, show=False):
    p = parse(src); res=[]
    e0,_,st0 = run_tac(p, env, arr)
    for lvl in (0,1,2):
        q, code, s, ops = compile_level(p, outs, lvl, k)
        m,_,steps,dyn = run_target(code, k, env, arr)
        ok = all(e0.get(v,0)==m.get(v,0) for v in outs)
        res.append(dict(level=lvl, tac_before=len(p), tac_after=len(q), tgt=ninstr(code), cost=total_cost(code), exec=steps, dyn=dyn, ops=ops, ok=ok, stack=len(stack_emit(q))))
        if show:
            print(f' O{lvl}:', ' | '.join(map(str,q)))
            for i,b in enumerate(code): print('    B%d:'%i, ' ; '.join(map(str,b)))
    return res
if __name__ == '__main__':
    for r in evaluate('LV', LV, {'r'}, {'n':5}, {'a':[1,2,3,4,5],'b':[5,4,3,2,1]}, show=True): print(r)
    for name,(src,outs,env,arr) in SUITE.items():
        print(name)
        for r in evaluate(name, src, outs, env, arr): print('  ', r)
