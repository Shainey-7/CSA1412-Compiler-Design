import json, time, cg
from cg import *; from opt import *; from progs import *; from rnd import rand_block
from levels import compile_level, evaluate, LV
R = {}
# ---- A2.3 next-use tables
p = parse(A2); bl = build_cfg(p); IN, OUT = liveness(bl, {'avg','s'})
nu = {}
for b in bl:
    _, rows = next_use(b.instrs, OUT[b.idx])
    nu[b.idx] = dict(live_out=sorted(OUT[b.idx]), rows=[(ins.id, str(ins), {v:[l, (b.instrs[n].id if n is not None else None)] for v,(l,n) in r.items()}) for ins, r in zip(b.instrs, rows)])
    # also naive assumption: program vars live, temps dead
    naive_out = {v for v in ['s','i','n','avg','a']}
    _, rows2 = next_use(b.instrs, naive_out)
    nu[b.idx]['rows_naive'] = [(ins.id, {v:[l, (b.instrs[n].id if n is not None else None)] for v,(l,n) in r.items()}) for ins, r in zip(b.instrs, rows2)]
R['nextuse'] = nu
# ---- A3.3 trace
tr = []
q = parse("t1 = a - b\nt2 = a - c\nt3 = t1 + t2\nd = t3 + t2")
_, code, s = generate(q, 2, 2, {'d'}, trace_block=0, trace=tr)
R['a3trace'] = dict(trace=tr, code=[str(t) for t in code[0]], cost=total_cost(code), costs=[t.cost() for t in code[0]])
ns = Stats(); nc = naive_block(q, {'d'}, ns)
R['a3naive'] = dict(code=[str(t) for t in nc], costs=[t.cost() for t in nc], cost=sum(t.cost() for t in nc))
# ---- A5.1 verify loop transformation
A5AFTER = """(1) s = 0
(2) t1 = 0
(3) t4 = 4 * n
(4) if t1 >= t4 goto (10)
(5) t2 = a[t1]
(6) if t2 <= 0 goto (8)
(7) s = s + t2
(8) t1 = t1 + 4
(9) goto (4)
(10) avg = s / n"""
res = []
for n_, arr in ((6,[3,-2,7,0,5,4]),(1,[-1]),(4,[0,0,9,1])):
    e1,_,st1 = run_tac(parse(A2), {'n':n_}, {'a':arr}); e2,_,st2 = run_tac(parse(A5AFTER), {'n':n_}, {'a':arr})
    res.append((n_, arr, e1['s'], e1['avg'], st1, e2['s'], e2['avg'], st2))
_, c1, _ = generate(parse(A2), 4, 2, {'avg','s'}); _, c2, _ = generate(parse(A5AFTER), 4, 2, {'avg','s'})
m1 = run_target(c1, 4, {'n':6}, {'a':[3,-2,7,0,5,4]}); m2 = run_target(c2, 4, {'n':6}, {'a':[3,-2,7,0,5,4]})
R['a51'] = dict(runs=res, tgt_before=(ninstr(c1), total_cost(c1), m1[2], m1[3]), tgt_after=(ninstr(c2), total_cost(c2), m2[2], m2[3]),
                code_after=[[str(t) for t in b] for b in c2])
# ---- B1.1 tests
def t(name, src, outs, env, arr, k=3, purpose=''):
    pp = parse(src) if src else []
    blocks, code, s = generate(pp, k, 2, outs) if pp else ([], [], Stats())
    e,_,st = run_tac(pp, env, arr); m,_,steps,dyn = run_target(code, k, env, arr)
    ok = all(e.get(v,0)==m.get(v,0) for v in outs)
    return dict(name=name, purpose=purpose, k=k, blocks=len(blocks), edges=edge_count(blocks), instr=ninstr(code), loads=s.loads, stores=s.stores, spills=s.spills, regs=len(s.used), cost=total_cost(code), tac_exec=st, tgt_exec=steps, input=env,
                tac={v:e.get(v,0) for v in sorted(outs)}, tgt={v:m.get(v,0) for v in sorted(outs)}, ok=ok, code=[[str(x) for x in b] for b in code])
R['b11'] = [
 t('T1 Loop (A2 code), n=6', A2, {'avg','s'}, {'n':6}, {'a':[3,-2,7,0,5,4]}, purpose='Loop, back edge, conditional jumps, array indexing; value of t2 must survive across a block boundary.'),
 t('T1b Loop, n=0 (zero trips)', A2, {'avg','s'}, {'n':0}, {'a':[]}, purpose='Loop body never runs: checks fall-through to exit and initial stores.'),
 t('T2 Redefinition, k=2', REDEF, {'x','y','z','i'}, {'i':4}, {}, k=2, purpose='i = i + 1 in mid-block: y must use the new i, x the old one; forces a spill at k=2.'),
 t('T3 Single instruction', SINGLE, {'x'}, {}, {}, purpose='Boundary: one block of one instruction, constant operand.'),
 t('T4 Jump to last instruction (a>=b)', JLAST, {'r'}, {'a':9,'b':4}, {}, purpose='Boundary: target of the jump is the final instruction; taken path.'),
 t('T4b Jump to last instruction (a<b)', JLAST, {'r'}, {'a':1,'b':4}, {}, purpose='Same program, fall-through path.'),
 t('T5 Empty program', EMPTY, set(), {}, {}, purpose='Boundary: zero instructions -> zero blocks, no code, no crash.'),
]
# ---- B1.4 sweep
named = list(SUITE.items())
rand = [rand_block(sd) for sd in range(50)]
renv = {v:(i+2) for i,v in enumerate('abcdef')}
sweep = {}
for k in (2,3,4,8,12):
    row = {}
    for pol in (1,2):
        acc = dict(instr=0, loads=0, stores=0, spills=0, cost=0, exec=0, named_cost=0, named_spills=0)
        for name,(src,outs,env,arr) in named:
            pp = parse(src); _, code, s = generate(pp, k, pol, outs); m = run_target(code, k, env, arr)
            acc['named_cost'] += total_cost(code); acc['named_spills'] += s.spills
            for key,val in (('instr',ninstr(code)),('loads',s.loads),('stores',s.stores),('spills',s.spills),('cost',total_cost(code)),('exec',m[2])): acc[key]+=val
        for src,outs in rand:
            pp = parse(src); _, code, s = generate(pp, k, pol, outs); m = run_target(code, k, renv, {})
            e = run_tac(pp, renv, {})[0]; assert all(e.get(v,0)==m[0].get(v,0) for v in outs)
            for key,val in (('instr',ninstr(code)),('loads',s.loads),('stores',s.stores),('spills',s.spills),('cost',total_cost(code)),('exec',m[2])): acc[key]+=val
        row[pol] = acc
    sweep[k] = row
R['b14'] = sweep
R['rand_example'] = rand[0][0]
# ---- B3.1
from b3 import TESTS
b31 = []
for name, src, outs, envs, arr in TESTS:
    pp = parse(src); df = DF(pp, outs)
    I1,O1,it1,op1 = df.reaching(1); I2,O2,it2,op2 = df.reaching(2)
    L1,LO1,lit1,lop1 = df.live(1); L2,LO2,lit2,lop2 = df.live(2)
    qq = global_opt(pp, outs)
    checks = []
    for env in envs:
        e1 = run_tac(pp, env, arr)[0]; e2 = run_tac(qq, env, arr)[0]
        checks.append((env, {v:e1.get(v,0) for v in outs}, {v:e2.get(v,0) for v in outs}))
    b31.append(dict(name=name, src=[str(x) for x in pp], defs=[(f"d{j+1}", v, str(i)) for j,(v,i) in enumerate([d for d in df.defs if d[1] is not None])],
        blocks=[dict(b=b.idx+1, ids=[x.id for x in b.instrs], rdin=df.names(I2[b.idx]), rdout=df.names(O2[b.idx]), lvin=df.names(L2[b.idx],'v'), lvout=df.names(LO2[b.idx],'v')) for b in df.blocks],
        same_v1v2=(I1==I2 and O1==O2 and L1==L2), it=(it1,it2,lit1,lit2), ops=(op1,op2,lop1,lop2), opt=[str(x) for x in qq], checks=checks))
R['b31'] = b31
# ---- B3.3 with timing
from gen import gen_program
rows=[]
for depth in (1,2,3,4,5):
  for seq in (1,4,16):
    src = gen_program(seq, depth, seed=depth*100+seq); pp = parse(src); df = DF(pp, {'v0','v1'})
    t0=time.perf_counter(); r1=df.reaching(1); t1=time.perf_counter(); r2=df.reaching(2); t2=time.perf_counter()
    l1=df.live(1); t3=time.perf_counter(); l2=df.live(2); t4=time.perf_counter()
    nb=len(df.blocks); vb=df.nd
    rows.append(dict(blocks=nb, defs=len([d for d in df.defs if d[1] is not None]), vecbits=vb, vars=len(df.allvars), depth=depth, seq=seq, instr=len(pp),
      rd=(r1[2],r2[2],r1[3],r2[3]), lv=(l1[2],l2[2],l1[3],l2[3]), ms=((t1-t0)*1e3,(t2-t1)*1e3,(t3-t2)*1e3,(t4-t3)*1e3),
      edges=edge_count(df.blocks)))
R['b33'] = rows
# ---- B4
import cg
cg.COMM_SWAP = False
lvres = evaluate('LV', LV, {'r'}, {'n':5}, {'a':[1,2,3,4,5],'b':[5,4,3,2,1]}, k=16)
R['b4_lv'] = lvres
lvcode = {}
for lvl in (0,1,2):
    qq, code, s, ops = compile_level(parse(LV), {'r'}, lvl, 16)
    lvcode[lvl] = dict(tac=[str(x) for x in qq], tgt=[[str(x) for x in b] for b in code], stack=stack_emit(qq))
R['b4_lvcode'] = lvcode
suite = {}
for name,(src,outs,env,arr) in list(SUITE.items()):
    suite[name] = evaluate(name, src, outs, env, arr, k=16)
R['b4_suite'] = suite
R['b4_expr'] = {}
for sw in (False, True):
    cg.COMM_SWAP = sw
    R['b4_expr'][str(sw)] = evaluate('EXPR', EXPR, {'r'}, dict(a=2,b=3,c=4,d=5,e=6,f=7), {}, k=16)
    qq, code, s, ops = compile_level(parse(EXPR), {'r'}, 2, 16)
    R['b4_expr']['code_'+str(sw)] = [str(x) for x in code[0]]
cg.COMM_SWAP = False
qq, code, s, ops = compile_level(parse(EXPR), {'r'}, 0, 16); R['b4_expr']['code_O0'] = [str(x) for x in code[0]]
json.dump(R, open('results.json','w'), indent=1, default=str)
print('done')
