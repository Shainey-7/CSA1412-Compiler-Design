import cg
from cg import *
from opt import *
from progs import A2
P1 = """a = 5
b = a + 2
c = b * x
a = c - 1
r = a + b"""
P2 = """(1) x = 4
(2) if p > 0 goto (5)
(3) y = x + 1
(4) goto (6)
(5) y = x * 2
(6) z = y + x"""
TESTS = [('1 straight-line', P1, {'r'}, [dict(x=v) for v in (0,3,-7,10)], {}),
         ('2 if/else', P2, {'z'}, [dict(p=v) for v in (1,0,-5,9)], {}),
         ('3 loop (A2)', A2, {'avg','s'}, [dict(n=n) for n in (1,3,6)], {'a':[3,-2,7,0,5,4]})]
for name, src, outs, envs, arr in TESTS:
    p = parse(src); df = DF(p, outs)
    print('==', name, 'defs:', [(f"d{d}", v, str(i)) for d,(v,i) in enumerate(df.defs) if i is not None])
    for ver in (1,2):
        IN,OUT,it,ops = df.reaching(ver)
        LI,LO,lit,lops = df.live(ver)
        print(' V%d RD iters=%d ops=%d | LV iters=%d ops=%d'%(ver,it,ops,lit,lops))
    for b in df.blocks:
        print('  B%d'%b.idx, [i.id for i in b.instrs], 'RDin', df.names(IN[b.idx]), 'RDout', df.names(OUT[b.idx]), 'LVin', df.names(LI[b.idx],'v'), 'LVout', df.names(LO[b.idx],'v'))
    q = global_opt(p, outs)
    print('  optimised:', ' | '.join(map(str,q)))
    for env in envs:
        e1,_,_ = run_tac(p, env, arr); e2,_,_ = run_tac(q, env, arr)
        print('   ', env, {v:e1.get(v,0) for v in outs}, {v:e2.get(v,0) for v in outs}, all(e1.get(v,0)==e2.get(v,0) for v in outs))
