"""
cg.py - Assignment 5 (CO5) toolkit
Three-address code (TAC) -> basic blocks -> flow graph -> next-use ->
register-allocating code generator for the common target machine,
plus interpreters for both TAC and target code so results can be checked.

Target machine:  R0..R(k-1);  LD R,x  ST x,R  OP R,x (ADD SUB MUL DIV)
                 JMP L  JLT/JGT/JEQ R,L
Cost = 1 + operand costs   (register 0, memory / immediate / indexed / label 1)
"""
import re
from dataclasses import dataclass, field
from typing import Optional

COMM = {'+', '*'}
OPNAME = {'+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV'}


def is_const(x):
    return isinstance(x, int)


def is_temp(x):
    return isinstance(x, str) and re.fullmatch(r't+\d+', x) is not None


# ---------------------------------------------------------------- TAC
@dataclass
class Instr:
    id: int
    kind: str                 # bin copy iload istore cjump jump
    dst: Optional[str] = None
    a: object = None
    op: Optional[str] = None
    b: object = None
    target: Optional[int] = None   # id of target instruction (or END)

    def uses(self):
        if self.kind == 'bin':
            xs = [self.a, self.b]
        elif self.kind == 'copy':
            xs = [self.a]
        elif self.kind == 'iload':
            xs = [self.b]                 # index; array itself lives in memory
        elif self.kind == 'istore':
            xs = [self.b, self.a]         # index, value
        elif self.kind == 'cjump':
            xs = [self.a, self.b]
        else:
            xs = []
        return [x for x in xs if isinstance(x, str)]

    def defs(self):
        return self.dst if self.kind in ('bin', 'copy', 'iload') else None

    def __str__(self):
        k = self.kind
        if k == 'bin':
            return f"{self.dst} = {self.a} {self.op} {self.b}"
        if k == 'copy':
            return f"{self.dst} = {self.a}"
        if k == 'iload':
            return f"{self.dst} = {self.a}[{self.b}]"
        if k == 'istore':
            return f"{self.dst}[{self.b}] = {self.a}"
        if k == 'cjump':
            return f"if {self.a} {self.op} {self.b} goto ({self.target})"
        if k == 'jump':
            return f"goto ({self.target})"


END = 10 ** 6
TRAP_DIV0 = False
COMM_SWAP = False


def _opnd(s):
    s = s.strip()
    return int(s) if re.fullmatch(r'-?\d+', s) else s


def parse(text):
    """Lines like '(3) if i >= n goto (11)'. Numbers in brackets are ids;
    if absent, lines are numbered 1,2,3..."""
    prog = []
    n = 0
    for raw in text.strip().splitlines():
        line = raw.strip()
        if not line:
            continue
        n += 1
        m = re.match(r'\((\d+)\)\s*(.*)', line)
        iid, body = (int(m.group(1)), m.group(2)) if m else (n, line)
        if (mm := re.fullmatch(r'if\s+(\S+)\s*(<=|>=|==|!=|<|>)\s*(\S+)\s+goto\s+\(?(\d+)\)?', body)):
            prog.append(Instr(iid, 'cjump', a=_opnd(mm[1]), op=mm[2], b=_opnd(mm[3]), target=int(mm[4])))
        elif (mm := re.fullmatch(r'goto\s+\(?(\d+)\)?', body)):
            prog.append(Instr(iid, 'jump', target=int(mm[1])))
        elif (mm := re.fullmatch(r'(\w+)\[(\w+)\]\s*=\s*(\S+)', body)):
            prog.append(Instr(iid, 'istore', dst=mm[1], b=_opnd(mm[2]), a=_opnd(mm[3])))
        elif (mm := re.fullmatch(r'(\w+)\s*=\s*(\w+)\[(\w+)\]', body)):
            prog.append(Instr(iid, 'iload', dst=mm[1], a=mm[2], b=_opnd(mm[3])))
        elif (mm := re.fullmatch(r'(\w+)\s*=\s*(\S+)\s*([-+*/])\s*(\S+)', body)):
            prog.append(Instr(iid, 'bin', dst=mm[1], a=_opnd(mm[2]), op=mm[3], b=_opnd(mm[4])))
        elif (mm := re.fullmatch(r'(\w+)\s*=\s*(\S+)', body)):
            prog.append(Instr(iid, 'copy', dst=mm[1], a=_opnd(mm[2])))
        else:
            raise ValueError(body)
    return prog


def resolve(prog, tid):
    """Target id -> index in prog (a deleted target falls through to the next survivor)."""
    for idx, ins in enumerate(prog):
        if ins.id >= tid:
            return idx
    return len(prog)


# ------------------------------------------------- TAC interpreter
def run_tac(prog, env, arrays, limit=10 ** 6):
    env = dict(env)
    arrays = {k: list(v) for k, v in arrays.items()}
    pc, steps = 0, 0
    val = lambda x: x if is_const(x) else env.get(x, 0)
    while pc < len(prog) and steps < limit:
        ins = prog[pc]
        steps += 1
        pc += 1
        k = ins.kind
        if k == 'bin':
            env[ins.dst] = arith(ins.op, val(ins.a), val(ins.b))
        elif k == 'copy':
            env[ins.dst] = val(ins.a)
        elif k == 'iload':
            env[ins.dst] = arrays[ins.a][val(ins.b) // 4]
        elif k == 'istore':
            arrays[ins.dst][val(ins.b) // 4] = val(ins.a)
        elif k == 'cjump':
            if relop(ins.op, val(ins.a), val(ins.b)):
                pc = resolve(prog, ins.target)
        elif k == 'jump':
            pc = resolve(prog, ins.target)
    return env, arrays, steps


def arith(op, x, y):
    if op == '+': return x + y
    if op == '-': return x - y
    if op == '*': return x * y
    if op == '/':
        if y == 0:
            if TRAP_DIV0:
                raise ZeroDivisionError('division by zero')
            return 0
        return int(x / y)
    raise ValueError(op)


def relop(op, x, y):
    return {'<': x < y, '>': x > y, '<=': x <= y, '>=': x >= y,
            '==': x == y, '!=': x != y}[op]


# ------------------------------------------ blocks and flow graph
@dataclass
class Block:
    idx: int
    instrs: list
    succ: list = field(default_factory=list)
    pred: list = field(default_factory=list)


def leaders(prog):
    L = set()
    if prog:
        L.add(0)                                   # rule 1: first instruction
    for i, ins in enumerate(prog):
        if ins.kind in ('cjump', 'jump'):
            t = resolve(prog, ins.target)
            if t < len(prog):
                L.add(t)                           # rule 2: target of a jump
            if i + 1 < len(prog):
                L.add(i + 1)                       # rule 3: instruction after a jump
    return sorted(L)


def build_cfg(prog):
    L = leaders(prog)
    blocks = []
    start_of = {}
    for bi, s in enumerate(L):
        e = L[bi + 1] if bi + 1 < len(L) else len(prog)
        blocks.append(Block(bi, prog[s:e]))
        start_of[s] = bi
    EXIT = len(blocks)
    for b in blocks:
        last = b.instrs[-1]
        nxt = b.idx + 1 if b.idx + 1 < len(blocks) else EXIT
        if last.kind == 'jump':
            t = resolve(prog, last.target)
            b.succ = [start_of.get(t, EXIT)]
        elif last.kind == 'cjump':
            t = resolve(prog, last.target)
            tb = start_of.get(t, EXIT)
            b.succ = [tb] + ([nxt] if nxt != tb else [])
        else:
            b.succ = [nxt]
    for b in blocks:
        for s in b.succ:
            if s != EXIT:
                blocks[s].pred.append(b.idx)
    return blocks


def edge_count(blocks):
    return sum(len(b.succ) for b in blocks)


# ----------------------------------------------- next-use info
def next_use(instrs, live_out):
    """Backward scan. Returns after[i] = {var: (live, nextuse_index or None)}
    describing the state just AFTER instruction i, and table rows for display."""
    table = {v: (True, None) for v in live_out}
    after = [None] * len(instrs)
    rows = [None] * len(instrs)
    for i in range(len(instrs) - 1, -1, -1):
        ins = instrs[i]
        after[i] = dict(table)
        info = {}
        d = ins.defs()
        for x in ([d] if d else []) + ins.uses():
            info[x] = table.get(x, (False, None))
        rows[i] = info                       # attach the state seen before update
        if d:
            table[d] = (False, None)
        for u in ins.uses():
            table[u] = (True, i)
    return after, rows


# ------------------------------------------------------ liveness
def liveness(blocks, exit_live):
    use, dfn = [], []
    for b in blocks:
        u, d = set(), set()
        for ins in b.instrs:
            for x in ins.uses():
                if x not in d:
                    u.add(x)
            if ins.defs():
                d.add(ins.defs())
        use.append(u); dfn.append(d)
    IN = [set() for _ in blocks]
    OUT = [set() for _ in blocks]
    changed = True
    while changed:
        changed = False
        for b in reversed(blocks):
            o = set()
            for s in b.succ:
                o |= exit_live if s == len(blocks) else IN[s]
            i = use[b.idx] | (o - dfn[b.idx])
            if i != IN[b.idx] or o != OUT[b.idx]:
                IN[b.idx], OUT[b.idx] = i, o
                changed = True
    return IN, OUT


# ------------------------------------------------ target code
@dataclass
class T:
    op: str
    r: object = None        # register number, or for ST: ('mem',x) / ('idx',a,r)
    x: object = None        # operand
    lab: Optional[int] = None

    def cost(self):
        c = 1
        for o in (self.r, self.x):
            if isinstance(o, tuple) and o[0] in ('mem', 'imm', 'idx'):
                c += 1
        if self.lab is not None:
            c += 1
        return c

    def __str__(self):
        f = lambda o: (f"R{o}" if isinstance(o, int) else
                       o[1] if o[0] == 'mem' else
                       f"#{o[1]}" if o[0] == 'imm' else
                       f"R{o[1]}" if o[0] == 'reg' else f"{o[1]}(R{o[2]})")
        if self.op == 'JMP':
            return f"JMP B{self.lab + 1}"
        if self.op in ('JLT', 'JGT', 'JEQ'):
            return f"{self.op} R{self.r}, B{self.lab + 1}"
        if self.op == 'ST':
            return f"ST {f(self.r)}, R{self.x}"
        return f"{self.op} R{self.r}, {f(self.x)}"


class Stats:
    def __init__(self):
        self.loads = self.stores = self.spills = 0
        self.used = set()
        self.getreg_calls = 0

    def merge(self, o):
        self.loads += o.loads; self.stores += o.stores; self.spills += o.spills
        self.used |= o.used; self.getreg_calls += o.getreg_calls


class BlockGen:
    """Simple code generator for one basic block (A3 design)."""

    def __init__(self, k, policy, instrs, live_out, stats, trace=None):
        self.k, self.policy = k, policy
        self.instrs, self.live_out = instrs, set(live_out)
        self.after, _ = next_use(instrs, live_out)
        self.reg = [set() for _ in range(k)]   # register descriptor
        self.addr = {}                          # address descriptor var -> set
        self.code = []
        self.st = stats
        self.trace = trace

    # --- descriptor helpers
    def loc(self, v):
        if v not in self.addr:
            self.addr[v] = {'mem'}              # on entry every value is in memory
        return self.addr[v]

    def in_reg(self, v):
        for r in range(self.k):
            if v in self.reg[r]:
                return r
        return None

    def emit(self, t):
        self.code.append(t)
        if t.op == 'LD':
            self.st.loads += 1
        if t.op == 'ST':
            self.st.stores += 1
        if t.op not in ('ST', 'JMP') and isinstance(t.r, int):
            self.st.used.add(t.r)

    def status(self, i, v):
        return self.after[i].get(v, (False, None))

    def safe(self, i, v, dst):
        """Can the value v be lost from its register after instruction i?"""
        if v == dst:
            return True
        live, _ = self.status(i, v)
        if not live:
            return True
        return len(self.loc(v)) > 1      # another register or memory holds it

    # --- register selection
    def getreg(self, i, exclude=(), dst=None):
        self.st.getreg_calls += 1
        for r in range(self.k):
            if r not in exclude and not self.reg[r]:
                return r
        cands = [r for r in range(self.k) if r not in exclude]
        if self.policy == 1:
            victim = cands[0]
        else:
            def score(r):
                stores = sum(1 for v in self.reg[r] if not self.safe(i, v, dst))
                nu = []
                for v in self.reg[r]:
                    live, n = self.status(i, v)
                    nu.append(10 ** 9 if not live else (n if n is not None else 10 ** 8))
                return (stores, -min(nu))
            victim = min(cands, key=score)
        self.spill(i, victim, dst)
        return victim

    def spill(self, i, r, dst):
        for v in list(self.reg[r]):
            if not self.safe(i, v, dst):
                self.emit(T('ST', ('mem', v), r))
                self.st.spills += 1
                self.loc(v).add('mem')
            self.loc(v).discard(r)
        self.reg[r] = set()

    def set_reg(self, r, x):
        """r now holds only x (x's previous locations are invalid)."""
        for v in self.reg[r]:
            self.loc(v).discard(r)
        for rr in range(self.k):
            self.reg[rr].discard(x)
        self.reg[r] = {x}
        self.addr[x] = {r}

    def free_dead(self, i, vs):
        for v in vs:
            if isinstance(v, str) and not self.status(i, v)[0]:
                for r in range(self.k):
                    self.reg[r].discard(v)
                if v in self.addr:
                    self.addr[v] = {l for l in self.addr[v] if l == 'mem'}

    def operand(self, v):
        if is_const(v):
            return ('imm', v)
        r = self.in_reg(v)
        return ('reg', r) if r is not None else ('mem', v)

    def result_reg(self, i, y, dst, exclude):
        """Register holding y that may be overwritten with the result."""
        if is_const(y):
            r = self.getreg(i, exclude, dst)
            self.emit(T('LD', r, ('imm', y)))
            return r
        ry = self.in_reg(y)
        if ry is not None:
            if all(self.safe(i, v, dst) for v in self.reg[ry]):
                return ry
            if not [r for r in range(self.k) if r not in set(exclude) | {ry}]:
                # k exhausted (e.g. k=2, y and z both in registers, y still live):
                # save y to memory, then compute in place.  (B1.2 refinement)
                for v in list(self.reg[ry]):
                    if not self.safe(i, v, dst):
                        self.emit(T('ST', ('mem', v), ry))
                        self.st.spills += 1
                        self.loc(v).add('mem')
                return ry
            r = self.getreg(i, set(exclude) | {ry}, dst)
            self.emit(T('LD', r, ('reg', ry)))          # register copy
            return r
        r = self.getreg(i, exclude, dst)
        self.emit(T('LD', r, ('mem', y)))
        self.loc(y)
        return r

    # --- main loop
    def gen(self, labels):
        n = len(self.instrs)
        for i, ins in enumerate(self.instrs):
            k = ins.kind
            if k == 'bin':
                y, z, op = ins.a, ins.b, ins.op
                if is_const(y) and op in COMM and not is_const(z):
                    y, z = z, y
                if (COMM_SWAP and op in COMM and isinstance(y, str) and isinstance(z, str)
                        and self.in_reg(y) is None and self.in_reg(z) is not None):
                    y, z = z, y          # keep the register-resident operand on the left
                rz = self.in_reg(z) if isinstance(z, str) else None
                ex = {rz} if rz is not None else set()
                rx = self.result_reg(i, y, ins.dst, ex)
                self.emit(T(OPNAME[op], rx, self.operand(z) if z != y else ('reg', rx)))
                self.set_reg(rx, ins.dst)
                self.free_dead(i, [y, z])
            elif k == 'copy':
                y, x = ins.a, ins.dst
                if is_const(y):
                    r = self.getreg(i, (), x)
                    self.emit(T('LD', r, ('imm', y)))
                    self.set_reg(r, x)
                else:
                    ry = self.in_reg(y)
                    if ry is None:
                        ry = self.getreg(i, (), x)
                        self.emit(T('LD', ry, ('mem', y)))
                        self.loc(y).add(ry)
                        self.reg[ry] = {y}
                    for rr in range(self.k):
                        if rr != ry:
                            self.reg[rr].discard(x)
                    self.reg[ry].add(x)
                    self.addr[x] = {ry}
                    self.free_dead(i, [y])
            elif k == 'iload':
                t = ins.b
                if is_const(t):
                    r = self.getreg(i, (), ins.dst)
                    self.emit(T('LD', r, ('imm', t)))
                    rt = r
                    self.reg[r] = set()
                    self.emit(T('LD', r, ('idx', ins.a, r)))
                    self.set_reg(r, ins.dst)
                else:
                    rt = self.in_reg(t)
                    if rt is None:
                        rt = self.getreg(i, (), ins.dst)
                        self.emit(T('LD', rt, ('mem', t)))
                        self.loc(t).add(rt); self.reg[rt] = {t}
                    if all(self.safe(i, v, ins.dst) for v in self.reg[rt]) or self.k == 1:
                        rx = rt
                    else:
                        rx = self.getreg(i, {rt}, ins.dst)
                    self.emit(T('LD', rx, ('idx', ins.a, rt)))
                    self.set_reg(rx, ins.dst)
                    self.free_dead(i, [t])
            elif k == 'istore':
                t, y = ins.b, ins.a
                rt = self.in_reg(t)
                if rt is None:
                    rt = self.getreg(i, (), None)
                    self.emit(T('LD', rt, self.operand(t)))
                    if isinstance(t, str):
                        self.loc(t).add(rt); self.reg[rt] = {t}
                ry = self.in_reg(y) if isinstance(y, str) else None
                if ry is None:
                    ry = self.getreg(i, {rt}, None)
                    self.emit(T('LD', ry, self.operand(y)))
                    if isinstance(y, str):
                        self.loc(y).add(ry); self.reg[ry] = {y}
                    else:
                        self.reg[ry] = set()
                self.emit(T('ST', ('idx', ins.dst, rt), ry))
                self.free_dead(i, [t, y])
            elif k == 'cjump':
                y, z = ins.a, ins.b
                rz = self.in_reg(z) if isinstance(z, str) else None
                ex = {rz} if rz is not None else set()
                if z == 0:
                    if isinstance(y, str) and self.in_reg(y) is not None:
                        rx = self.in_reg(y)
                    else:
                        rx = self.getreg(i, ex, None)
                        self.emit(T('LD', rx, self.operand(y)))
                        if isinstance(y, str):
                            self.loc(y).add(rx); self.reg[rx] = {y}
                else:
                    rx = self.result_reg(i, y, '__cmp', ex)
                    self.emit(T('SUB', rx, self.operand(z)))
                    for v in self.reg[rx]:
                        self.loc(v).discard(rx)
                    self.reg[rx] = set()
                self.end_of_block()
                L = labels(ins.target)
                for j in {'<': ['JLT'], '>': ['JGT'], '==': ['JEQ'], '<=': ['JLT', 'JEQ'],
                          '>=': ['JGT', 'JEQ'], '!=': ['JLT', 'JGT']}[ins.op]:
                    self.emit(T(j, rx, lab=L))
                return self.code
            elif k == 'jump':
                self.end_of_block()
                self.emit(T('JMP', lab=labels(ins.target)))
                return self.code
            if self.trace is not None:
                self.trace.append((str(ins), [str(c) for c in self.code],
                                   [sorted(s) for s in self.reg],
                                   {v: sorted(str(l) if l == 'mem' else f"R{l}" for l in L)
                                    for v, L in sorted(self.addr.items())}))
        self.end_of_block()
        return self.code

    def end_of_block(self):
        for v in sorted(self.live_out):
            L = self.loc(v)
            if 'mem' not in L:
                r = min(l for l in L if l != 'mem')
                self.emit(T('ST', ('mem', v), r))
                L.add('mem')


def naive_block(instrs, live_out, stats):
    """A3.1 baseline: load operands, compute, store result - every instruction."""
    code = []
    for ins in instrs:
        if ins.kind == 'bin':
            code += [T('LD', 0, ('imm', ins.a) if is_const(ins.a) else ('mem', ins.a)),
                     T(OPNAME[ins.op], 0, ('imm', ins.b) if is_const(ins.b) else ('mem', ins.b)),
                     T('ST', ('mem', ins.dst), 0)]
        elif ins.kind == 'copy':
            code += [T('LD', 0, ('imm', ins.a) if is_const(ins.a) else ('mem', ins.a)),
                     T('ST', ('mem', ins.dst), 0)]
    for c in code:
        stats.loads += c.op == 'LD'; stats.stores += c.op == 'ST'
    stats.used.add(0)
    return code


def generate(prog, k, policy, exit_live, trace_block=None, trace=None):
    """Whole-program code generation. Live-on-exit of each block comes from
    global liveness (refinement over the 'temporaries are dead' assumption)."""
    blocks = build_cfg(prog)
    _, OUT = liveness(blocks, set(exit_live))
    start_of = {}
    pos = 0
    for b in blocks:
        start_of[pos] = b.idx
        pos += len(b.instrs)
    labels = lambda tid: start_of.get(resolve(prog, tid), len(blocks))
    stats = Stats()
    out = []
    for b in blocks:
        g = BlockGen(k, policy, b.instrs, OUT[b.idx], stats,
                     trace if b.idx == trace_block else None)
        out.append(g.gen(labels))
    return blocks, out, stats


def total_cost(code):
    return sum(t.cost() for blk in code for t in blk)


def ninstr(code):
    return sum(len(b) for b in code)


# ------------------------------------------- target interpreter
def run_target(code, k, env, arrays, limit=10 ** 6):
    mem = dict(env)
    arrays = {a: list(v) for a, v in arrays.items()}
    R = [0] * k
    flat, start = [], []
    for blk in code:
        start.append(len(flat))
        flat += blk
    start.append(len(flat))
    pc, steps, dyn = 0, 0, 0

    def val(o):
        if o[0] == 'reg': return R[o[1]]
        if o[0] == 'imm': return o[1]
        if o[0] == 'mem': return mem.get(o[1], 0)
        if o[0] == 'idx': return arrays[o[1]][R[o[2]] // 4]

    while pc < len(flat) and steps < limit:
        t = flat[pc]
        steps += 1
        dyn += t.cost()
        pc += 1
        if t.op == 'LD':
            R[t.r] = val(t.x)
        elif t.op == 'ST':
            if t.r[0] == 'mem':
                mem[t.r[1]] = R[t.x]
            else:
                arrays[t.r[1]][R[t.r[2]] // 4] = R[t.x]
        elif t.op in ('ADD', 'SUB', 'MUL', 'DIV'):
            R[t.r] = arith({'ADD': '+', 'SUB': '-', 'MUL': '*', 'DIV': '/'}[t.op], R[t.r], val(t.x))
        elif t.op == 'JMP':
            pc = start[t.lab]
        elif t.op == 'JLT' and R[t.r] < 0 or t.op == 'JGT' and R[t.r] > 0 or t.op == 'JEQ' and R[t.r] == 0:
            pc = start[t.lab]
    return mem, arrays, steps, dyn


# ----------------------------------------------- stack bytecode
def stack_emit(prog):
    """Second target (B4.3): a stack bytecode machine. Only this emitter is new."""
    out = []
    p = lambda x: f"PUSH #{x}" if is_const(x) else f"PUSH {x}"
    for ins in prog:
        if ins.kind == 'bin':
            out += [p(ins.a), p(ins.b), OPNAME[ins.op], f"POP {ins.dst}"]
        elif ins.kind == 'copy':
            out += [p(ins.a), f"POP {ins.dst}"]
        elif ins.kind == 'iload':
            out += [p(ins.b), f"ALOAD {ins.a}", f"POP {ins.dst}"]
        elif ins.kind == 'istore':
            out += [p(ins.b), p(ins.a), f"ASTORE {ins.dst}"]
        elif ins.kind == 'cjump':
            out += [p(ins.a), p(ins.b), f"IF_{ins.op} L{ins.target}"]
        elif ins.kind == 'jump':
            out += [f"GOTO L{ins.target}"]
    return out
