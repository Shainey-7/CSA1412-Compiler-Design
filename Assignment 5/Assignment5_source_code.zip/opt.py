"""
opt.py - DAG block optimiser (A4), peephole optimiser, and global data-flow
analysis with bit vectors (A5/B3): reaching definitions, live variables,
constant propagation and dead-code elimination.
"""
from cg import Instr, is_const, build_cfg, resolve, T, COMM
import copy as _copy


class Counter:
    def __init__(self):
        self.ops = 0


# ================================================================ DAG
class DAG:
    def __init__(self, ctr=None):
        self.nodes = []          # node: dict(op, l, r, val, kind, killed)
        self.table = {}          # (op,l,r) -> node id
        self.cur = {}            # var -> node id
        self.leaf = {}           # var -> leaf node id
        self.const = {}
        self.ctr = ctr or Counter()
        self.removed = []        # text notes of what was simplified

    def mk(self, key, **kw):
        self.ctr.ops += 1
        if key in self.table and not self.nodes[self.table[key]].get('killed'):
            return self.table[key], True
        n = len(self.nodes)
        self.nodes.append(dict(key=key, **kw))
        self.table[key] = n
        return n, False

    def node_of(self, x):
        if is_const(x):
            n, _ = self.mk(('c', x), kind='const', val=x)
            return n
        if x in self.cur:
            return self.cur[x]
        n, _ = self.mk(('leaf', x), kind='leaf', val=x)
        self.leaf[x] = n
        return n

    def cval(self, n):
        return self.nodes[n]['val'] if self.nodes[n]['kind'] == 'const' else None

    def binop(self, op, a, b, text):
        from cg import arith
        ca, cb = self.cval(a), self.cval(b)
        if ca is not None and cb is not None:
            self.removed.append(f"{text}: constant folding -> {arith(op, ca, cb)}")
            return self.node_of(arith(op, ca, cb))
        if op == '*' and (cb == 1 or ca == 1):
            self.removed.append(f"{text}: identity x*1 = x")
            return a if cb == 1 else b
        if op == '+' and (cb == 0 or ca == 0):
            self.removed.append(f"{text}: identity x+0 = x")
            return a if cb == 0 else b
        if op == '-' and cb == 0:
            self.removed.append(f"{text}: identity x-0 = x"); return a
        if op == '/' and cb == 1:
            self.removed.append(f"{text}: identity x/1 = x"); return a
        if op == '*' and (ca == 0 or cb == 0):
            self.removed.append(f"{text}: x*0 = 0"); return self.node_of(0)
        if op == '-' and a == b:
            self.removed.append(f"{text}: x-x = 0"); return self.node_of(0)
        if op == '*' and (ca == 2 or cb == 2):
            x = b if ca == 2 else a
            self.removed.append(f"{text}: strength reduction 2*x -> x+x")
            op, a, b = '+', x, x
        if op in COMM and a > b:
            a, b = b, a
        n, reused = self.mk((op, a, b), kind='op', op=op, l=a, r=b)
        if reused:
            self.removed.append(f"{text}: common sub-expression (reuses node n{n})")
        return n

    def add(self, ins):
        if ins.kind == 'bin':
            n = self.binop(ins.op, self.node_of(ins.a), self.node_of(ins.b), str(ins))
            self.cur[ins.dst] = n
        elif ins.kind == 'copy':
            self.cur[ins.dst] = self.node_of(ins.a)
            self.removed.append(f"{ins}: copy - {ins.dst} attached to existing node")
        elif ins.kind == 'iload':
            t = self.node_of(ins.b)
            n, _ = self.mk(('[]', ins.a, t), kind='op', op='[]', l=ins.a, r=t)
            self.cur[ins.dst] = n
        elif ins.kind == 'istore':
            # every earlier load of this array may now be stale: kill those nodes
            for nd in self.nodes:
                if nd.get('op') == '[]' and nd['l'] == ins.dst:
                    nd['killed'] = True
            t, v = self.node_of(ins.b), self.node_of(ins.a)
            n = len(self.nodes)
            self.nodes.append(dict(key=('[]=', n), kind='store', op='[]=', arr=ins.dst, l=t, r=v))

    def code(self, live_out, tail=None):
        """Regenerate TAC from the DAG: only nodes needed by live-out variables,
        stores or the block's final jump survive (dead-code elimination)."""
        need = set()

        def mark(n):
            if n in need or not isinstance(n, int):
                return
            need.add(n)
            nd = self.nodes[n]
            if nd['kind'] in ('op', 'store'):
                if nd['op'] != '[]':
                    mark(nd['l'])
                else:
                    pass
                mark(nd['r']) if nd['op'] != '[]' else mark(nd['r'])
        for v in live_out:
            if v in self.cur:
                mark(self.cur[v])
        for n, nd in enumerate(self.nodes):
            if nd['kind'] == 'store':
                mark(n)
        tail_ops = []
        if tail is not None and tail.kind == 'cjump':
            for x in (tail.a, tail.b):
                if isinstance(x, str) and x in self.cur:
                    mark(self.cur[x])
        attached = {}
        for v, n in self.cur.items():
            if v in live_out:
                attached.setdefault(n, []).append(v)
        name = {}
        for v, n in self.leaf.items():
            name[n] = v
        for n, nd in enumerate(self.nodes):
            if nd['kind'] == 'const':
                name[n] = nd['val']
        out, tmp = [], [0]
        order = [n for n in range(len(self.nodes)) if n in need and self.nodes[n]['kind'] in ('op', 'store')]
        users_after = lambda n, pos: any(
            self.nodes[m].get('l') == n or self.nodes[m].get('r') == n for m in order[pos + 1:])
        pending_copies = []
        for pos, n in enumerate(order):
            nd = self.nodes[n]
            if nd['kind'] == 'store':
                out.append(Instr(0, 'istore', dst=nd['arr'], b=name[nd['l']], a=name[nd['r']]))
                continue
            vs = sorted(attached.get(n, []))
            target = None
            for v in vs:
                # writing v is unsafe if v's initial value (leaf) is still needed later
                lf = self.leaf.get(v)
                if lf is not None and users_after(lf, pos):
                    continue
                target = v
                break
            if target is None:
                tmp[0] += 1
                target = f"tt{tmp[0]}"
            if nd['op'] == '[]':
                out.append(Instr(0, 'iload', dst=target, a=nd['l'], b=name[nd['r']]))
            else:
                out.append(Instr(0, 'bin', dst=target, a=name[nd['l']], op=nd['op'], b=name[nd['r']]))
            name[n] = target
            for v in vs:
                if v != target:
                    pending_copies.append((v, n))
        for v, n in pending_copies:
            out.append(Instr(0, 'copy', dst=v, a=name[n]))
        # live-out variables that ended up equal to a leaf or constant
        for v in sorted(live_out):
            if v in self.cur:
                n = self.cur[v]
                if self.nodes[n]['kind'] in ('leaf', 'const') and not (
                        self.nodes[n]['kind'] == 'leaf' and self.nodes[n]['val'] == v):
                    out.append(Instr(0, 'copy', dst=v, a=name[n]))
        if tail is not None:
            t = _copy.copy(tail)
            for f in ('a', 'b'):
                x = getattr(t, f)
                if isinstance(x, str) and x in self.cur:
                    setattr(t, f, name.get(self.cur[x], x))
            out.append(t)
        return out


def dag_block(instrs, live_out, ctr=None):
    d = DAG(ctr)
    body = instrs
    tail = None
    if instrs and instrs[-1].kind in ('cjump', 'jump'):
        body, tail = instrs[:-1], instrs[-1]
    for ins in body:
        d.add(ins)
    return d, d.code(set(live_out), tail)


def dag_program(prog, exit_live, ctr=None):
    """Apply the DAG optimiser to every block; ids preserved at block starts."""
    from cg import liveness
    blocks = build_cfg(prog)
    _, OUT = liveness(blocks, set(exit_live))
    newprog = []
    for b in blocks:
        _, code = dag_block(b.instrs, OUT[b.idx], ctr)
        first = b.instrs[0].id
        # new instructions get fractional-free ids: keep first id for the leader
        for j, ins in enumerate(code):
            ins.id = first if j == 0 else first + 0  # same id ok: resolve() finds first
        if not code:
            # keep a no-op so jump targets survive
            code = [Instr(first, 'copy', dst='_nop', a=0)]
        newprog += code
    # renumber with gaps preserving relative order and leader ids
    return renumber(newprog)


def renumber(prog):
    """Give unique increasing ids while keeping jump targets correct."""
    old_first = {}
    for idx, ins in enumerate(prog):
        old_first.setdefault(ins.id, idx)
    out = []
    for idx, ins in enumerate(prog):
        n = _copy.copy(ins)
        n.id = idx + 1
        out.append(n)
    for n in out:
        if n.kind in ('cjump', 'jump'):
            t = n.target
            # map old target id to the first new instruction with that old id (or next)
            cands = [i for oid, i in old_first.items() if oid >= t]
            n.target = (min(cands) + 1) if cands else 10 ** 6
    return out


# ============================================================ peephole
def peephole(code, ctr=None):
    """code: list of blocks of T. Rules P1-P6 applied until nothing changes."""
    ctr = ctr or Counter()
    fired = {}
    changed = True
    code = [list(b) for b in code]
    while changed:
        changed = False
        for bi, blk in enumerate(code):
            out = []
            i = 0
            while i < len(blk):
                ctr.ops += 1
                t = blk[i]
                nx = blk[i + 1] if i + 1 < len(blk) else None
                # P1: ST x,R ; LD R,x  -> drop the load
                if nx and t.op == 'ST' and nx.op == 'LD' and t.r[0] == 'mem' and nx.x == t.r and nx.r == t.x:
                    out.append(t); i += 2; fired['P1 ST x,R / LD R,x'] = fired.get('P1 ST x,R / LD R,x', 0) + 1; changed = True; continue
                # P2: LD R,x ; ST x,R -> drop the store
                if nx and t.op == 'LD' and nx.op == 'ST' and t.x[0] == 'mem' and nx.r == t.x and nx.x == t.r:
                    out.append(t); i += 2; fired['P2 LD R,x / ST x,R'] = fired.get('P2 LD R,x / ST x,R', 0) + 1; changed = True; continue
                # P3: algebraic no-ops
                if t.op in ('ADD', 'SUB') and t.x == ('imm', 0) or t.op in ('MUL', 'DIV') and t.x == ('imm', 1):
                    i += 1; fired['P3 x+0 / x*1'] = fired.get('P3 x+0 / x*1', 0) + 1; changed = True; continue
                # P4: strength reduction MUL R,#2 -> ADD R,R
                if t.op == 'MUL' and t.x == ('imm', 2):
                    out.append(T('ADD', t.r, ('reg', t.r))); i += 1
                    fired['P4 MUL #2 -> ADD R,R'] = fired.get('P4 MUL #2 -> ADD R,R', 0) + 1; changed = True; continue
                # P5: jump to the next block
                if t.op == 'JMP' and t.lab == bi + 1 and i == len(blk) - 1:
                    i += 1; fired['P5 jump to next'] = fired.get('P5 jump to next', 0) + 1; changed = True; continue
                # P6: LD Ri,Ri
                if t.op == 'LD' and t.x == ('reg', t.r):
                    i += 1; fired['P6 LD Ri,Ri'] = fired.get('P6 LD Ri,Ri', 0) + 1; changed = True; continue
                out.append(t)
                i += 1
            code[bi] = out
    return code, fired


# ===================================================== data-flow (bit vectors)
class DF:
    """Reaching definitions and live variables on bit vectors (Python ints)."""

    def __init__(self, prog, exit_live):
        self.prog = prog
        self.blocks = build_cfg(prog)
        self.exit_live = set(exit_live)
        # definitions: real ones plus one 'entry' pseudo-definition per variable
        self.defs = []
        self.var_defs = {}
        allvars = set()
        for ins in prog:
            allvars |= set(ins.uses())
            if ins.defs():
                allvars.add(ins.defs())
        self.allvars = sorted(allvars)
        for v in self.allvars:
            self._adddef(v, None)
        self.def_at = {}
        for b in self.blocks:
            for ins in b.instrs:
                if ins.defs():
                    self.def_at[ins.id] = self._adddef(ins.defs(), ins)
        self.nd = len(self.defs)
        self.vidx = {v: i for i, v in enumerate(self.allvars)}

    def _adddef(self, v, ins):
        d = len(self.defs)
        self.defs.append((v, ins))
        self.var_defs.setdefault(v, 0)
        self.var_defs[v] |= 1 << d
        return d

    def entry_defs(self):
        m = 0
        for d, (v, ins) in enumerate(self.defs):
            if ins is None:
                m |= 1 << d
        return m

    def gen_kill(self):
        G, K = [], []
        for b in self.blocks:
            g = k = 0
            for ins in b.instrs:
                if ins.defs():
                    d = self.def_at[ins.id]
                    allv = self.var_defs[ins.defs()]
                    g = (g & ~allv) | (1 << d)
                    k |= allv & ~(1 << d)
            G.append(g); K.append(k)
        return G, K

    # --- block visiting orders
    def rpo(self):
        seen, post = set(), []

        def dfs(n):
            seen.add(n)
            for s in self.blocks[n].succ:
                if s < len(self.blocks) and s not in seen:
                    dfs(s)
            post.append(n)
        import sys
        sys.setrecursionlimit(100000)
        if self.blocks:
            dfs(0)
        rest = [b.idx for b in self.blocks if b.idx not in seen]
        return list(reversed(post)) + rest

    def order(self, version, direction):
        if version == 1:
            return [b.idx for b in self.blocks]
        r = self.rpo()
        return r if direction == 'forward' else list(reversed(r))

    def reaching(self, version=1, trace=None):
        G, K = self.gen_kill()
        nb = len(self.blocks)
        IN, OUT = [0] * nb, [0] * nb
        for i in range(nb):
            OUT[i] = G[i]                       # initialisation OUT = gen
        ops, iters = 0, 0
        changed = True
        order = self.order(version, 'forward')
        E = self.entry_defs()
        while changed:
            changed = False
            iters += 1
            for i in order:
                b = self.blocks[i]
                x = E if i == 0 else 0
                for p in b.pred:
                    x |= OUT[p]; ops += 1
                o = G[i] | (x & ~K[i]); ops += 2
                if x != IN[i] or o != OUT[i]:
                    changed = True
                IN[i], OUT[i] = x, o
            if trace is not None:
                trace.append((list(IN), list(OUT)))
        return IN, OUT, iters, ops

    def live(self, version=1):
        nb = len(self.blocks)
        U, D = [], []
        for b in self.blocks:
            u = d = 0
            for ins in b.instrs:
                for x in ins.uses():
                    if not (d >> self.vidx[x]) & 1:
                        u |= 1 << self.vidx[x]
                if ins.defs():
                    d |= 1 << self.vidx[ins.defs()]
            U.append(u); D.append(d)
        ex = 0
        for v in self.exit_live:
            if v in self.vidx:
                ex |= 1 << self.vidx[v]
        IN, OUT = [0] * nb, [0] * nb
        ops, iters = 0, 0
        changed = True
        order = self.order(version, 'backward')
        while changed:
            changed = False
            iters += 1
            for i in order:
                o = 0
                for s in self.blocks[i].succ:
                    o |= ex if s == nb else IN[s]; ops += 1
                n = U[i] | (o & ~D[i]); ops += 2
                if n != IN[i] or o != OUT[i]:
                    changed = True
                IN[i], OUT[i] = n, o
        return IN, OUT, iters, ops

    def names(self, mask, kind='def'):
        if kind == 'def':
            first = len(self.allvars)
            return [f"d{d - first + 1}" for d in range(self.nd) if (mask >> d) & 1 and self.defs[d][1] is not None]
        return [v for v in self.allvars if (mask >> self.vidx[v]) & 1]


def const_prop(prog, exit_live, ctr=None):
    """Global constant propagation using reaching definitions."""
    ctr = ctr or Counter()
    df = DF(prog, exit_live)
    IN, _, it, ops = df.reaching(2)
    ctr.ops += ops * max(1, (df.nd + 63) // 64)
    changed = False
    new = []
    for b in df.blocks:
        rd = IN[b.idx]
        for ins in b.instrs:
            n = _copy.copy(ins)

            def cval(x):
                if not isinstance(x, str):
                    return x
                ds = rd & df.var_defs[x]
                vals = set()
                for d in range(df.nd):
                    if (ds >> d) & 1:
                        v, di = df.defs[d]
                        if di is None or di.kind != 'copy' or not is_const(di.a):
                            return x
                        vals.add(di.a)
                return vals.pop() if len(vals) == 1 else x
            for f in ('a', 'b'):
                if n.kind in ('bin', 'copy', 'cjump') or (n.kind == 'istore' and f in ('a', 'b')) or (n.kind == 'iload' and f == 'b'):
                    old = getattr(n, f)
                    nv = cval(old)
                    if nv != old:
                        setattr(n, f, nv); changed = True
            from cg import arith, relop
            if n.kind == 'bin' and is_const(n.a) and is_const(n.b):
                n = Instr(n.id, 'copy', dst=n.dst, a=arith(n.op, n.a, n.b)); changed = True
            if n.kind == 'cjump' and is_const(n.a) and is_const(n.b):
                if relop(n.op, n.a, n.b):
                    n = Instr(n.id, 'jump', target=n.target)
                else:
                    n = Instr(n.id, 'copy', dst='_nop', a=0)
                changed = True
            new.append(n)
            if ins.defs():
                rd = (rd & ~df.var_defs[ins.defs()]) | (1 << df.def_at[ins.id])
    return new, changed


def dce(prog, exit_live, ctr=None):
    """Remove assignments whose result is not live afterwards (and _nop)."""
    ctr = ctr or Counter()
    df = DF(prog, exit_live)
    _, OUT, it, ops = df.live(2)
    ctr.ops += ops * max(1, (len(df.allvars) + 63) // 64)
    keep_ids = set()
    removed = []
    for b in df.blocks:
        live = OUT[b.idx]
        kept = []
        for ins in reversed(b.instrs):
            d = ins.defs()
            if d is not None and not (live >> df.vidx[d]) & 1:
                removed.append(ins)
                continue
            kept.append(ins)
            if d is not None:
                live &= ~(1 << df.vidx[d])
            for u in ins.uses():
                live |= 1 << df.vidx[u]
        keep_ids |= {id(x) for x in kept}
    out = [ins for ins in prog if id(ins) in keep_ids]
    # remove unreachable blocks
    return out, removed


def global_opt(prog, exit_live, ctr=None, rounds=5):
    for _ in range(rounds):
        prog, ch = const_prop(prog, exit_live, ctr)
        prog, rem = dce(prog, exit_live, ctr)
        prog = drop_unreachable(prog)
        if not ch and not rem:
            break
    return prog


def drop_unreachable(prog):
    if not prog:
        return prog
    blocks = build_cfg(prog)
    seen, st = {0}, [0]
    while st:
        n = st.pop()
        for s in blocks[n].succ:
            if s < len(blocks) and s not in seen:
                seen.add(s); st.append(s)
    out = []
    for b in blocks:
        if b.idx in seen:
            out += b.instrs
    # a jump whose target is the very next instruction is useless
    res = []
    for i, ins in enumerate(out):
        if ins.kind == 'jump' and resolve(out, ins.target) == i + 1:
            continue
        res.append(ins)
    return res if res else []
