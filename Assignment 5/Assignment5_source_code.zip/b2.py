from cg import *
BA = """t1 = a + b
t2 = t1 * c
t3 = t2 - d
t4 = t3 + e
t5 = t4 * f
t6 = t5 - g
x = t6 + h"""
BB = """t1 = a + b
t2 = c + d
t3 = e + f
t4 = g + h
t5 = t1 * t2
t6 = t3 * t4
x = t5 - t6"""
BB2 = """t1 = a + b
t2 = c + d
t5 = t1 * t2
t3 = e + f
t4 = g + h
t6 = t3 * t4
x = t5 - t6"""
env = dict(a=1,b=2,c=3,d=4,e=5,f=6,g=7,h=8)
def peak(p, outs):
    after,_ = next_use(p, outs)
    livecnt = []
    for i in range(len(p)):
        livecnt.append(sorted(v for v,(l,_) in after[i].items() if l and is_temp(v)))
    return livecnt
for name,src in (('A',BA),('B',BB),('B-reordered',BB2)):
    p=parse(src)
    for pol in (2,1):
        _,code,s=generate(p,2,pol,{'x'})
        m,_,steps,dyn=run_target(code,2,env,{})
        e,_,_=run_tac(p,env,{})
        print(name,'V%d'%pol, ninstr(code), s.loads,s.stores,s.spills,total_cost(code), m['x'], e['x'])
    print('  ', ' ; '.join(map(str,generate(p,2,2,{'x'})[1][0])))
    pk = peak(p,{'x'}); print('   live temps after each:', [len(x) for x in pk], pk)
