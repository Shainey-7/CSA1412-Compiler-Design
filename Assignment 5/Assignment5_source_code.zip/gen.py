import random
def gen_program(seq, depth, seed=0, body=3):
    """seq loop nests in sequence, each nested `depth` deep, each loop body has an if/else."""
    R = random.Random(seed)
    lines = []          # list of [text, label_placeholders]
    pool = [f"v{i}" for i in range(6)]
    def emit(s): lines.append(s); return len(lines)
    def assigns(m):
        for _ in range(m):
            emit(f"{R.choice(pool)} = {R.choice(pool)} {R.choice('+-*')} {R.choice(pool+[str(R.randint(1,5))])}")
    def loop(d, tag):
        iv = f"i{tag}{d}"
        emit(f"{iv} = 0")
        h = emit(f"if {iv} >= n goto @EXIT{tag}{d}")
        assigns(body)
        j = emit(f"if {R.choice(pool)} > 0 goto @ELSE{tag}{d}")
        assigns(1)
        emit(f"goto @JOIN{tag}{d}")
        lines.append(f"@L ELSE{tag}{d}"); assigns(1)
        lines.append(f"@L JOIN{tag}{d}")
        if d > 1: loop(d-1, tag)
        assigns(1)
        emit(f"{iv} = {iv} + 1")
        emit(f"goto ({h})")
        lines.append(f"@L EXIT{tag}{d}")
    for s in range(seq):
        assigns(2); loop(depth, chr(97+s%26)+str(s))
    assigns(1)
    # resolve labels -> instruction numbers
    out, lab, n = [], {}, 0
    for l in lines:
        if l.startswith("@L "): lab[l[3:]] = n+1
        else: n += 1
    n=0
    for l in lines:
        if l.startswith("@L "): continue
        n += 1
        import re
        l = re.sub(r"@(\w+)", lambda m: f"({lab[m[1]]})", l)
        # goto (h) uses line index of emitted list, which equals instruction number
        out.append(f"({n}) {l}")
    return "\n".join(out)
