import cg
from cg import *; from opt import *
CONS = """(1) x = 0
(2) if p > 0 goto (4)
(3) x = 1
(4) if p <= 0 goto (6)
(5) y = x + 1
(6) r = y + p"""
p=parse(CONS); df=DF(p,{'r'}); IN,OUT,it,ops=df.reaching(2)
for b in df.blocks: print('B%d'%(b.idx+1),[i.id for i in b.instrs],'succ',[s+1 for s in b.succ],'RDin',df.names(IN[b.idx]))
q=global_opt(p,{'r'}); print('opt:', ' | '.join(map(str,q)))
for pv in (3,-2): print(pv, run_tac(p,{'p':pv},{})[0])
UNSAFE = """(1) s = 0
(2) i = 0
(3) if i >= n goto (8)
(4) q = m / d
(5) s = s + q
(6) i = i + 1
(7) goto (3)
(8) r = s"""
HOIST = """(1) s = 0
(2) i = 0
(3) q = m / d
(4) if i >= n goto (8)
(5) s = s + q
(6) i = i + 1
(7) goto (4)
(8) r = s"""
cg.TRAP_DIV0 = True
for env in (dict(n=3,m=12,d=4), dict(n=0,m=12,d=0)):
  for name,src in (('original',UNSAFE),('hoisted',HOIST)):
    try: e,_,st=run_tac(parse(src),env,{}); print(env,name,'r =',e['r'],'steps',st)
    except ZeroDivisionError as ex: print(env,name,'TRAP:',ex)
