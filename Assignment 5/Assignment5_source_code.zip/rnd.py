import random
from cg import *
def rand_block(seed, n=14, nvars=6):
    R = random.Random(seed)
    vs = [chr(ord('a')+i) for i in range(nvars)]
    defined = list(vs); lines=[]
    for j in range(n):
        y = R.choice(defined); z = R.choice(defined + [R.randint(1,9)])
        op = R.choice('+-*')
        dst = f"t{j+1}" if R.random()<0.7 else R.choice(vs)
        lines.append(f"{dst} = {y} {op} {z}")
        if dst not in defined: defined.append(dst)
    src="\n".join(lines)
    outs = set(vs)
    return src, outs
if __name__=='__main__':
    for k in (2,3,4,8):
        agg={1:[0]*5,2:[0]*5}
        for sd in range(50):
            src,outs=rand_block(sd)
            p=parse(src)
            env={v:(i+2) for i,v in enumerate('abcdef')}
            for pol in (1,2):
                _,code,s=generate(p,k,pol,outs)
                e,_,_=run_tac(p,env,{}); m,_,steps,dyn=run_target(code,k,env,{})
                assert all(e.get(v,0)==m.get(v,0) for v in outs), (sd,k,pol)
                for j,x in enumerate((ninstr(code),s.loads,s.stores,s.spills,total_cost(code))): agg[pol][j]+=x
        print(k, agg)
